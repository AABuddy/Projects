package uk.ac.aber.dcs.cs31620.demonstratingtsp.components

import androidx.compose.ui.unit.Dp

data class Node(
    var id: Int,
    var x: Float,
    var y: Float
)