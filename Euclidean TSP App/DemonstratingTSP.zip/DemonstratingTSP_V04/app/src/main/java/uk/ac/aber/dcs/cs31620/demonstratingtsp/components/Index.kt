package uk.ac.aber.dcs.cs31620.demonstratingtsp.components

data class index(
    var currentNode : Int,
    var nodeSet : Set<Int>
)
