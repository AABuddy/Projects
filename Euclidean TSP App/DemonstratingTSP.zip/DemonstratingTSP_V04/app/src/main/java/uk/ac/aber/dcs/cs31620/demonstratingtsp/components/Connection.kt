package uk.ac.aber.dcs.cs31620.demonstratingtsp.components

import androidx.compose.ui.geometry.Offset

data class Connection(
    var start: Offset,
    var end: Offset,
)
