DELETE
FROM PayloadStore;
