SELECT Metadata
FROM `PayloadStore`
WHERE `Key`=?;
