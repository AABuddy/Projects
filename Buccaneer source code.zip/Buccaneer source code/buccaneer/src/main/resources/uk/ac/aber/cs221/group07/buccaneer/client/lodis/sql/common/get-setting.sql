SELECT `Value`
FROM `Settings`
WHERE `Setting`=?;
