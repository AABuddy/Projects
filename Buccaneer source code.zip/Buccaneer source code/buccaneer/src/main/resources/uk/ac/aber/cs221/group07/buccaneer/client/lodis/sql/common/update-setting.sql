UPDATE `Settings`
SET `Value`=?
WHERE Setting=?;
