DELETE
FROM `PayloadStore`
WHERE `Key`=?;
