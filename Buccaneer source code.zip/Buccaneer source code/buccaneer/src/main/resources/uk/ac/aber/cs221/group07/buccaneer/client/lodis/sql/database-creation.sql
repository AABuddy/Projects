CREATE TABLE IF NOT EXISTS "PayloadStore"
(
    "Key" TEXT UNIQUE,
    "Metadata" TEXT NOT NULL,
    "Payload" BLOB,
    PRIMARY KEY ("Key")
);


CREATE TABLE IF NOT EXISTS "Settings"
(
    "Setting" TEXT NOT NULL UNIQUE,
    "Value" TEXT NOT NULL UNIQUE,
    PRIMARY KEY ("Setting")
);

INSERT OR IGNORE
INTO `Settings`
VALUES ("DumpFiles", "[]");
