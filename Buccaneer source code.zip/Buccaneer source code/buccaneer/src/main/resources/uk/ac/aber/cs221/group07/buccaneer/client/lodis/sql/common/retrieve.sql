SELECT `Metadata`, `Payload`
FROM `PayloadStore`
WHERE `Key`=?
