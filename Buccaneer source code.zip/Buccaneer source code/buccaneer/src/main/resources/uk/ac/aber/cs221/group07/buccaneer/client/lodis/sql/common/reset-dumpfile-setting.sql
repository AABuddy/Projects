UPDATE `Settings`
SET VALUE="[]"
WHERE "Setting" LIKE "DumpFiles";
