SELECT EXISTS(
    SELECT *
    FROM `PayloadStore`
    WHERE `Key`=?
) AS "DoesExist";
