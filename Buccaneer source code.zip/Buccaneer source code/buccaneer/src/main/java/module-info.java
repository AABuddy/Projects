/**
 * @author Julia Drozdz -- jud28@aber.ac.uk
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * module-info.java 22.05.06 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
module uk.ac.aber.cs221.group07.buccaneer.buccaneer {
    requires com.google.gson;
    requires org.xerial.sqlitejdbc;
    requires org.apache.commons.io;
    requires java.sql;
    requires javafx.controls;
    requires javafx.fxml;
    requires junit;
    requires org.apiguardian.api;
    requires org.junit.platform.commons;
    requires org.junit.jupiter.api;
    requires org.junit.jupiter.engine;

    exports uk.ac.aber.cs221.group07.buccaneer.client.controllers;
    opens uk.ac.aber.cs221.group07.buccaneer.client.controllers to javafx.fxml;

    exports uk.ac.aber.cs221.group07.buccaneer.client;
    opens uk.ac.aber.cs221.group07.buccaneer.client to javafx.fxml;


    exports uk.ac.aber.cs221.group07.buccaneer.client.lodis to junit;
    exports uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.exceptions to junit;
    exports uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.exceptions.specific to junit;
    exports uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.chassis to junit;
    exports uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.statics to junit;

    exports uk.ac.aber.cs221.group07.buccaneer_testing.tests.cards to junit;
    exports uk.ac.aber.cs221.group07.buccaneer_testing.tests.location to junit;
    exports uk.ac.aber.cs221.group07.buccaneer_testing.tests.other to junit;
    exports uk.ac.aber.cs221.group07.buccaneer_testing.tests.treasure to junit;

}