package uk.ac.aber.cs221.group07.buccaneer_testing.tests.location;

import javafx.geometry.Point2D;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import uk.ac.aber.cs221.group07.buccaneer.client.utils.Port;

/**
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * @version 22.05.06
 * buccaneer_testing.tests.location.PortTest.java 22.05.06 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
public class PortTest {
    Port testPort = new Port("test port", new Point2D(1, 2), true);

    @Test
    public void TestTurnOrder() {
        testPort.setTurnOrder(123);
        Assertions.assertEquals(123, testPort.getTurnOrder());
    }

    @Test
    public void TestIsTradable() {
        testPort.setTradable(true);
        Assertions.assertTrue(testPort.isTradable());
        testPort.setTradable(false);
        Assertions.assertFalse(testPort.isTradable());
    }

    @Test
    public void TestLocation() {
        Assertions.assertEquals(
                new Point2D(1, 2),
                testPort.getLocation()
        );
    }
}
