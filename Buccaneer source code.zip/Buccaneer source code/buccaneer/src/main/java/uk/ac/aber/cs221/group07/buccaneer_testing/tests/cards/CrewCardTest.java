package uk.ac.aber.cs221.group07.buccaneer_testing.tests.cards;

import javafx.scene.paint.Color;
import org.junit.Test;
import uk.ac.aber.cs221.group07.buccaneer.client.utils.CrewCard;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class CrewCardTest {
    CrewCard testCrewCard = new CrewCard(1234, Color.BLACK);

    // ##################################################
    // Card
    // ##################################################
    @Test
    public void ID() {
        assertNull(testCrewCard.getId());
    }

    @Test
    public void Text() {
        assertNull(testCrewCard.getText());
    }


    // ##################################################
    // CrewCard
    // ##################################################
    @Test
    public void Colour() {
        assertEquals(
                testCrewCard.getColor(),
                Color.BLACK
        );
    }

    @Test
    public void Value() {
        assertEquals(
                testCrewCard.getValue(),
                1234
        );
    }
}
