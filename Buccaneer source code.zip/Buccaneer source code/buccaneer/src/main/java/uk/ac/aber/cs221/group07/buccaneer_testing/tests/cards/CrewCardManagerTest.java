package uk.ac.aber.cs221.group07.buccaneer_testing.tests.cards;

import org.junit.Test;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;
import uk.ac.aber.cs221.group07.buccaneer.client.utils.CrewCardManager;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class CrewCardManagerTest {
    private final CrewCardManager testCrewCardManager = new CrewCardManager();


    @Test
    @Order(1)
    public void InitialiseInstance() {
        this.testCrewCardManager.initialize();
    }


    /*
    @Test
    @Order(2)
    public void getRed1(){
        Assertions.assertNotNull(this.testCrewCardManager.getRandom());
    }
     */
}
