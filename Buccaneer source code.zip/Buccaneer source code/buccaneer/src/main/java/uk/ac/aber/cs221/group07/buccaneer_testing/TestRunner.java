package uk.ac.aber.cs221.group07.buccaneer_testing;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import uk.ac.aber.cs221.group07.buccaneer_testing.tests.cards.ChanceCardManagerTest;
import uk.ac.aber.cs221.group07.buccaneer_testing.tests.cards.ChanceCardTest;
import uk.ac.aber.cs221.group07.buccaneer_testing.tests.cards.CrewCardManagerTest;
import uk.ac.aber.cs221.group07.buccaneer_testing.tests.cards.CrewCardTest;
import uk.ac.aber.cs221.group07.buccaneer_testing.tests.location.IslandTest;
import uk.ac.aber.cs221.group07.buccaneer_testing.tests.location.PortTest;
import uk.ac.aber.cs221.group07.buccaneer_testing.tests.other.GameWorldTest;
import uk.ac.aber.cs221.group07.buccaneer_testing.tests.other.InventoryTest;
import uk.ac.aber.cs221.group07.buccaneer_testing.tests.other.PlayerTest;
import uk.ac.aber.cs221.group07.buccaneer_testing.tests.treasure.TreasureManagerTest;
import uk.ac.aber.cs221.group07.buccaneer_testing.tests.treasure.TreasureTest;

/**
 * Responsible for running all tests automatically and generating a report.
 *
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * @version 22.05.06
 * buccaneer_testing.TestRunner.java 22.05.06 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({
        ChanceCardManagerTest.class,
        ChanceCardTest.class,
        CrewCardManagerTest.class,
        CrewCardTest.class,

        IslandTest.class,
        PortTest.class,

        /*DeckTest.class,*/
        GameWorldTest.class,
        InventoryTest.class,
        PlayerTest.class,

        TreasureManagerTest.class,
        TreasureTest.class/*,

        PersistentStorageTest.class*/
})
public class TestRunner {

}
