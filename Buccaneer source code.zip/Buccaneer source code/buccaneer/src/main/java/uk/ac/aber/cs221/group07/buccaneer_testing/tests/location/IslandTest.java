package uk.ac.aber.cs221.group07.buccaneer_testing.tests.location;

import javafx.geometry.Point2D;
import org.junit.Test;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;
import uk.ac.aber.cs221.group07.buccaneer.client.utils.Island;

import static org.junit.Assert.assertEquals;

/**
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * @version 22.05.06
 * buccaneer_testing.tests.location.IslandTest.java 22.05.06 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class IslandTest {
    public Point2D[] testLocation1 = new Point2D[]{new Point2D(1, 2), new Point2D(3, 4)};
    public Point2D[] testLocation2 = new Point2D[]{new Point2D(1, 2), new Point2D(3, 4)};
    public Island testIsland = new Island("test island", testLocation1);

    @Test
    @Order(1)
    public void TestLocation() {
        assertEquals(
                this.testLocation1,
                testIsland.getLocation()
        );
    }

    @Test
    @Order(2)
    public void ChangeLocation() {
        testIsland.setLocation(testLocation2);
    }

    @Test
    @Order(3)
    public void TestLocationAgain() {
        assertEquals(
                this.testLocation2,
                testIsland.getLocation()
        );
    }
}
