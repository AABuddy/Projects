/*
 * @(#) Island.java 1.0 | 2022/05/06 *
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved. *
 */
package uk.ac.aber.cs221.group07.buccaneer.client.utils;

import javafx.geometry.Point2D;

 /**
 * Class that stores the location of islands
 * @author Mia Sabin (mis44)
 * @date (16/04/2022)
 * @version 1.0
 */

public class Island extends Location{
    private Point2D[] location;

    /**
    *constructor for Island
     *
     */


    public Island(String name, Point2D[] location) {
        super(name);
        this.location = location;
    }

    /**
     * Gets location
     * @return location
     */

    public Point2D[] getLocation() {
        return location;
    }

    /**
     * Sets crewCards that the island has
     */

    public void setLocation(Point2D[] location) {
        this.location = location;
    }
}