package uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.exceptions.specific;

/**
 * Used to construct `LodisClassMismatchException`
 *
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * @version 22.05.02
 * lodis.common.exceptions.specific.LodisClassMismatchException.java 22.05.02 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
public class LodisClassMismatchException extends Exception {
    /**
     * This is used when there's an unknown error with something to do with database interaction.
     */
    public LodisClassMismatchException(ClassNotFoundException classNotFoundException) {
        super(classNotFoundException);
    }
}
