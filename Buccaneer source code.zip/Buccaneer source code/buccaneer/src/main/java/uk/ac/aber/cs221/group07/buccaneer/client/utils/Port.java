/*
 * @(#) Port.java 1.0 | 2022/05/06 *
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved. *
 */


// packages
package uk.ac.aber.cs221.group07.buccaneer.client.utils;

import javafx.geometry.Point2D;

import java.util.ArrayList;
/**
 * A class that retrieves and sets data for the ports in the game.
 * @author Mia Sabin (mis77)
 * @date 25/04/2022
 * @version 1.0
 */

public class Port extends Location{
    private Point2D location;
    private boolean tradable;
    private int turnOrder;
    public Port(String name, Point2D location,  boolean tradable) {
        super(name);
        this.location = location;
        this.tradable = tradable;
    }
    /**
     * Constructor for the Port class
     * @param name holds the name of the port.
     * @param location holds the location of the port on the board.
     * @param tradable holds if the port is able to be traded at.
     * @param turnOrder holds the int of where the port places in the order of turns
     */
    public Port(String name, Point2D location, boolean tradable, int turnOrder) {
        super(name);
        this.location = location;
        this.tradable = tradable;
        this.turnOrder = turnOrder;
    }

    /**
     * This method retrieves the turn order of the ports when it is called.
     * @return turnorder
     */
    public int getTurnOrder() {
        return turnOrder;
    }

    /**
     *  This method sets the turn under of a port by changing the int
     * @param turnOrder - Int that identifies the ports position
     */
    public void setTurnOrder(int turnOrder) {
        this.turnOrder = turnOrder;
    }

    /**
     * This method retrieves a boolean to tell if the port can be traded at
     * @return tradable
     */

    public boolean isTradable() {
        return tradable;
    }

    /**
     * This method sets whether the port can be traded at on the gamboard.
     * @param tradable
     */

    public void setTradable(boolean tradable) {
        this.tradable = tradable;
    }

    /**
     * This method gets the locaiton of the port and returns it.
     * @return location
     */

    public Point2D getLocation() {
        return  this.location;
    }

    /**
     * This method sets the location for the port on the gameboard.
     * @param location
     */

    public void setLocation(Point2D location) {
        this.location = location;
    }
}
