/*
 * @(#) GameWorld.java 1.0 | 2022/05/06 *
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved. *
 */
package uk.ac.aber.cs221.group07.buccaneer.client.utils;

import javafx.event.ActionEvent;
import javafx.geometry.Point2D;
import javafx.scene.paint.Color;

import java.util.*;

/**
 * @author Julia Drozdz [jud28]
 * @version 1.0 - released.
 * GameWorld manages and initializes all the game data for the BoardController to use.
 * @see uk.ac.aber.cs221.group07.buccaneer.client.controllers.BoardController
 * @see TreasureManager
 * @see CrewCardManager
 * @see #initialize()
 */
public class GameWorld {
    /**
     * This constant is used to shift the islands vertically by 14.
     * Since grid in JavaFX count from the top-left corner
     * and buccaneer counts from the bottom-left, a vertical shift is necessary
     */
    public static final int GRID_SHIFT_AMOUNT = 14;
    private TreasureManager treasureManager;
    private CrewCardManager crewCardManager;
    private ChanceCardManager chanceCardManager;
    private Island[] islands = {
            new Island("Flat", new Point2D[]{new Point2D(1, 15 - GRID_SHIFT_AMOUNT), new Point2D(3, 18 - GRID_SHIFT_AMOUNT)}),
            new Island("Pirate", new Point2D[]{new Point2D(16, 1 + GRID_SHIFT_AMOUNT), new Point2D(18, 4 + GRID_SHIFT_AMOUNT)}),
            new Island("Treasure", new Point2D[]{new Point2D(8, 8), new Point2D(11, 11)}),
    };
    private Map<String, Island> islandsMap;
    private Port[] ports = {
            new Port("Venice", new Point2D(0, 13), true),
            new Port("London", new Point2D(0, 6), false, 0),
            new Port("Cadiz", new Point2D(13, 0), false, 3),
            new Port("Amsterdam", new Point2D(19, 6), true),
            new Port("Marseilles", new Point2D(19, 13), false, 2),
            new Port("Genoa", new Point2D(6, 19), false, 1),
    };
    private Player[] players = {
            new Player(Color.BLUEVIOLET),
            new Player(Color.ORANGE),
            new Player(Color.CORNFLOWERBLUE),
            new Player(Color.YELLOW),
    };
    String[] names;

    /**
     * Constructor for the GameWorld initiates players with the names passed from the SettingUsernames screen,
     * then it calls the #initialize() function.
     *
     * @param names - names of the players that were set in the SettingUsernames screen
     * @see uk.ac.aber.cs221.group07.buccaneer.client.controllers.SettingUsernameController#goToBoard(ActionEvent)
     */
    public GameWorld(String[] names) {
        this.names = names;
        this.initialize();
    }

    /**
     * Constructor for restoring the data from the database.
     */
    public GameWorld() {
        restore();
    }

    /**
     *  This method initializes manager for treasures, crew cards and chance cards in the game.
     *  Calls all initialization function for the game objects.
     */
    public void initialize() {
        initIslandsMap();
        treasureManager = new TreasureManager();
        treasureManager.initialize();
        crewCardManager = new CrewCardManager();
        crewCardManager.initialize();
        chanceCardManager = new ChanceCardManager();
        chanceCardManager.initialize();
        initializePlayers();
        initializeIslands();
        initializeTradingPorts();
        assignRemainingCards();
    }

    /**
     * Initializes a HashMap with the islands for telling the islands apart
     * The name of the islands is the key by which an island's data can be accessed.
     */
    private void initIslandsMap() {
        islandsMap = new HashMap<>();
        for (Island island : islands) {
            islandsMap.put(island.getName(), island);
        }
    }

    /**
     * Initialize the cards and treasures for islands. Treasure island is assigned all the chance cards and
     * it also should not get treasures at this point.
     * @see #assignRemainingCards()
     */
    public void initializeIslands() {
        for (Island island : islands) {
            if (island.getName() != "Treasure") {
                for (int j = 0; j < 2; j++) {
                    island.getCrewCards().add(crewCardManager.getRandom());
                    island.getTreasures().add(treasureManager.getRandomTreasure());
                }
            }
            if (island.getName() == "Treasure") {
                while (!chanceCardManager.isChanceCardsEmpty()) {
                    island.getChanceCards().add(chanceCardManager.getRandom());
                }
            }
        }
    }

    /**
     * Assigns the remaining cards to Treasure Islands and the remaining crew cards to Pirate
     */
    public void assignRemainingCards() {
        while (islandsMap.get("Treasure").getTreasures().size() < 5) {
            islandsMap.get("Treasure").treasures.add(treasureManager.getRandomTreasure());
        }
        while (islandsMap.get("Pirate").getCrewCards().size() < 5) {
            islandsMap.get("Pirate").crewCards.add(crewCardManager.getRandom());
        }
    }

    /**
     * Initializes the trading ports with treasures and crew cards
     */
    public void initializeTradingPorts() {
        for (Port port : ports) {
            if (port.isTradable()) {
                for (int j = 0; j < 2; j++) {
                    port.getTreasures().add(treasureManager.getRandomTreasure());
                    port.getCrewCards().add(crewCardManager.getRandom());
                }
            }
        }
    }

    /**
     * Initializes players with random ports and 5 crew cards
     */
    public void initializePlayers() {
        List<Port> portsList = new ArrayList<>();
        List<Port> tradablePorts = new ArrayList<>();
        for (Port port : ports) {
            if (port.isTradable()) {
                tradablePorts.add(port);
            } else {
                portsList.add(port);
            }
        }
        Collections.shuffle(portsList);

        Player playersTemp[] = new Player[4];

        for (int i = 0; i < 4; i++) {
            players[i].setName(names[i]);
            players[i].setHomePort(portsList.get(i));
            // Adding crew cards to player
            for (int j = 0; j < 5; j++) {
                players[i].getInventory().getCrewCards().add(crewCardManager.getRandom());
            }
            players[i].setMovesRemaining();
            int index = players[i].getHomePort().getTurnOrder();
            playersTemp[index] = players[i];
        }
        players = playersTemp;
        portsList.addAll(tradablePorts);
        portsList.toArray(ports);
    }


    /**
     * Get the game world islands
     *
     * @return islands
     */
    public Island[] getIslands() {
        return islands;
    }

    /**
     * Get the game world ports
     *
     * @return ports
     */
    public Port[] getPorts() {
        return ports;
    }

    /**
     * Get the game world players
     *
     * @return players
     */
    public Player[] getPlayers() {
        return players;
    }

    /**
     * Get the names of the game world players. This function is used when initializing the game screen
     * after trading.
     *
     * @return names -  names of the playrrs
     */
    public String[] getNames() {
        return names;
    }

    /**
     * Updates an existing game world with new values for islands, players and ports.
     *
     * @param islands
     * @param ports
     * @param players
     */
    public void updateGameWorld(Island[] islands, Port[] ports, Player[] players) {
        this.islands = islands;
        this.players = players;
        this.ports = ports;
    }

    /**
     * Return the map which stores islands
     *
     * @return islandsMap
     */
    public Map<String, Island> getIslandsMap() {
        return islandsMap;
    }

    /**
     * Saves all the objects to the database
     */
    public void save() {
    }

    /**
     * Loads the initial data from the database
     */
    public void load() {
    }

    /**
     * Restore the game world data from the previous fame
     */
    public void restore() {
    }

    /////////////////// TESTING //////////////////////
//    public static void main(String[] args) {
//        String[] names = new String[]{"Jack", "Zoe", "Ann", "Georgia"};
//        GameWorld gameWorld = new GameWorld(names);
//    }

//    public void testTakeTreasure() {
//        players[0].getInventory().getTreasures().add(new Treasure(TreasureType.DIAMOND));
//        Treasure taken = players[0].getInventory().takeTreasure();
//        System.out.println(taken);
//    }

//    public void testTakeCrewCards() {
//        System.out.println(players[0].getInventory().getCrewCards());
//        ArrayList<CrewCard> takenCrewCards = players[0].getInventory().takeCrewCards();
//
//        System.out.println(takenCrewCards);
//    }
}
