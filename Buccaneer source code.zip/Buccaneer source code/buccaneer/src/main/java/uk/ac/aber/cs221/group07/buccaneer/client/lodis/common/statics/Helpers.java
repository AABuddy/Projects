package uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.statics;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import uk.ac.aber.cs221.group07.buccaneer.client.lodis.Lodis;
import uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.exceptions.specific.LodisDatabaseIOException;
import uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.exceptions.specific.LodisFileIOException;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;
import java.util.UUID;

/**
 *
 * @author Cerys Amber Skye Lewis
 * @author cel24@aber.ac.uk
 * @version 22.05.02


/**
 * This class contains various helper operations that Lodis utilises.
 *
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * @version 22.05.02
 * lodis.common.statics.Helpers.java 22.05.02 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
public class Helpers {
    /**
     * This is used for converting an instance of ResultSet to a String for easy reading.
     *
     * @param resultSet the ResultSet instance to parse
     * @param columns   the names of the columns that you want to include in the outputted String
     * @return the given ResultSet as a String
     */
    public static String resultSetToString(ResultSet resultSet, String... columns) throws LodisDatabaseIOException {
        assert resultSet != null;
        assert columns != null;

        StringBuilder stringBuilder = new StringBuilder();

        try {
            while (resultSet.next())
                for (String column : columns)
                    stringBuilder.append(resultSet.getString(column)).append(Objects.equals(column, columns[columns.length - 1]) ? "\n" : " ");
        } catch (SQLException ex) {
            throw new LodisDatabaseIOException(ex);
        }

        return stringBuilder.toString();
    }

    /**
     * Converts columnar data from a ResultSet into an array of Strings
     *
     * @param resultSet the ResultSet to operate on
     * @param column    the column to take data from
     * @return a list of Strings
     */
    public static String[] resultSetColumnToArray(ResultSet resultSet, String column) throws LodisDatabaseIOException {
        assert resultSet != null;

        ArrayList<String> tempList = new ArrayList<>();

        try {
            while (resultSet.next()) tempList.add(resultSet.getString(column));
        } catch (SQLException ex) {
            throw new LodisDatabaseIOException(ex);
        }

        String[] returnList = new String[tempList.size()];
        for (int i = 0; i < tempList.size(); i++) returnList[i] = tempList.get(i);

        return returnList;
    }

    /**
     * Used for turning a GUID into a valid full file path for data IO operations
     *
     * @param lodis the Lodis instance in use for this operation
     * @param GUID  the dump file identifier
     * @return a valid file path
     */
    public static String generateFilePath(Lodis lodis, UUID GUID) {
        return lodis.getVariableChassis().getRootFileLocation() + "/" + GUID.toString() + ".dmp";
    }


    /**
     * Writes the given object into a file named with the given GUID.
     *
     * @param lodis         the Lodis instance that will be used -- this method will pull variables from it for working out the file path
     * @param objectToStore the actual object to be stored
     * @param GUID          the GUID that will be used to name the file
     */
    public static void writeFileToVirtualDatabaseDirectory(Lodis lodis, String objectToStore, UUID GUID) throws LodisFileIOException {
        try {
            new File(generateFilePath(lodis, GUID)).createNewFile();
            FileWriter myWriter = new FileWriter(generateFilePath(lodis, GUID));
            myWriter.write(objectToStore);
            myWriter.close();
        } catch (IOException ex) {
            throw new LodisFileIOException(ex);
        }
    }

    /**
     * Reads from a dump file using the given GUID
     *
     * @param lodis the Lodis instance that will be used -- this method will pull variables from it for working out the file path
     * @param GUID  the GUID that is used in the name of the file
     * @return the contents of the file
     */
    public static String readFileFromVirtualDatabaseDirectory(Lodis lodis, UUID GUID) throws LodisFileIOException {
        try {
            Scanner scanner = new Scanner(new File(generateFilePath(lodis, GUID)));
            StringBuilder stringBuilder = new StringBuilder();
            while (scanner.hasNextLine())
                stringBuilder.append(scanner.nextLine());
            scanner.close();
            return stringBuilder.toString();
        } catch (IOException ex) {
            throw new LodisFileIOException(ex);
        }
    }


    /**
     * Used for adding and removing GUIDs from the internal list of dump files
     *
     * @param lodis     the Lodis instance to operate on
     * @param GUID      the GUID to operate
     * @param addToList set to `true` if you want to *add* this GUID to the list, and set to `false` if you want to *remove* this GUID from the list
     * @return number of rows affected, should be one for successful operation!
     */
    public static Integer manageDumpFileList(Lodis lodis, UUID GUID, boolean addToList) throws LodisFileIOException, LodisDatabaseIOException {
        ArrayList<String> dumpFileList = new Gson().fromJson(
                lodis.getSetting("DumpFiles"),
                new TypeToken<ArrayList<String>>() {
                }.getType()
        );

        if (dumpFileList == null)
            dumpFileList = new ArrayList<>();

        if (addToList)
            dumpFileList.add(String.valueOf(GUID));
        else
            dumpFileList.remove(String.valueOf(GUID));

        return lodis.updateSetting("DumpFiles", dumpFileList);
    }

    /**
     * Takes a path of a resource file, reads it, turns it into a String, then returns that String
     *
     * @param path the path of the resource file
     * @return the contents of the target resource file
     */
    public static String resourceFileToString(String path) throws LodisFileIOException {
        StringBuilder stringBuilder = new StringBuilder();
        BufferedReader bufferedReader = new BufferedReader(
                new InputStreamReader(
                        Objects.requireNonNull(Lodis.class.getResourceAsStream(path)),
                        StandardCharsets.UTF_8
                )
        );
        try {
            for (String temp; (temp = bufferedReader.readLine()) != null; )
                stringBuilder.append(temp).append("\n");
        } catch (IOException ex) {
            throw new LodisFileIOException(ex);
        }
        return stringBuilder.toString();
    }
}
