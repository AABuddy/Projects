/*
 * @(#) Card.java 1.0 | 25/04/2022 *
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved. *
 */

package uk.ac.aber.cs221.group07.buccaneer.client.utils;

/**
* @author Jennifer Billingsley (jeb69)
* @date (25/04/2022)
* @version 1.0 | This is the class that deals with any cards within Buccaneer including both
 * Chance and Crew cards, Released.
*/
public abstract class Card {
    Integer id;
    String text;
    String name;

    /**
     * Constructor for card class.
     *
     * @param text The text stored within the Card.
     * @param name The name of the card.
     * @param id The ID of the card.
     */
    public Card (String text, String name, Integer id){
        this.id = id;
        this.text = text;
        this.name = name;

    }

    /**
     *  Empty constructor for card.
     */
    public Card() {
    }

    /**
     *
     * @return The cards ID.
     */
    public Integer getId() {
        return id;
    }

    /**
     *
     * @return The text stored for the card.
     */
    public String getText() {
        return text;
    }

    /**
     *
     * @param id Sets the ID for the card.
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     *
     * @param text Sets the text stored for the card.
     */
    public void setText(String text) {
        this.text = text;
    }
}



