package uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.statics;

import uk.ac.aber.cs221.group07.buccaneer.client.lodis.Lodis;
import uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.chassis.Query;
import uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.exceptions.specific.LodisDatabaseIOException;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * This class contains various operations to aid in CRUD (Create Read Update Destroy) operations.
 *
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * @version 22.05.02
 * lodis.common.statics.CRUD.java 22.05.02 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
public class CRUD {
    /**
     * for reading data from the database (for reading, see UPDATE)
     *
     * @param lodis the Lodis instance that will be used
     * @param query the QueryChassis to work with
     * @return an object, whatever is returned from the SQL query
     */
    public static ResultSet read(Lodis lodis, Query query) throws LodisDatabaseIOException {
        lodis.connect();
        PreparedStatement preparedStatement = query.createPreparedStatement(lodis.getVariableChassis().getSqliteConnection());
        try {
            return preparedStatement.executeQuery();
        } catch (SQLException ex) {
            throw new LodisDatabaseIOException(ex);
        }
    }

    /**
     * !!CRITICAL!!
     * this is used for disconnecting from the SQLite instance after usage so another thread can read from the database
     * !!CRITICAL!!
     *
     * @param lodis the Lodis instance that will be used
     */
    public static void afterRead(Lodis lodis) throws LodisDatabaseIOException {
        lodis.disconnect();
    }

    /**
     * for writing data to the database (for reading, see READ)
     *
     * @param lodis the Lodis instance that will be used
     * @param query the QueryChassis to work with
     * @return the number of rows affected by the operation
     */
    public static Integer update(Lodis lodis, Query query) throws LodisDatabaseIOException {
        lodis.connect();
        int effectedRows;
        PreparedStatement preparedStatement = query.createPreparedStatement(lodis.getVariableChassis().getSqliteConnection());
        try {
            effectedRows = preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            throw new LodisDatabaseIOException(ex);
        }
        lodis.disconnect();
        return effectedRows;
    }
}
