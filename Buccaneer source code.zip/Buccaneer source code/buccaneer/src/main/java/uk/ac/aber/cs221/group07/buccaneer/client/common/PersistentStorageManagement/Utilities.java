package uk.ac.aber.cs221.group07.buccaneer.client.common.PersistentStorageManagement;

import static uk.ac.aber.cs221.group07.buccaneer.client.common.PersistentStorageManagement.Key.CORE__SHOULD_RESTORE;

public class Utilities {
    public static boolean GetShouldRestore() {
        return false;
        // return Administrator.GetFromStore(CORE__SHOULD_RESTORE, false);
    }
    public static void SetShouldRestore(boolean value) {
        Administrator.PutIntoStore(CORE__SHOULD_RESTORE, value);
    }
}
