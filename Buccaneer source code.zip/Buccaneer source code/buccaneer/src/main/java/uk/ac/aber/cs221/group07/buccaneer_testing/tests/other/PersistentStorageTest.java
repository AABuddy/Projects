package uk.ac.aber.cs221.group07.buccaneer_testing.tests.other;

import javafx.scene.paint.Color;
import org.apache.commons.io.FileUtils;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;
import uk.ac.aber.cs221.group07.buccaneer.client.lodis.Lodis;
import uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.chassis.KeyValuePair;
import uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.chassis.Query;
import uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.exceptions.specific.*;
import uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.statics.CRUD;
import uk.ac.aber.cs221.group07.buccaneer.client.utils.Player;

import java.io.File;
import java.io.IOException;
import java.util.*;

import static org.junit.Assert.assertThrows;

/**
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * @version 22.05.06
 * buccaneer_testing.tests.other.PersistentStorageTest.java 22.05.06 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class PersistentStorageTest {
    Map<String, Object> testData = new HashMap<>() {{
        put("SHORT_STRING.KEY", "test_1");
        put("SHORT_STRING.VALUE", "nya~");
        put("SHORT_STRING.VALUE.UPDATED", "nya~nya~");

        put("LONG_STRING.KEY", "test_2");
        put("LONG_STRING.VALUE", new String(new char[10000000]).replace("\0", "/"));
        put("LONG_STRING.VALUE.UPDATED", new String(new char[10000000]).replace("\0", "\\/"));

        put("MULTI_OBJECT.ITEM_1.KEY", "test_3");
        put("MULTI_OBJECT.ITEM_1.VALUE", "test_3");
        put("MULTI_OBJECT.ITEM_2.KEY", "test_4");
        put("MULTI_OBJECT.ITEM_2.VALUE", "test_4");
        put("MULTI_OBJECT.ITEM_3.KEY", "test_5");
        put("MULTI_OBJECT.ITEM_3.VALUE", "test_5");
        put("MULTI_OBJECT.ITEM_4.KEY", "test_6");
        put("MULTI_OBJECT.ITEM_4.VALUE", "test_6");

        put("SUPER_LONG_STRING.KEY", "test_7");
        // put("SUPER_LONG_STRING.VALUE", new String(new char[1000000000]).replace("\0", "/"));

        put("COMPLEX_OBJECT.KEY", "test_8");
        put("COMPLEX_OBJECT.VALUE", new Player(Color.BLACK));
    }};
    private Lodis lodisTest;

    @Test
    @Order(1)
    public void initialiseLodis() throws LodisFileIOException, LodisDatabaseIOException {
        lodisTest = new Lodis();
    }

    @Test
    @Order(2)
    public void wipeAllData() throws LodisFileIOException, LodisDatabaseIOException {
        lodisTest.deleteAll();
    }


    @Test
    @Order(3)
    public void storeShortString() throws LodisFileIOException, LodisDatabaseIOException, LodisKeyAlreadyExistsException {
        Assertions.assertEquals(
                lodisTest.store((String) testData.get("SHORT_STRING.KEY"), testData.get("SHORT_STRING.VALUE")),
                1
        );
    }

    @Test
    @Order(4)
    public void storeShortStringAgain() {
        Exception exception = assertThrows(LodisKeyAlreadyExistsException.class, () -> lodisTest.store((String) testData.get("SHORT_STRING.KEY"), testData.get("SHORT_STRING.VALUE")));
        Assertions.assertTrue(exception.getMessage().contains(new LodisKeyAlreadyExistsException((String) testData.get("SHORT_STRING.KEY")).getMessage()));
    }

    @Test
    @Order(5)
    public void retrieveShortString() throws LodisFileIOException, LodisDatabaseIOException, LodisKeyDoesNotExistException, LodisClassMismatchException {
        Assertions.assertEquals(
                lodisTest.retrieve((String) testData.get("SHORT_STRING.KEY")),
                testData.get("SHORT_STRING.VALUE")
        );
    }

    @Test
    @Order(6)
    public void updateShortString() throws LodisFileIOException, LodisDatabaseIOException, LodisKeyDoesNotExistException, LodisKeyAlreadyExistsException {
        Assertions.assertEquals(
                lodisTest.update((String) testData.get("SHORT_STRING.KEY"), testData.get("SHORT_STRING.VALUE.UPDATED")),
                1
        );
    }

    @Test
    @Order(7)
    public void retrieveUpdatedShortString() throws LodisFileIOException, LodisDatabaseIOException, LodisKeyDoesNotExistException, LodisClassMismatchException {
        Assertions.assertEquals(
                lodisTest.retrieve((String) testData.get("SHORT_STRING.KEY")),
                testData.get("SHORT_STRING.VALUE.UPDATED")
        );
    }


    @Test
    @Order(8)
    public void storeLongString() throws LodisFileIOException, LodisDatabaseIOException, LodisKeyAlreadyExistsException {
        Assertions.assertEquals(
                lodisTest.store((String) testData.get("LONG_STRING.KEY"), testData.get("LONG_STRING.VALUE")),
                1
        );
    }

    @Test
    @Order(9)
    public void storeLongStringAgain() {
        Exception exception = assertThrows(LodisKeyAlreadyExistsException.class, () -> lodisTest.store((String) testData.get("LONG_STRING.KEY"), testData.get("LONG_STRING.VALUE")));
        Assertions.assertTrue(exception.getMessage().contains(new LodisKeyAlreadyExistsException((String) testData.get("LONG_STRING.KEY")).getMessage()));
    }

    @Test
    @Order(10)
    public void retrieveLongString() throws LodisFileIOException, LodisDatabaseIOException, LodisKeyDoesNotExistException, LodisClassMismatchException {
        Assertions.assertEquals(
                lodisTest.retrieve((String) testData.get("LONG_STRING.KEY")),
                testData.get("LONG_STRING.VALUE")
        );
    }

    @Test
    @Order(11)
    public void updateLongString() throws LodisFileIOException, LodisDatabaseIOException, LodisKeyDoesNotExistException, LodisKeyAlreadyExistsException {
        Assertions.assertEquals(
                lodisTest.update((String) testData.get("LONG_STRING.KEY"), testData.get("LONG_STRING.VALUE.UPDATED")),
                1
        );
    }

    @Test
    @Order(12)
    public void retrieveUpdatedLongString() throws LodisFileIOException, LodisDatabaseIOException, LodisKeyDoesNotExistException, LodisClassMismatchException {
        Assertions.assertEquals(
                lodisTest.retrieve((String) testData.get("LONG_STRING.KEY")),
                testData.get("LONG_STRING.VALUE.UPDATED")
        );
    }

    @Test
    @Order(13)
    public void storeMultipleObjects() throws LodisFileIOException, LodisDatabaseIOException, LodisKeyAlreadyExistsException {
        Assertions.assertEquals(
                lodisTest.store(
                        new KeyValuePair((String) testData.get("MULTI_OBJECT.ITEM_1.KEY"), testData.get("MULTI_OBJECT.ITEM_1.VALUE")),
                        new KeyValuePair((String) testData.get("MULTI_OBJECT.ITEM_2.KEY"), testData.get("MULTI_OBJECT.ITEM_2.VALUE")),
                        new KeyValuePair((String) testData.get("MULTI_OBJECT.ITEM_3.KEY"), testData.get("MULTI_OBJECT.ITEM_3.VALUE")),
                        new KeyValuePair((String) testData.get("MULTI_OBJECT.ITEM_4.KEY"), testData.get("MULTI_OBJECT.ITEM_4.VALUE"))
                ),
                4
        );
    }

    @Test
    @Order(14)
    public void retrieveMultipleObjects() throws LodisFileIOException, LodisDatabaseIOException, LodisKeyDoesNotExistException, LodisClassMismatchException {
        Assertions.assertEquals(
                lodisTest.retrieve((String) testData.get("MULTI_OBJECT.ITEM_1.KEY")),
                testData.get("MULTI_OBJECT.ITEM_1.VALUE")
        );
        Assertions.assertEquals(
                lodisTest.retrieve((String) testData.get("MULTI_OBJECT.ITEM_2.KEY")),
                testData.get("MULTI_OBJECT.ITEM_2.VALUE")
        );
        Assertions.assertEquals(
                lodisTest.retrieve((String) testData.get("MULTI_OBJECT.ITEM_3.KEY")),
                testData.get("MULTI_OBJECT.ITEM_3.VALUE")
        );
        Assertions.assertEquals(
                lodisTest.retrieve((String) testData.get("MULTI_OBJECT.ITEM_4.KEY")),
                testData.get("MULTI_OBJECT.ITEM_4.VALUE")
        );
    }

    @Test
    @Order(15)
    public void countKeys() throws LodisFileIOException, LodisDatabaseIOException {
        Assertions.assertEquals(
                lodisTest.countAllObjects(),
                6
        );
    }

    @Test
    @Order(16)
    public void verifyKeys() throws LodisFileIOException, LodisDatabaseIOException {
        Assertions.assertEquals(
                Arrays.stream(lodisTest.getAllKeys()).toList(),
                List.of(
                        testData.get("SHORT_STRING.KEY"),
                        testData.get("LONG_STRING.KEY"),
                        testData.get("MULTI_OBJECT.ITEM_1.KEY"),
                        testData.get("MULTI_OBJECT.ITEM_2.KEY"),
                        testData.get("MULTI_OBJECT.ITEM_3.KEY"),
                        testData.get("MULTI_OBJECT.ITEM_4.KEY")
                )
        );
    }

    @Test
    @Order(17)
    public void destroyAll() throws LodisFileIOException, LodisDatabaseIOException {
        Assertions.assertEquals(
                lodisTest.deleteAll(),
                6
        );
    }

    @Test
    @Order(18)
    public void createSuperLongString() throws LodisFileIOException, LodisDatabaseIOException, LodisKeyAlreadyExistsException {
        Assertions.assertEquals(
                lodisTest.store(
                        new KeyValuePair((String) testData.get("SUPER_LONG_STRING.KEY"), new String(new char[1000000000]).replace("\0", "/"))
                ),
                1
        );
    }

    @Test
    @Order(19)
    public void retrieveSuperLongString() throws LodisFileIOException, LodisDatabaseIOException, LodisKeyDoesNotExistException, LodisClassMismatchException {
        Assertions.assertEquals(
                lodisTest.retrieve((String) testData.get("SUPER_LONG_STRING.KEY")),
                new String(new char[1000000000]).replace("\0", "/")
        );
    }

    @Test
    @Order(20)
    public void deleteAllDumpFiles() throws IOException, LodisFileIOException, LodisDatabaseIOException {
        for (File file : Objects.requireNonNull(new File(new Lodis().getVariableChassis().getRootFileLocation()).listFiles()))
            if (file.getName().endsWith(".dmp"))
                FileUtils.forceDelete(file);
    }

    @Test
    @Order(21)
    public void destroyReferencesToNonExistentDumpFiles() throws LodisFileIOException, LodisDatabaseIOException {
        Assertions.assertEquals(
                lodisTest.destroyReferencesToNonExistentDumpFiles(),
                1
        );
    }

    @Test
    @Order(22)
    public void storeLongStringAgainButForADifferentTest() throws LodisFileIOException, LodisDatabaseIOException, LodisKeyAlreadyExistsException {
        Assertions.assertEquals(
                lodisTest.store(
                        new KeyValuePair((String) testData.get("LONG_STRING.KEY"), testData.get("LONG_STRING.VALUE"))
                ),
                1
        );
    }

    @Test
    @Order(23)
    public void destroyAllDumpFileReferences() throws LodisDatabaseIOException {
        CRUD.update(lodisTest, new Query("UPDATE `Settings` SET VALUE=\"[]\" WHERE \"Setting\" LIKE \"DumpFiles\";"));
        CRUD.update(lodisTest, new Query("DELETE FROM PayloadStore;"));
    }

    @Test
    @Order(24)
    public void destroyUnreferencedDumpFiles() throws LodisFileIOException, LodisDatabaseIOException {
        Assertions.assertEquals(
                lodisTest.destroyUnreferencedDumpFiles(),
                1
        );
    }
}
