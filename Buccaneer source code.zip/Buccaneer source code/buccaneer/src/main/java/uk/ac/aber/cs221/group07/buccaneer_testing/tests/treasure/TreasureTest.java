package uk.ac.aber.cs221.group07.buccaneer_testing.tests.treasure;

import org.junit.Test;
import uk.ac.aber.cs221.group07.buccaneer.client.utils.Treasure;
import uk.ac.aber.cs221.group07.buccaneer.client.utils.TreasureType;

import static org.junit.Assert.assertEquals;

/**
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * @version 22.05.06
 * buccaneer_testing.tests.treasure.TreasureTest.java 22.05.06 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
public class TreasureTest {
    Treasure testTreasureBarrelOfRum = new Treasure(TreasureType.BARRELOFRUM);
    Treasure testTreasureDiamond = new Treasure(TreasureType.DIAMOND);
    Treasure testTreasureGoldBar = new Treasure(TreasureType.GOLDBAR);
    Treasure testTreasurePearl = new Treasure(TreasureType.PEARL);
    Treasure testTreasureRuby = new Treasure(TreasureType.RUBY);

    @Test
    public void Types() {
        assertEquals(TreasureType.BARRELOFRUM, testTreasureBarrelOfRum.getType());
        assertEquals(TreasureType.DIAMOND, testTreasureDiamond.getType());
        assertEquals(TreasureType.GOLDBAR, testTreasureGoldBar.getType());
        assertEquals(TreasureType.PEARL, testTreasurePearl.getType());
        assertEquals(TreasureType.RUBY, testTreasureRuby.getType());
    }

    @Test
    public void Values() {
        assertEquals(2, testTreasureBarrelOfRum.getValue());
        assertEquals(5, testTreasureDiamond.getValue());
        assertEquals(4, testTreasureGoldBar.getValue());
        assertEquals(3, testTreasurePearl.getValue());
        assertEquals(5, testTreasureRuby.getValue());
    }
}
