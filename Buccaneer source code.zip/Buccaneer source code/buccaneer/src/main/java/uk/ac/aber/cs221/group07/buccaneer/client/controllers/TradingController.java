package uk.ac.aber.cs221.group07.buccaneer.client.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.GridPane;

import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import uk.ac.aber.cs221.group07.buccaneer.client.Main;
import uk.ac.aber.cs221.group07.buccaneer.client.utils.*;

import java.io.IOException;

import java.util.ArrayList;

/*
* @(#) TradingController.java 1.0 | 2022/05/06 
* Copyright (c) 2021 Aberystwyth University.
* All rights reserved. 
*
*TradingController - Manages the trading screens functionality and UI
* @author Daniel Slater[das94]
* @author Julia Drozdz [jud28]
* @version 1.0 | Released
* @see @BoardController */

public class TradingController {
    private Stage stage;
    private GameWorld gameWorld;
    private Player player;
    private Port port;
    private int playerTradeValue = 0;
    private int portTradeValue = 0;
    public Player getPlayer() {
        return player;
    }
    public void setPlayer(Player player) {
        this.player = player;
    }
    @FXML
    private Button btTreasure1;

    @FXML
    private Button btTreasure2;
    @FXML
    private Button btPortTreasure1;
    @FXML
    private Button btPortTreasure2;
    @FXML
    private Button btPortTreasure3;
    @FXML
    private Button btPortTreasure4;
    @FXML
    private Button btPortTreasure5;
    @FXML
    private Button btPortTreasure6;
    @FXML
    private Button btPlayerCard1;
    @FXML
    private Button btPlayerCard2;
    @FXML
    private Button btPlayerCard3;
    @FXML
    private Button btPlayerCard4;
    @FXML
    private Button btPlayerCard5;
    @FXML
    private Button btPlayerCard6;

    @FXML
    private Button btPortCard1;
    @FXML
    private Button btPortCard2;
    @FXML
    private Button btPortCard3;
    @FXML
    private Button btPortCard4;
    @FXML
    private Button btPortCard5;
    @FXML
    private Button btPortCard6;


    @FXML
    private GridPane gpPortTreasure;

    @FXML
    private GridPane playerCards;

    @FXML
    private GridPane portCards;

    @FXML
    private Label lblPortValue;

    @FXML
    private Label lblPlayerValue;

    @FXML
    private GridPane gpPlayerOffer;

    @FXML
    private GridPane gpPortOffer;

    @FXML
    private GridPane gpPlayerTreasure;


    private ArrayList<Treasure> playerTradeTreasure = new ArrayList<>();
    private ArrayList<CrewCard> playerCardsArray = new ArrayList<>();
    private ArrayList<ImageView> playerCardsArrayImages = new ArrayList<>();
    private ArrayList<Treasure> playerTreasureArray = new ArrayList<>(2);
    private ArrayList<ImageView> playerTreasureArrayImages = new ArrayList<>(2);
    private ArrayList<CrewCard> playerTradeCards = new ArrayList<>(6);


    private ArrayList<CrewCard> portCardsArray = new ArrayList<>(6);
    private ArrayList<CrewCard> portTradeCards = new ArrayList<>(6);
    private ArrayList<ImageView> portCardsArrayImages = new ArrayList<>(6);
    private ArrayList<Treasure> portTreasureArray = new ArrayList<>(6);
    private ArrayList<ImageView> portTreasureArrayImages = new ArrayList<>(6);
    private ArrayList<Treasure> portTradeTreasure = new ArrayList<>(6);


    /*
    *
    *@param event ping from the button clicked
    */
    @FXML
    void onConfirm(ActionEvent event) {
        if (playerTradeValue == portTradeValue && portTradeValue != 0) {//checks trade values are equal and not 0
            System.out.println("Confirm Trade");
            for (int x = 0; x < 6; x++) {//For every trade box, the code calculates what item needs to be in what inventory
                try {
                    Treasure playerTreasure = playerTradeTreasure.get(x);
                    if (playerTreasure != null) {
                        playerTreasureArray.remove(playerTreasure);
                    }
                } catch (IndexOutOfBoundsException i) {
                }
                try {
                    Treasure portTreasure = portTradeTreasure.get(x);
                    if (portTreasure != null) {
                        portTreasureArray.remove(portTreasure);
                    }
                } catch (IndexOutOfBoundsException i) {
                }
                try {
                    CrewCard playerCard = playerTradeCards.get(x);
                    if (playerCard != null) {
                        playerCardsArray.remove(playerCard);
                    }
                } catch (IndexOutOfBoundsException i) {
                }
                try {
                    CrewCard portCard = portTradeCards.get(x);
                    if (portCard != null) {
                        playerCardsArray.remove(portCard);
                    }
                } catch (IndexOutOfBoundsException i) {
                }
            }
            portTradeTreasure.addAll(playerTreasureArray);
            this.player.getInventory().setTreasures(portTradeTreasure);

            portTradeCards.addAll(playerTradeCards);
            this.player.getInventory().setCrewCards(portTradeCards);

            playerTradeTreasure.addAll(portTreasureArray);
            this.port.setTreasures(playerTradeTreasure);

            playerTradeCards.addAll(portCardsArray);
            this.port.setCrewCards(playerTradeCards);

            System.out.println("PortInventory:");
            System.out.println("Treasures: ");
            System.out.println(port.getTreasures());
            System.out.println("Cards: ");
            System.out.println(port.getCrewCards());

            System.out.println("Player Inventory:");
            System.out.println("Treasures: ");
            System.out.println(player.getInventory().getTreasures());
            System.out.println("Cards: ");
            System.out.println(player.getInventory().getCrewCards());

            saveAndQuit(event);
            //gpPlayerTreasure.getChildren().clear();
            //gpPortTreasure.getChildren().clear();
            //clearOffers();
        } else return;


    }


    /*
    *Clears all arrays and ui images and recreates them with the correct items
    *@param player the player we need to get the inventory of
    *@param port the port we need the inventory of
    *@param gameWorld the gameWorld data used
    */
    void initialise(Player player, Port port, GameWorld gameWorld) {
        this.gameWorld = gameWorld;
        this.setPlayer(player);
        this.setPort(port);
        btTreasure1.setDisable(false);
        btTreasure2.setDisable(false);

        btPortTreasure1.setDisable(false);
        btPortTreasure2.setDisable(false);
        btPortTreasure3.setDisable(false);
        btPortTreasure4.setDisable(false);
        btPortTreasure5.setDisable(false);
        btPortTreasure6.setDisable(false);

        btPlayerCard1.setDisable(false);
        btPlayerCard2.setDisable(false);
        btPlayerCard3.setDisable(false);
        btPlayerCard4.setDisable(false);
        btPlayerCard5.setDisable(false);
        btPlayerCard6.setDisable(false);

        btPortCard1.setDisable(false);
        btPortCard2.setDisable(false);
        btPortCard3.setDisable(false);
        btPortCard4.setDisable(false);
        btPortCard5.setDisable(false);
        btPortCard6.setDisable(false);

        this.playerTradeValue = 0;
        this.portTradeValue = 0;
        playerTreasureArray.clear();
        playerTradeTreasure.clear();
        playerTreasureArrayImages.clear();

        playerCards.getChildren().clear();
        playerCardsArray.clear();
        playerCardsArrayImages.clear();

        portCardsArray.clear();
        portCardsArrayImages.clear();
        portCards.getChildren().clear();

        portTreasureArray.clear();
        portTreasureArrayImages.clear();
        portTradeTreasure.clear();

        gpPlayerTreasure.getChildren().clear();
        gpPortTreasure.getChildren().clear();


        initialisePlayerTreasures();
        initialisePlayerCards();
        initialisePortTrade();
        initialisePortCards();

    }

    /*
    *Helper method that initialises the trading ports treasures
    */

    void initialisePortTrade() {
        ArrayList<Treasure> treasureCards = this.port.getTreasures();
        ArrayList<CrewCard> crewCards = port.getCrewCards();
        int index = 0;
        for (Treasure selectTreasure : treasureCards) {
            portTreasureArray.add(selectTreasure);
            Image treasureImage = null;
            switch (selectTreasure.getType()) {
                case DIAMOND:
                    treasureImage = new Image(String.valueOf(Main.class.getResource("assets/DIAMOND.jpg")));
                    break;

                case GOLDBAR:
                    treasureImage = new Image(String.valueOf(Main.class.getResource("assets/GOLDBAR.jpg")));
                    break;

                case PEARL:
                    treasureImage = new Image(String.valueOf(Main.class.getResource("assets/PEARL.jpg")));
                    break;

                case RUBY:
                    treasureImage = new Image(String.valueOf(Main.class.getResource("assets/RUBY.jpg")));
                    break;

                case BARRELOFRUM:
                    treasureImage = new Image(String.valueOf(Main.class.getResource("assets/BARRELOFRUM.jpg")));
                    break;
            }
            ImageView treasureImageView = new ImageView(treasureImage);
            portTreasureArrayImages.add(treasureImageView);

            int line = index >= 3 ? 1 : 0;
            gpPortTreasure.add(treasureImageView, index % 3, line);
            index++;
        }
        


    }


    /*
    *Helper method that initialises the player treasures
    */

    void initialisePlayerTreasures() {
        ArrayList<Treasure> treasureCards = this.player.getInventory().getTreasures();
        for (Treasure selectTreasure : treasureCards) {
            playerTreasureArray.add(selectTreasure);
            Image treasureImage = null;
            switch (selectTreasure.getType()) {
                case DIAMOND:
                    treasureImage = new Image(String.valueOf(Main.class.getResource("assets/DIAMOND.jpg")));
                    break;

                case GOLDBAR:
                    treasureImage = new Image(String.valueOf(Main.class.getResource("assets/DIAMOND.jpg")));
                    break;

                case PEARL:
                    treasureImage = new Image(String.valueOf(Main.class.getResource("assets/DIAMOND.jpg")));
                    break;

                case RUBY:
                    treasureImage = new Image(String.valueOf(Main.class.getResource("assets/DIAMOND.jpg")));
                    break;

                case BARRELOFRUM:
                    treasureImage = new Image(String.valueOf(Main.class.getResource("assets/DIAMOND.jpg")));
                    break;
            }
            ImageView treasureImageView = new ImageView(treasureImage);
            playerTreasureArrayImages.add(treasureImageView);
            gpPlayerTreasure.add(treasureImageView, gpPlayerTreasure.getChildren().size(), 0);
        }
    }

    /*
    *Helper method that initialises the player crew cards
    */

    void initialisePlayerCards() {
        ArrayList<CrewCard> crewCards = this.player.getInventory().getCrewCards();
        int index = 0;
        for (CrewCard selectCard : crewCards) {
            playerCardsArray.add(selectCard);
            Image cardImage = null;
            switch (selectCard.getValue()) {
                case 1:
                    //if (selectCard.color())
                    //treasureImage = new Image(String.valueOf(MenuController.class.getResource("Diamond JPEG.jpg")));
                    //else
                    cardImage = new Image(String.valueOf(Main.class.getResource("assets/black1.png")));
                    break;

                case 2:

                    cardImage = new Image(String.valueOf(Main.class.getResource("assets/black1.png")));
                    break;

                case 3:
                    cardImage = new Image(String.valueOf(Main.class.getResource("assets/black1.png")));

                    break;
            }
            ImageView cardImageView = new ImageView(cardImage);
            playerCardsArray.add(selectCard);
            playerCardsArrayImages.add(cardImageView);

            int line = index >= 3 ? 1 : 0;
            playerCards.add(cardImageView, index % 3, line);
            index++;
        }
    }

    /*
    *Helper method that initialises the port crew cards
    */
    void initialisePortCards() {
        ArrayList<CrewCard> crewCards = this.port.getCrewCards();
        int index = 0;
        for (CrewCard selectCard : crewCards) {
            playerCardsArray.add(selectCard);
            Image cardImage = null;
            switch (selectCard.getValue()) {
                case 1:
                    //if (selectCard.color())
                    //treasureImage = new Image(String.valueOf(MenuController.class.getResource("Diamond JPEG.jpg")));
                    //else
                    cardImage = new Image(String.valueOf(Main.class.getResource("assets/black1.png")));
                    break;

                case 2:

                    cardImage = new Image(String.valueOf(Main.class.getResource("assets/black1.png")));
                    break;

                case 3:
                    cardImage = new Image(String.valueOf(Main.class.getResource("assets/black1.png")));

                    break;
            }
            ImageView cardImageView = new ImageView(cardImage);
            portCardsArray.add(selectCard);
            portCardsArrayImages.add(cardImageView);

            int line = index >= 3 ? 1 : 0;
            portCards.add(cardImageView, index % 3, line);
            index++;

        }
    }

    /*
    *Gets the correct port being used
    *@return the port being used
    */
    public Port getPort() {
        return port;
    }
    /*
    *sets the correct port being used
    *@param port the port we are loading from
    */
    public void setPort(Port port) {
        this.port = port;
    }

     /*
    *sets the correct port being used
    *@param port the port we are loading from
    */
    @FXML
    void onCancel(ActionEvent event) throws IOException {
        //playerCards.setRowIndex(treasure, playerCards.getRowIndex(treasure) + 1);
        clearOffers();
        lblPlayerValue.setText("0");
        playerTradeValue = 0;

        lblPortValue.setText("0");
        portTradeValue = 0;

        this.initialise(this.player, this.port, this.gameWorld);
    }

    /*
    *Closes the trade window
    *@param event ping from the button clicked
    */
    void saveAndQuit(ActionEvent event) {
        goToBoard(event);
    }

    /*
    *Disabled the button clicked then runs the code to add the item to the trading offer
    *@param event ping from the button clicked
    */
    @FXML
    void onPlayerTreasure1Clicked(ActionEvent event) {
        btTreasure1.setDisable(true);
        playerTreasureClicked(0);
    }

    /*
    *Disabled the button clicked then runs the code to add the item to the trading offer
    *@param event ping from the button clicked
    */
    @FXML
    void onPlayerTreasure2Clicked(ActionEvent event) {
        btTreasure2.setDisable(true);
        playerTreasureClicked(1);
    }

    /*
    *Disabled the button clicked then runs the code to add the item to the trading offer
    *@param event ping from the button clicked
    */
    @FXML
    void onPortTreasure1Clicked(ActionEvent event) {
        btPortTreasure1.setDisable(true);
        portTreasureClicked(0);
    }

    /*
    *Disabled the button clicked then runs the code to add the item to the trading offer
    *@param event ping from the button clicked
    */
    @FXML
    void onPortTreasure2Clicked(ActionEvent event) {
        btPortTreasure2.setDisable(true);
        portTreasureClicked(1);
    }

    /*
    *Disabled the button clicked then runs the code to add the item to the trading offer
    *@param event ping from the button clicked
    */
    @FXML
    void onPortTreasure3Clicked(ActionEvent event) {
        btPortTreasure3.setDisable(true);
        portTreasureClicked(2);
    }

    /*
    *Disabled the button clicked then runs the code to add the item to the trading offer
    *@param event ping from the button clicked
    */
    @FXML
    void onPortTreasure4Clicked(ActionEvent event) {
        btPortTreasure4.setDisable(true);
        portTreasureClicked(3);
    }


    /*
    *Disabled the button clicked then runs the code to add the item to the trading offer
    *@param event ping from the button clicked
    */
    @FXML
    void onPortTreasure5Clicked(ActionEvent event) {
        btPortTreasure5.setDisable(true);
        portTreasureClicked(4);
    }

    /*
    *Disabled the button clicked then runs the code to add the item to the trading offer
    *@param event ping from the button clicked
    */
    @FXML
    void onPortTreasure6Clicked(ActionEvent event) {
        btPortTreasure6.setDisable(true);
        portTreasureClicked(5);
    }

    /*
    *Disabled the button clicked then runs the code to add the item to the trading offer
    *@param event ping from the button clicked
    */
    @FXML
    void onPortCard6Clicked(ActionEvent event) {
        btPortCard6.setDisable(true);
        portCardClicked(5);
    }

    /*
    *Disabled the button clicked then runs the code to add the item to the trading offer
    *@param event ping from the button clicked
    */
    @FXML
    void onPortCard5Clicked(ActionEvent event) {
        btPortCard5.setDisable(true);
        portCardClicked(4);

    }

    /*
    *Disabled the button clicked then runs the code to add the item to the trading offer
    *@param event ping from the button clicked
    */
    @FXML
    void onPortCard4Clicked(ActionEvent event) {
        btPortCard4.setDisable(true);
        portCardClicked(3);

    }

    /*
    *Disabled the button clicked then runs the code to add the item to the trading offer
    *@param event ping from the button clicked
    */
    @FXML
    void onPortCard3Clicked(ActionEvent event) {
        btPortCard4.setDisable(true);
        portCardClicked(2);

    }

    /*
    *Disabled the button clicked then runs the code to add the item to the trading offer
    *@param event ping from the button clicked
    */
    @FXML
    void onPortCard2Clicked(ActionEvent event) {
        btPortCard2.setDisable(true);
        portCardClicked(1);

    }

    /*
    *Disabled the button clicked then runs the code to add the item to the trading offer
    *@param event ping from the button clicked
    */
    @FXML
    void onPortCard1Clicked(ActionEvent event) {
        btPortCard1.setDisable(true);
        portCardClicked(0);


    }

    /*
    *Disabled the button clicked then runs the code to add the item to the trading offer
    *@param event ping from the button clicked
    */
    @FXML
    void onPlayerCard6Clicked(ActionEvent event) {
        btPlayerCard6.setDisable(true);
        playerCardClicked(5);
    }

    /*
    *Disabled the button clicked then runs the code to add the item to the trading offer
    *@param event ping from the button clicked
    */
    @FXML
    void onPlayerCard5Clicked(ActionEvent event) {
        btPlayerCard5.setDisable(true);
        playerCardClicked(4);
    }

    /*
    *Disabled the button clicked then runs the code to add the item to the trading offer
    *@param event ping from the button clicked
    */
    @FXML
    void onPlayerCard4Clicked(ActionEvent event) {
        btPlayerCard4.setDisable(true);
        playerCardClicked(3);
    }

    /*
    *Disabled the button clicked then runs the code to add the item to the trading offer
    *@param event ping from the button clicked
    */
    @FXML
    void onPlayerCard3Clicked(ActionEvent event) {
        btPlayerCard3.setDisable(true);
        playerCardClicked(2);
    }

    /*
    *Disabled the button clicked then runs the code to add the item to the trading offer
    *@param event ping from the button clicked
    */
    @FXML
    void onPlayerCard2Clicked(ActionEvent event) {
        btPlayerCard2.setDisable(true);
        playerCardClicked(1);

    }

    /*
    *Disabled the button clicked then runs the code to add the item to the trading offer
    *@param event ping from the button clicked
    */
    @FXML
    void onPlayerCard1Clicked(ActionEvent event) {
        btPlayerCard1.setDisable(true);
        playerCardClicked(0);


    }

    /*
    *Disabled the button clicked then runs the code to add the item to the trading offer
    *@param event ping from the button clicked
    */
    @FXML
    void onExitTradePort(ActionEvent event) {
        gpPortTreasure.getChildren().clear();
        //saveAndQuit();
        goToBoard(event);

    }
    /**
     *  Go back to the board window from the set username menu
     * @param actionEvent
     */
    public void goToBoard(ActionEvent actionEvent) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("boardScreen.fxml"));
            Parent boardViewParent = fxmlLoader.load();
            BoardController controller = fxmlLoader.getController();
            // Pass data between controllers for the scenes
            controller.resumeGame(gameWorld);

            stage = (Stage)(((Node)actionEvent.getSource()).getScene().getWindow());
            Scene scene = new Scene(boardViewParent);
            stage.setTitle("Buccaneer");
            stage.setResizable(false);
            stage.setScene(scene);
            stage.show();
        } catch(IOException e) {
            e.printStackTrace();
        }
    }

    /*
    *increases the player trade value
    *@param value the amount to add
    */
    void addToPlaterTradeValue(int value) {
        this.playerTradeValue += value;
    }

    /*
    *increases the port trade value
    *@param value the amount to add
    */
    void addToPortTradeValue(int value) {
        this.portTradeValue += value;
    }

    /*
    *Adds the player treasure data and image to the correct place
    *@param girdLocation the location of the item clicked in the trading menu
    */
    void playerTreasureClicked(int girdLocation) {
        try {
            Treasure object = playerTreasureArray.get(girdLocation);
            ImageView image = playerTreasureArrayImages.get(girdLocation);


            if (object != null && image != null) {
                playerTradeTreasure.add(object);
                addToPlaterTradeValue(object.getValue());
                String valuetext = playerTradeValue + "";
                lblPlayerValue.setText(valuetext);
                //playerTradeItemsImages.add(image);
                gpPlayerOffer.add(image, 0, gpPlayerOffer.getChildren().size());

            }
        } catch (IndexOutOfBoundsException i) {
        }
    }

    /*
    *Adds the player card data and image to the correct place
    *@param girdLocation the location of the item clicked in the trading menu
    */
    void playerCardClicked(int girdLocation) {
        try {
            CrewCard object = playerCardsArray.get(girdLocation);
            ImageView image = playerCardsArrayImages.get(girdLocation);


            if (object != null && image != null) {
                playerTradeCards.add(object);
                addToPlaterTradeValue(object.getValue());
                String valuetext = playerTradeValue + "";
                lblPlayerValue.setText(valuetext);
                //playerTradeItemsImages.add(image);
                gpPlayerOffer.add(image, 0, gpPlayerOffer.getChildren().size());

            }
        } catch (IndexOutOfBoundsException i) {
        }
    }

     /*
    *Adds the player card data and image to the correct place
    *@param girdLocation the location of the item clicked in the trading menu
    */

    void portCardClicked(int girdLocation) {
        try {
            CrewCard object = portCardsArray.get(girdLocation);
            ImageView image = portCardsArrayImages.get(girdLocation);


            if (object != null && image != null) {
                playerTradeCards.add(object);
                addToPortTradeValue(object.getValue());
                String valuetext = portTradeValue + "";
                lblPortValue.setText(valuetext);
                gpPortOffer.add(image, 0, gpPortOffer.getChildren().size());

            }
        } catch (IndexOutOfBoundsException i) {
        }
    }

    /*
    *Adds the player card data and image to the correct place
    *@param girdLocation the location of the item clicked in the trading menu
    */
    void portTreasureClicked(int girdLocation) {
        try {
            Treasure object = portTreasureArray.get(girdLocation);
            ImageView image = portTreasureArrayImages.get(girdLocation);


            if (object != null && image != null) {
                portTradeTreasure.add(object);
                addToPortTradeValue(object.getValue());
                String valuetext = portTradeValue + "";
                lblPortValue.setText(valuetext);

                gpPortOffer.add(image, 0, gpPortOffer.getChildren().size());
            }
        } catch (IndexOutOfBoundsException i) {
        }
    }

     /*
    *Clears the trading offer UI
    */

    void clearOffers() {
        gpPlayerOffer.getChildren().clear();
        gpPortOffer.getChildren().clear();
        //playerTradeItems.clear();
        // playerTradeItemsImages.clear();
        gpPortOffer.getChildren().clear();
        gpPlayerOffer.getChildren().clear();
    }
}





