package uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.chassis;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.exceptions.specific.LodisClassMismatchException;

import java.lang.reflect.Type;
import java.util.Objects;
import java.util.UUID;

/**
 * Used to construct a JSON payload to contain information *about* an object being stored in Lodis.
 *
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * @version 22.05.02
 * lodis.common.chassis.StoredObjectMetadata.java 22.05.02 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
public class StoredObjectMetadata {
    private String objectType;
    private UUID dumpFileIdentifier;

    private final UUID defaultDumpFileIdentifier = UUID.fromString("00000000-0000-0000-0000-000000000000");

    /**
     * Initialises a new Metadata instance.
     *
     * @param objectType the Type of the object being stored
     * @param dumpFile   whether the object is being stored in a dump file (false==being stored directly in the database)
     */
    public StoredObjectMetadata(Type objectType, UUID dumpFile) {
        this.objectType = objectType.getTypeName();
        this.dumpFileIdentifier = dumpFile;
    }

    /**
     * Initialises a new Metadata instance, assumed that the object is being stored directly into the database
     *
     * @param objectType the Type of the object being stored
     */
    public StoredObjectMetadata(Type objectType) {
        this.objectType = objectType.getTypeName();
        this.dumpFileIdentifier = defaultDumpFileIdentifier;
    }

    /**
     * Initialises a new Metadata instance using the JSON payload this class generates.
     *
     * @param jsonPayload the JSON payload
     */
    public StoredObjectMetadata(String jsonPayload) {
        GsonBuilder builder = new GsonBuilder();
        builder.registerTypeAdapter(StoredObjectMetadata.class, new StoredObjectMetadataTypeAdapter());
        builder.setPrettyPrinting();

        StoredObjectMetadata storedObjectMetadata = builder.create().fromJson(jsonPayload, StoredObjectMetadata.class);

        this.objectType = storedObjectMetadata.objectType;
        this.dumpFileIdentifier = storedObjectMetadata.dumpFileIdentifier;
    }

    /**
     * Used to retrieve the set Type of the object.
     *
     * @return the Type of object
     */
    public Type getObjectType() throws LodisClassMismatchException {
        try {
            return Class.forName(objectType);
        } catch (ClassNotFoundException ex) {
            throw new LodisClassMismatchException(ex);
        }
    }

    public void setObjectType(String objectType) {
        this.objectType = objectType;
    }

    public void setObjectType(Type objectType) {
        this.objectType = objectType.getTypeName();
    }

    public boolean getIsInDumpFile() {
        return !Objects.equals(this.dumpFileIdentifier.toString(), defaultDumpFileIdentifier.toString());
    }

    public UUID getDumpFileIdentifier() {
        return dumpFileIdentifier;
    }

    public void setDumpFileIdentifier(UUID dumpFileIdentifier) {
        this.dumpFileIdentifier = dumpFileIdentifier;
    }

    /**
     * Serialises this class into a JSON payload and returns it as a string.
     *
     * @return a JSON payload
     */
    @Override
    public String toString() {
        GsonBuilder builder = new GsonBuilder();
        builder.registerTypeAdapter(StoredObjectMetadata.class, new StoredObjectMetadataTypeAdapter());
        builder.setPrettyPrinting();
        Gson gson = builder.create();

        return gson.toJson(this);
    }
}
