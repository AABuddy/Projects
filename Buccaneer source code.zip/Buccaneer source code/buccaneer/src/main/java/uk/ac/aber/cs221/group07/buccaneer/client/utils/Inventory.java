/*
 * @(#) Inventory.java 1.0 | 2022/05/06 *
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved. *
 */
package uk.ac.aber.cs221.group07.buccaneer.client.utils;

import java.util.ArrayList;
import java.util.Collections;
/**
 * class that stores what each player has
 * @author Elliot Tudor (elt49)
 * @date (16/04/2022)
 * @version 1.0
 */

public class Inventory {
	public static final int NUM_OF_TREASURES = 2;
	ArrayList<CrewCard> crewCards;
	ArrayList<ChanceCard> chanceCards;
	ArrayList<Treasure> treasures;

	/**
	 * Initializes crewCards, chanceCards and treasures
	 */

	public Inventory() {
		crewCards = new ArrayList<>();
		chanceCards = new ArrayList<>();
		treasures = new ArrayList<>(NUM_OF_TREASURES);
	}

	/**
	 * Gets crewCards
	 * @return crewCards
	 */

	public ArrayList<CrewCard> getCrewCards() {
		return crewCards;
	}

	/**
	 * Sets crewCards in the players inventory
	 */

	public void setCrewCards(ArrayList<CrewCard> crewCards) {
		this.crewCards = crewCards;
	}

	/**
	 * Gets chanceCards
	 * @return chanceCards
	 */

	public ArrayList<ChanceCard> getChanceCards() {
		return chanceCards;
	}

	/**
	 * Sets chanceCards in the players inventory
	 */

	public void setChanceCards(ArrayList<ChanceCard> chanceCards) {
		this.chanceCards = chanceCards;
	}

	/**
	 * Gets chanceCards
	 * @return chanceCards
	 */

	public ArrayList<Treasure> getTreasures() {
		return treasures;
	}


	/**
	 * Sets treasures in the players inventory
	 */


	public void setTreasures(ArrayList<Treasure> treasures) {
		this.treasures = treasures;
	}

	/**
	 * Takes a treasure from the loser and returns it
	 *
	 * @return treasure if the loser had any, null otherwise
	 */
	public Treasure takeTreasure() {
		Treasure treasure;
		if(this.treasures.isEmpty()) return null;
		treasure = this.treasures.get(0);
		this.treasures.remove(0);
		return  treasure;
	}

	/**
	 * Takes up to two cards from the player and returns it
	 * @return takenCrewCards - cards that were taken from the player
	 */
	public ArrayList<CrewCard> takeCrewCards() {
		ArrayList<CrewCard> takenCrewCards = new ArrayList<>();
		ArrayList<CrewCard> temp = this.crewCards;
		Collections.sort(temp);
		int cardsToTake = 2;
		while(cardsToTake > 0 && !this.crewCards.isEmpty()) {
			takenCrewCards.add((CrewCard) this.crewCards.get(0));
			this.crewCards.remove(0);
			cardsToTake--;
		}
		return takenCrewCards;
	}
}
