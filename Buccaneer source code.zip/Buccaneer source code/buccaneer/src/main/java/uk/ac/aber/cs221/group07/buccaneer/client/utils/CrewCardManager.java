/*
 * @(#) CrewCardManager.java 1.0 | 2022/05/06 *
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved. *
 */
package uk.ac.aber.cs221.group07.buccaneer.client.utils;

import javafx.scene.paint.Color;

import java.util.ArrayList;
import java.util.Random;


/**
 * Controls whether a card is red or black and its value
 * @author Mia Sabin (mis44) 
 * @date (02/05/2022)
 * @version 1.0
 */
public class CrewCardManager {

    private ArrayList<CrewCard> red1;
    private ArrayList<CrewCard> red2;
    private ArrayList<CrewCard> red3;
    private ArrayList<CrewCard> black1;
    private ArrayList<CrewCard> black2;
    private ArrayList<CrewCard> black3;

    /**
     * Initializes each ArrayList of CrewCards
     */


    public CrewCardManager(){
        red1 = new ArrayList<>();
        red2 = new ArrayList<>();
        red3 = new ArrayList<>();
        black1 = new ArrayList<>();
        black2 = new ArrayList<>();
        black3 = new ArrayList<>();
    }

    /**
     * Creates each crew card and adds it to the correct ArrayList
     */

    public void initialize() {
        CrewCard red_1 = new CrewCard(1, Color.RED);
        CrewCard red_2 = new CrewCard(2, Color.RED);
        CrewCard red_3 = new CrewCard(3, Color.RED);
        CrewCard black_1 = new CrewCard(1, Color.BLACK);
        CrewCard black_2 = new CrewCard(2, Color.BLACK);
        CrewCard black_3 = new CrewCard(3, Color.BLACK);

        for(int x = 0; x < 6; x++){
            red1.add(red_1);
            red2.add(red_2);
            red3.add(red_3);
            black1.add(black_1);
            black2.add(black_2);
            black3.add(black_3);

        }
    }

    /**
     * Gets a red crew card with value 1
     * @return CrewCard item
     */

    public CrewCard getRed1() {
        CrewCard item = null;

        if(!red1.isEmpty()){
            item = red1.get(red1.size() - 1);
            red1.remove(red1.size()-1);

        }

        return item;
    }

    /**
     * Gets a red crew card with value 2
     * @return CrewCard item
     */

    public CrewCard getRed2(){
        CrewCard item = null;

        if(!red2.isEmpty()){
            item = red2.get(red2.size() - 1);
            red2.remove(red2.size() - 1);
        }

        return item;
    }

    /**
     * Gets a red crew card with value 3
     * @return CrewCard item
     */

    public CrewCard getRed3(){
        CrewCard item = null;

        if(!red3.isEmpty()){
            item = red3.get(red3.size() - 1);
            red3.remove(red3.size() - 1);
        }

        return item;
    }

    /**
     * Gets a black crew card with value 1
     * @return CrewCard item
     */

    public CrewCard getBlack1(){
        CrewCard item = null;

        if(!black1.isEmpty()){
            item = black1.get(black1.size() - 1);
            black1.remove(black1.size() - 1);

        }

        return item;
    }

    /**
     * Gets a black crew card with value 2
     * @return CrewCard item
     */

    public CrewCard getBlack2(){
       CrewCard item = null;

       if(!black2.isEmpty()){
           item = black2.get(black2.size() - 1);
           black2.remove(black2.size() - 1);

       }

       return item;
    }

    /**
     * Gets a black crew card with value 2
     * @return CrewCard item
     */

    public CrewCard getBlack3() {
        CrewCard item = null;

        if (!black3.isEmpty()) {
            item = black3.get(black3.size() - 1);
            black3.remove(black3.size() - 1);
        }

        return item;
    }

    /**
     * checks if there are any crew cards in any of the arrayLists
     */

    public boolean isCrewCard(){

        boolean crewCard = false;

        if(!red1.isEmpty() || !red2.isEmpty() || red3.isEmpty()
        || !black1.isEmpty() || !black2.isEmpty() || black3.isEmpty()){
            crewCard = true;
        }

        return crewCard;
    }

    /**
     * Gets a random CrewCard
     * @return CrewCard item
     */

    public CrewCard getRandom(){
        CrewCard item = null;
        Random number= new Random();

        if(isCrewCard()){
            while(item == null){
                int value = number.nextInt(6) + 1;
                switch(value){

                    case 1:
                        item = getRed1();
                        break;

                    case 2:
                        item = getRed2();
                        break;

                    case 3:
                        item = getRed3();
                        break;

                    case 4:
                        item = getBlack1();
                        break;

                    case 5:
                        item = getBlack2();
                        break;

                    case 6:
                        item = getBlack3();
                        break;

                }
            }
        }

        return item;
    }
}

