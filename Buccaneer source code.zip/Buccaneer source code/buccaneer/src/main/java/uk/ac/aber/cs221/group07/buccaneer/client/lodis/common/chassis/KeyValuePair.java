package uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.chassis;

/**
 * For storing a tuple of a String and an Object.
 * Used when bulk creating database records.
 *
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * @version 22.05.02
 * lodis.common.chassis.KeyValuePair.java 22.05.02 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
public record KeyValuePair(String key, Object value) {
}
