package uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.chassis;

import com.google.gson.TypeAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.exceptions.specific.LodisClassMismatchException;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.UUID;

/**
 * Used by Gson to convert an instance of StoredObjectMetadata to JSON and back.
 * This is critical since Gson cannot serialise/deserialise StoredObjectMetadata due to potential exception throws.
 *
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * @version 22.05.04
 * lodis.common.chassis.StoredObjectMetadataTypeAdapter.java 22.05.04 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
public class StoredObjectMetadataTypeAdapter extends TypeAdapter<StoredObjectMetadata> {
    @Override
    public void write(JsonWriter jsonWriter, StoredObjectMetadata storedObjectMetadata) throws IOException {
        jsonWriter.beginObject();

        jsonWriter.name("objectType");
        try
        {
            jsonWriter.value(storedObjectMetadata.getObjectType().getTypeName());
        }
        catch (LodisClassMismatchException ex)
        {
            jsonWriter.value(String.valueOf(Object.class));
        }

        jsonWriter.name("dumpFileIdentifier");
        jsonWriter.value(storedObjectMetadata.getDumpFileIdentifier().toString());

        jsonWriter.endObject();
    }

    @Override
    public StoredObjectMetadata read(JsonReader jsonReader) throws IOException {
        jsonReader.beginObject();
        String fileDescription = null;

        Type objectType = null;
        UUID dumpFileIdentifier = null;

        while (jsonReader.hasNext()) {
            JsonToken jsonToken = jsonReader.peek();

            if (jsonToken.equals(JsonToken.NAME))
                fileDescription = jsonReader.nextName();

            assert fileDescription != null;

            if (fileDescription.equals("objectType")) {
                jsonToken = jsonReader.peek();
                try {
                    objectType = Class.forName(jsonReader.nextString());
                } catch (ClassNotFoundException ignored) {}
            }

            if (fileDescription.equals("dumpFileIdentifier")) {
                jsonToken = jsonReader.peek();
                dumpFileIdentifier = UUID.fromString(jsonReader.nextString());
            }
        }

        assert(objectType != null);
        assert(dumpFileIdentifier != null);

        jsonReader.endObject();
        return new StoredObjectMetadata(objectType, dumpFileIdentifier);
    }
}
