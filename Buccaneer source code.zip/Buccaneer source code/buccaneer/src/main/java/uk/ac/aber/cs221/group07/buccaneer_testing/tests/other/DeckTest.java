package uk.ac.aber.cs221.group07.buccaneer_testing.tests.other;

/**
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * @version 22.05.06
 * @deprecated buccaneer_testing.tests.other.DeckTest.java 22.05.06 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
public class DeckTest {
    /*
    private Deck testDeck = new Deck(new ArrayList<>() {static {
        new ChanceCard("0", "0", 0, true);
        new ChanceCard("1", "1", 1, true);
        new ChanceCard("2", "2", 2, true);
        new CrewCard(3, Color.BLACK);
        new CrewCard(4, Color.RED);
        new CrewCard(5, Color.YELLOW);
    }}) {{
        shuffle();
    }};

    @Test()
    public void TestCardExistance()
    {
        Assertions.assertEquals(
                "Index 0 out of bounds for length 0",
                Assertions.assertThrows(IndexOutOfBoundsException.class, () -> testDeck.getTopCard()).getMessage());
    }

    @Test
    public void TestRandomCard()
    {
        // there's no way to test for randomness!
        // ish
        // could shuffle and get the top card like a 1000 times I suppose...
    }
     */
}
