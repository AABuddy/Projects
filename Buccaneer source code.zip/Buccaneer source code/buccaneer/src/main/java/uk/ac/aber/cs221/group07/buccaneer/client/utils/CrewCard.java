/*
 * @(#) CrewCard.java 1.0 | 2022/05/06 *
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved. *
 */

package uk.ac.aber.cs221.group07.buccaneer.client.utils;

import javafx.scene.paint.Color;

/**
 * @author Julia Drodz (jud28), Emma Solaas (ems53)
 * @date (02/05/2022)
 * @version 1.0 | This class allows you to create and manage chance cards, Released.
 */
public class CrewCard extends Card implements  Comparable<CrewCard>{
    int value;
    Color color;

 /**
     * Constructor for crew card class.
    *
     * @param value The value of the crew card.
     * @param color The color of the crew card.
     */
    public CrewCard(int value, Color color) {
        this.value = value;
        this.color = color;
    }

    /**
     *
     * @return The value of the crew card.
     */
    public int getValue() {
        return value;
    }

    /**
     *
     * @param value Sets teh value of the crew card.
     */
    public void setValue(int value) {
        this.value = value;
    }

    /**
     *
     * @return Returns the color of the crew card.
     */
    public Color getColor() {
        return color;
    }

    /**
     *
     * @param color Sets the color of the crew card.
     */
    public void setColor(Color color) {
        this.color = color;
    }

    /**
     * Compares the crew cards based on their value.
     *
     * @param o The current crew card object.
     * @return The result of the comparison.
     */
    @Override
    public int compareTo(CrewCard o) {
        return this.getValue() - o.getValue();
    }
}
