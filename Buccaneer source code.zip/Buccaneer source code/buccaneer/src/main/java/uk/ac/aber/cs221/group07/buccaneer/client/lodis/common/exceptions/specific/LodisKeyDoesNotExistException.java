package uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.exceptions.specific;

import uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.exceptions.LodisKeyException;

/**
 * Used to construct `LodisKeyDoesNotExistException`
 *
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * @version 22.05.02
 * Lodis.common.exceptions.specific.LodisKeyDoesNotExistException.java 22.05.02 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
public class LodisKeyDoesNotExistException extends LodisKeyException {
    /**
     * This would typically be used when you're trying to retrieve data from Lodis, but the key isn't within the database.
     *
     * @param key the key that was trying to be used.
     */
    public LodisKeyDoesNotExistException(String key) {
        super(new LodisKeyDoesNotExistException(
                "The key \"" + key + "\" does not exist within the database, use PUT to create."
        ));
    }
}

