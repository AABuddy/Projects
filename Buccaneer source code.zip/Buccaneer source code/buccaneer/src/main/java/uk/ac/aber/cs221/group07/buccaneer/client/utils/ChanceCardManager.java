/*
 * @(#) ChanceCardManager.java 1.0 | 2022/05/06 *
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved. *
 */

package uk.ac.aber.cs221.group07.buccaneer.client.utils;

import java.util.ArrayList;
import java.util.Collections;

/**
 * @author Julia Drodz (jud28)
 * @date (02/05/2022)
 * @version 1.0 | Allows you to manage specific chance cards, Released.
 */
public class ChanceCardManager {
    private ArrayList<ChanceCard> chanceCards;

    /**
     *  Chance card manager constructor used to initialize a new ArrayList to store chance cards.
     */
    public ChanceCardManager() {
        chanceCards = new ArrayList<>();
    }

    /**
     *  This method initializes chance cards within the game by setting the chance card name, ID and isRetainable
     *  value using the chance card constructor.
     */
    public void initialize() {
        ChanceCard chanceCard28 = new ChanceCard("this is chanceCard28", "chanceCard28", 28, false);
        ChanceCard chanceCard15 = new ChanceCard("this is chanceCard15", "chanceCard15", 15, false);
        ChanceCard chanceCard14 = new ChanceCard("this is chanceCard14", "chanceCard13", 14, false);
        ChanceCard chanceCard13 = new ChanceCard("this is chanceCard13", "chanceCard13", 13, false);
        ChanceCard chanceCard12 = new ChanceCard("this is chanceCard12", "chanceCard12", 12, false);
        ChanceCard chanceCard11 = new ChanceCard("this is chanceCard11", "chanceCard11", 11, false);
        chanceCards.add(chanceCard11);
        chanceCards.add(chanceCard12);
        chanceCards.add(chanceCard13);
        chanceCards.add(chanceCard14);
        chanceCards.add(chanceCard15);
        chanceCards.add(chanceCard28);
        Collections.shuffle(chanceCards);
    }

    /**
     *
     * @return This method returns a random  chance card from the chance card ArrayList.
     */
    public ChanceCard getRandom() {
        ChanceCard randomCard = chanceCards.remove(0);
        if(randomCard == null) return null;
        return  randomCard;
    }

    /**
     *
     * @return This method returns whether the chance card ArrayList has any chance cards in it.
     */
    public boolean isChanceCardsEmpty() {
        if(chanceCards.isEmpty()) {
            return true;
        }
        return false;
    }
}
