package uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.chassis;

import uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.exceptions.specific.LodisDatabaseIOException;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * This class serves as a way to build Prepared Statements dynamically.
 * Used because Lodis uses Prepared Statements for data I/O operations.
 *
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * @version 22.03.15
 * lodis.common.chassis.Query.java 22.03.15 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
public class Query {
    private final String sqlQuery;
    private final List<PreparedStatementVariables> parameters = new ArrayList<>();

    /**
     * used to construct an instance of the QueryChassis class
     *
     * @param sqlQuery   plain text SQL query using '?' characters for prepared statements
     * @param parameters parameters to pass through into the prepared statement
     */
    public Query(String sqlQuery, Object... parameters) {
        this.sqlQuery = sqlQuery;

        for (Object parameter : parameters) addParameter(parameter);
    }


    /**
     * For adding additional parameters to the query.
     *
     * @param object the object you want to add.
     */
    public void addParameter(Object object) {
        this.parameters.add(new PreparedStatementVariables(parameters.size() + 1, object));
    }

    /**
     * @param connection the SQLite3 connection
     * @return a PreparedStatement instance to execute
     */
    public PreparedStatement createPreparedStatement(java.sql.Connection connection) throws LodisDatabaseIOException {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(this.sqlQuery);
            for (PreparedStatementVariables preparedStatementVariables : this.parameters)
                preparedStatement.setObject(preparedStatementVariables.index(), preparedStatementVariables.object());
            return preparedStatement;
        } catch (SQLException exception) {
            throw new LodisDatabaseIOException(exception);
        }
    }

    /**
     * @return the internal SQL query
     */
    public String getSqlQuery() {
        return this.sqlQuery;
    }
}
