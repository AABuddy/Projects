package uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.exceptions;

import java.io.IOException;
import java.sql.SQLException;

/**
 * Used to construct `LodisIOException`
 *
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * @version 22.05.02
 * Lodis.common.exceptions.LodisIOException.java 22.05.02 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
public class LodisIOException extends Exception {
    public LodisIOException(SQLException sqlException) {
        super(sqlException);
    }

    public LodisIOException(IOException fileIOException) {
        super(fileIOException);
    }
}
