package uk.ac.aber.cs221.group07.buccaneer.client.controllers;
/*
 *
 * @(#) ObtainHelpController.java 1.0 | 2022/05/06 *
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved. *
 */
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.stage.Stage;
import uk.ac.aber.cs221.group07.buccaneer.client.Main;

import java.io.IOException;
/**
 * Obtain help controller - A controller that sends you back to the main menu
 * @author Julia Drodz (jud28)
 * @date 02/05/2022
 * @version 1.0 | release
 */
public class ObtainHelpController {
    Stage stage;
    /**
     *  Go back to the main window from the main menu
     * @param actionEvent
     */
    public void goToWelcome(ActionEvent actionEvent) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("welcomeScreen.fxml"));
            stage = (Stage)(((Node)actionEvent.getSource()).getScene().getWindow());
            Scene scene = new Scene(fxmlLoader.load());
            stage.setTitle("Welcome to Buccaneer");
            stage.setResizable(false);
            stage.setScene(scene);
            stage.show();
        } catch(IOException e) {
            e.printStackTrace();
        }
    }
}
