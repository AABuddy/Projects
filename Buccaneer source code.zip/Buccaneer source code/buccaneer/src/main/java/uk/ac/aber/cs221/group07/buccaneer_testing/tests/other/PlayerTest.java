package uk.ac.aber.cs221.group07.buccaneer_testing.tests.other;

import javafx.geometry.Point2D;
import javafx.scene.paint.Color;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import uk.ac.aber.cs221.group07.buccaneer.client.utils.*;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * @version 22.05.06
 * buccaneer_testing.tests.other.PlayerTest.java 22.05.06 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
public class PlayerTest {
    Player testPlayer = new Player(Color.YELLOW);

    Inventory testInventory = new Inventory();
    Port testPort = new Port("test port", new Point2D(1, 2), true);
    ArrayList<Treasure> treasureTest = new ArrayList<>() {{
        add(new Treasure(TreasureType.DIAMOND));
    }};

    @Test
    public void TestChangeTreasures() {
        Assertions.assertNotNull(testPlayer.getInventory());
        testPlayer.setInventory(new Inventory() {{
            setTreasures(treasureTest);
        }});
        assertEquals(treasureTest, testPlayer.getInventory().getTreasures());
    }

    @Test
    public void TestOrientation() {
        Assertions.assertEquals(0, testPlayer.getOrientation());
        testPlayer.setOrientation(123);
        Assertions.assertEquals(123, testPlayer.getOrientation());
    }

    @Test
    public void TestFightingStrength() {
        // testPlayer.getFightingStrength()
    }

    @Test
    public void TestPosition() {
        testPlayer.setLocation(new Point2D(1, 2));
        Assertions.assertEquals(new Point2D(1, 2), testPlayer.getLocation());
        Assertions.assertEquals(1, testPlayer.getX());
        Assertions.assertEquals(2, testPlayer.getY());
    }

    @Test
    public void TestHomePort() {
        testPlayer.setHomePort(testPort);
        Assertions.assertEquals(testPort, testPlayer.getHomePort());
    }

    @Test
    public void TestName() {
        testPlayer.setName("test");
        Assertions.assertEquals("test", testPlayer.getName());
    }

    @Test
    public void TestMovesRemaining() {
        testPlayer.setMovesRemaining();
        Assertions.assertEquals(1, testPlayer.getMovesRemaining());
        testPlayer.getInventory().setCrewCards(
                new ArrayList<>() {{
                    add(new CrewCard(1, Color.BLACK));
                }}
        );
        Assertions.assertEquals(testPlayer.getInventory().getCrewCards().size(), testPlayer.getMovesRemaining());
    }

    @Test
    public void TestIsRotational() {
        testPlayer.setRotatable(true);
        Assertions.assertTrue(testPlayer.isRotatable());
        testPlayer.setRotatable(false);
        Assertions.assertFalse(testPlayer.isRotatable());
    }

    @Test
    public void TestColour() {
        testPlayer.setColor(Color.BLACK);
        Assertions.assertEquals(Color.BLACK, testPlayer.getColor());
    }
}
