package uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.exceptions.specific;

import uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.exceptions.LodisIOException;

import java.io.IOException;

/**
 * Used to construct `LodisFileIOException`
 *
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * @version 22.05.02
 * Lodis.common.exceptions.specific.LodisFileIOException.java 22.05.02 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
public class LodisFileIOException extends LodisIOException {
    /**
     * This is used when there's an unknown error with something to do with database interaction.
     */
    public LodisFileIOException(IOException ioException) {
        super(ioException);
    }
}
