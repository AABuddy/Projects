/*
 * @(#) Player.java 1.0 | 2022/05/06 *
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved. *
 */

//packages
package uk.ac.aber.cs221.group07.buccaneer.client.utils;

import javafx.geometry.Point2D;
import javafx.scene.paint.Color;

import java.util.ArrayList;

/**
 * A class that retrieves and sets data for players in the game.
 * @author Elliot Tudor (elt49), Julia Drozdz (jud28)
 * @date 12/04/2022
 * @version 1.0
 */

public class Player {

    private Port homePort;
    private int movesRemaining;
    private Point2D location;
    private Color color;
    private String name;
    private boolean rotatable;
    private Inventory inventory;
    private int orientation;

    /**
     * Constructor for the Player Class
     * @param color the color assosiated with the player on the gameboard
     */

    public Player(Color color) {
        this.color = color;
        this.inventory = new Inventory();
    }

    /**
     * Method that retrieves the inventory contents of the player.
     * @return inventory
     */

    public Inventory getInventory() {
        return inventory;
    }

    /**
     * Method that sets the inventory contents of the player to the input contents.
     * @param inventory
     */

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    /**
     * Method that retrieves the orientation of a players ship on the gameboard.
     * @return orientation
     */

    public int getOrientation() {
        return orientation;
    }

    /**
     * Method that sets the orientation of a players ship on the gameboard.
     * @param orientation direction of the player
     */

    public void setOrientation(int orientation) {
        this.orientation = orientation;
    }

    /**
     * Method that calculates the fighting strength of a player through their crew cards
     * Taking away Red Card Score from the Black Card Score unless negative then vice-versa.
     * @return fightingStrength value compared during battle
     */

    public int getFightingStrength() {
        int blackCrewCard = 0;
        int redCrewCard = 0;
        ArrayList<CrewCard> playerInventory = inventory.getCrewCards();
        for (CrewCard card : playerInventory) {
            int value = card.getValue();
            Color color = card.getColor();
            if (color.equals(Color.RED)) {
                redCrewCard = redCrewCard + value;
            } else if (color.equals(Color.BLACK)) {
                blackCrewCard = blackCrewCard + value;
            }
        }
        return Math.abs(blackCrewCard - redCrewCard);
    }

    /**
     * Method that sets the color they palyer will appear on the gameboard
     * @param color the color of the player
     */

    public void setColor(Color color) {
        this.color = color;
    }

    /**
     * Method that sets the moves that a player has left on the gameboard.
     * @param movesRemaining the amount of squares a player can move in a turn
     */

    public void setMovesRemaining() {
        if (inventory.getCrewCards().size() > 1) this.movesRemaining = this.inventory.getCrewCards().size();
        else this.movesRemaining = 1;
    }

    /**
     * Method that retrieves if the player is able to rotate their ship on the gameboard
     * @return rotatable boolean whether rotation is possible.
     */

    public boolean isRotatable() {
        return rotatable;
    }

    /**
     * Method that sets if the player can rotate their ship on the gameboard.
     * @param rotatable boolean whether rotation is possible.
     */

    public void setRotatable(boolean rotatable) {
        this.rotatable = rotatable;
    }

    /**
     * Method that retrieves the X Coordinate of the players ship
     * @return location x value
     */
    public int getX() {
        return (int) this.location.getX();
    }

    /**
     * Method that retrieves the coordinates of the players ship
     * @return location of the players ship on the board.
     */

    public Point2D getLocation() {
        return location;
    }

    /**
     * Method that retrieves the Y Coordinate of the players ship
     * @return location y value
     */

    public int getY() {
        return (int) this.location.getY();
    }

    /**
     * Method that sets the players ship to a certain location
     * @param location location of the ship on the board
     */

    public void setLocation(Point2D location) {
        this.location = location;
    }

    /**
     * Method that retrieves the home port of the player
     * @return the details of the homeport
     */

    public Port getHomePort() {
        return homePort;
    }

    /**
     * Method that assigns a player to a home port
     * @param homePort details of the homeport
     */

    public void setHomePort(Port homePort) {
        this.homePort = homePort;
    }

    /**
     * Method that retrieves the players username in the game.
     * @return name username of the player.
     */

    public String getName() {
        return name;
    }

    /**
     * Method that retrieves the amount of squares the player can move on their turn
     * @return the amount of squares a player can move
     */

    public int getMovesRemaining() {
        return movesRemaining;
    }

    /**
     * Method that retrieves the color of the player assigned to them.
     * @return the color of the player
     */


    public Color getColor() {
        return color;
    }

    /**
     * Method that sets the username of the player.
     * @param name username of the player.
     */

    public void setName(String name) {
        this.name = name;
    }

}