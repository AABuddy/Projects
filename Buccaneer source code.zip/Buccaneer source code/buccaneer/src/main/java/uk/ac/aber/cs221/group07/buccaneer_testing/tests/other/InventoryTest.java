package uk.ac.aber.cs221.group07.buccaneer_testing.tests.other;

import javafx.scene.paint.Color;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import uk.ac.aber.cs221.group07.buccaneer.client.utils.CrewCard;
import uk.ac.aber.cs221.group07.buccaneer.client.utils.Inventory;
import uk.ac.aber.cs221.group07.buccaneer.client.utils.Treasure;
import uk.ac.aber.cs221.group07.buccaneer.client.utils.TreasureType;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * @version 22.05.06
 * buccaneer_testing.tests.other.InventoryTest.java 22.05.06 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
public class InventoryTest {
    Inventory testInventory = new Inventory();

    CrewCard[] testCrewCards = new CrewCard[]{
            new CrewCard(1, Color.BLACK),
            new CrewCard(2, Color.BLACK),
            new CrewCard(3, Color.BLACK),
            new CrewCard(4, Color.BLACK),
            new CrewCard(5, Color.BLACK),
            new CrewCard(6, Color.BLACK)
    };
    Treasure[] testTreasureCards = new Treasure[]{
            new Treasure(TreasureType.BARRELOFRUM),
            new Treasure(TreasureType.DIAMOND),
            new Treasure(TreasureType.GOLDBAR),
            new Treasure(TreasureType.PEARL),
            new Treasure(TreasureType.RUBY)
    };

    @Test
    public void testTooManyCrewCards() {
        testInventory.setCrewCards(new ArrayList<>(Arrays.asList(testCrewCards)));
    }

    @Test
    public void testCrewCards() {
        Assertions.assertEquals(new ArrayList<>(), testInventory.getChanceCards());
    }

    @Test
    public void testChanceCards() {
        Assertions.assertEquals(new ArrayList<>(), testInventory.getChanceCards());
    }

    @Test
    public void testTooManyTreasures() {
        testInventory.setTreasures(new ArrayList<>(Arrays.asList(testTreasureCards)));
    }

    @Test
    public void testTreasures() {
        // IMPORTANT!!
        // This test has been updated to ensure that it returns 0 since it should NOT have been given a value at this point.
        /* Assertions.assertEquals(Inventory.NUM_OF_TREASURES, testInventory.getTreasures().size()); */
        Assertions.assertEquals(0, testInventory.getTreasures().size());
    }
}
