package uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.exceptions;

import uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.exceptions.specific.LodisKeyAlreadyExistsException;
import uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.exceptions.specific.LodisKeyDoesNotExistException;

/**
 * Used to construct `LodisKeyException`
 *
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * @version 22.05.02
 * Lodis.common.exceptions.LodisKeyException.java 22.05.02 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
public class LodisKeyException extends Exception {
    public LodisKeyException(LodisKeyAlreadyExistsException ex) {
        super(ex);
    }

    public LodisKeyException(LodisKeyDoesNotExistException ex) {
        super(ex);
    }
}
