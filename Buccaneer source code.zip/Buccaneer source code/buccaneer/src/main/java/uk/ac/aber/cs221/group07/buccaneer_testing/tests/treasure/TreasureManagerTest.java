package uk.ac.aber.cs221.group07.buccaneer_testing.tests.treasure;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;
import uk.ac.aber.cs221.group07.buccaneer.client.utils.TreasureManager;

/**
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * @version 22.05.06
 * buccaneer_testing.tests.treasure.TreasureManagerTest.java 22.05.06 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TreasureManagerTest {
    private final TreasureManager testTreasureManager = new TreasureManager();

    @Test
    @Order(1)
    public void InitialiseInstance() {
        this.testTreasureManager.initialize();
    }

    @Test
    @Order(2)
    public void EverythingHasValue() {
        // IMPORTANT!!
        // This test has been updated to ensure that they are all null, this is because they will be assigned values other than null later on in the game, for example, during battles.
        /*
        Assertions.assertNotNull(testTreasureManager.getDiamond());
        Assertions.assertNotNull(testTreasureManager.getPearl());
        Assertions.assertNotNull(testTreasureManager.getRuby());
        Assertions.assertNotNull(testTreasureManager.getBarrelOfRum());
        Assertions.assertNotNull(testTreasureManager.getGoldBar());
        */

        Assertions.assertNull(testTreasureManager.getDiamond());
        Assertions.assertNull(testTreasureManager.getPearl());
        Assertions.assertNull(testTreasureManager.getRuby());
        Assertions.assertNull(testTreasureManager.getBarrelOfRum());
        Assertions.assertNull(testTreasureManager.getGoldBar());
    }
}
