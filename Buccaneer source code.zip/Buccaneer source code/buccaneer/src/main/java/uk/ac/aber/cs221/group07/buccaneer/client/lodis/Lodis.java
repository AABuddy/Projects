package uk.ac.aber.cs221.group07.buccaneer.client.lodis;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import org.apache.commons.io.FileUtils;
import uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.chassis.CoreVariables;
import uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.chassis.KeyValuePair;
import uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.chassis.Query;
import uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.chassis.StoredObjectMetadata;
import uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.exceptions.specific.*;
import uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.statics.CRUD;
import uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.statics.Helpers;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;
import java.util.UUID;

import static uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.statics.Helpers.*;

/**
 * Responsible for controlling data input/output operations, uses the 'Core' class for connection control.
 *
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * @version 22.05.04
 * lodis.java 22.05.04 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
public class Lodis extends Core {
    /**
     * This is for initialising an instance of Lodis using the default storage location.
     * The database file will be stored in the running directory of the Java application under `database.lodis`
     */
    public Lodis() throws LodisFileIOException, LodisDatabaseIOException {
        String path;
        try {
            path = (new File(".").getCanonicalPath()).replace('\\', '/') + "/database.lodis";
        } catch (IOException ex) {
            throw new LodisFileIOException(ex);
        }
        super.setVariableChassis(new CoreVariables(path));
        init();
    }

    /**
     * This is for initialising an instance of Lodis using a specified storage location.
     *
     * @param databaseLocation the full file path of the database file (database.lodis)
     */
    public Lodis(String databaseLocation) throws LodisFileIOException, LodisDatabaseIOException {
        super.setVariableChassis(
                new CoreVariables(
                        databaseLocation + "/database.lodis"
                )
        );
        init();
    }

    /**
     * Initialises a new instance of Lodis, creates the relevant directories, along with a database with valid datatables
     */
    public void init() throws LodisDatabaseIOException, LodisFileIOException {
        try {
            if (!Files.exists(Paths.get(getVariableChassis().getRootFileLocation())))
                Files.createDirectories(Paths.get(getVariableChassis().getRootFileLocation()));
        } catch (IOException ex) {
            throw new LodisFileIOException(ex);
        }
        this.connect();
        try {
            this.getVariableChassis().getSqliteConnection().createStatement().executeUpdate(resourceFileToString("sql/database-creation.sql"));
        } catch (SQLException ex) {
            throw new LodisDatabaseIOException(ex);
        }
        this.disconnect();
    }

    /**
     * returns a boolean for whether the provided key corresponds to an object within Lodis
     *
     * @param key the key to check.
     * @return whether the key exists or not.
     */
    public boolean isKeyInUse(String key) throws LodisFileIOException, LodisDatabaseIOException {
        ResultSet temp1 = CRUD.read(this, new Query(resourceFileToString("sql/common/is-key-in-use.sql"), key));
        String temp2;
        try {
            temp2 = temp1.getString("DoesExist");
        } catch (SQLException ex) {
            throw new LodisDatabaseIOException(ex);
        }
        CRUD.afterRead(this);
        return temp2.equals("1");
    }


    /**
     * Returns only the metadata JSON payload from a stored object.
     *
     * @param key the target object's key
     * @return an instance of the StoredObjectMetadata class
     */
    public StoredObjectMetadata getMetadata(String key) throws LodisFileIOException, LodisDatabaseIOException {
        ResultSet resultSet = CRUD.read(this, new Query(resourceFileToString("sql/common/get-metadata.sql"), key));
        String jsonPayload;
        try {
            jsonPayload = resultSet.getString("Metadata");
        } catch (SQLException ex) {
            throw new LodisDatabaseIOException(ex);
        }
        CRUD.afterRead(this);
        return new StoredObjectMetadata(jsonPayload);
    }


    /**
     * used for inserting data into Lodis
     *
     * @param keyValuePairs the keys and values to store
     * @return how many rows were affected, should be one if everything goes well!
     */
    public Integer store(KeyValuePair... keyValuePairs) throws LodisKeyAlreadyExistsException, LodisFileIOException, LodisDatabaseIOException {
        for (KeyValuePair keyValuePair : keyValuePairs)
            if (isKeyInUse(keyValuePair.key()))
                throw new LodisKeyAlreadyExistsException(keyValuePair.key());

        String sqlQuery = "INSERT INTO `PayloadStore` VALUES {{ VALUES }};";
        sqlQuery = sqlQuery.replace("{{ VALUES }}", new String(new char[keyValuePairs.length]).replace("\0", "(?, ?, ?),"));
        sqlQuery = sqlQuery.replace(",;", ";");

        ArrayList<Object> parameterList = new ArrayList<>();

        for (KeyValuePair keyValuePair : keyValuePairs) {
            String jsonPayload = new Gson().toJson(keyValuePair.value());
            StoredObjectMetadata storedObjectMetadata = new StoredObjectMetadata(keyValuePair.value().getClass());

            if (jsonPayload.length() > super.getVariableChassis().getFileSizeThreshold()) {
                UUID guid = UUID.randomUUID();
                Helpers.writeFileToVirtualDatabaseDirectory(this, jsonPayload, guid);
                storedObjectMetadata.setDumpFileIdentifier(guid);
                manageDumpFileList(this, guid, true);
            }

            parameterList.add(keyValuePair.key());
            parameterList.add(storedObjectMetadata);
            parameterList.add(jsonPayload.length() > super.getVariableChassis().getFileSizeThreshold() ? null : jsonPayload);
        }

        return CRUD.update(
                this,
                new Query(
                        sqlQuery,
                        parameterList.toArray()
                )
        );
    }

    /**
     * Used to store a single item into Lodis
     *
     * @param key   the object key
     * @param value the object value
     * @return the number of affected rows, should be 1 in this case!
     */
    public Integer store(String key, Object value) throws LodisKeyAlreadyExistsException, LodisFileIOException, LodisDatabaseIOException {
        return store(new KeyValuePair(key, value));
    }

    /**
     * used for retrieving data out of Lodis
     *
     * @param key the key of the object you want to get
     * @param <T> this is a dynamic method and objects will be returned as the type they were stored in
     * @return the object
     */
    public <T> T retrieve(String key) throws LodisFileIOException, LodisDatabaseIOException, LodisKeyDoesNotExistException, LodisClassMismatchException {
        if (!isKeyInUse(key))
            throw new LodisKeyDoesNotExistException(key);

        ResultSet resultSet = CRUD.read(this, new Query(resourceFileToString("sql/common/retrieve.sql"), key));

        assert resultSet != null;

        String metadataJsonPayload;
        String dataJsonPayload;

        try {
            metadataJsonPayload = resultSet.getString("Metadata");
        } catch (SQLException ex) {
            throw new LodisDatabaseIOException(ex);
        }
        try {
            dataJsonPayload = resultSet.getString("Payload");
        } catch (SQLException ex) {
            throw new LodisDatabaseIOException(ex);
        }


        StoredObjectMetadata storedObjectMetadata = new StoredObjectMetadata(metadataJsonPayload);
        String payload = dataJsonPayload;

        CRUD.afterRead(this);

        String jsonPayload = storedObjectMetadata.getIsInDumpFile()
                ? Helpers.readFileFromVirtualDatabaseDirectory(this, storedObjectMetadata.getDumpFileIdentifier())
                : payload;

        return new Gson().fromJson(jsonPayload, storedObjectMetadata.getObjectType());
    }


    /**
     * For retrieving a setting from the database
     *
     * @param settingDescription works like the `key` in the PayloadStore
     * @return the current value of the target setting
     */
    public String getSetting(String settingDescription) throws LodisFileIOException, LodisDatabaseIOException {
        ResultSet resultSet = CRUD.read(this, new Query(resourceFileToString("sql/common/get-setting.sql"), settingDescription));
        String settingValue;
        try {
            settingValue = resultSet.getString("Value");
        } catch (SQLException ex) {
            throw new LodisDatabaseIOException(ex);
        }
        CRUD.afterRead(this);
        return settingValue;
    }

    /**
     * For updating a setting from the database.
     *
     * @param settingDescription works like the `key` in the PayloadStore
     * @param newValue           the new updated value for the target setting
     * @return number of rows affected, should be 1 for successful operation!
     */
    public Integer updateSetting(String settingDescription, Object newValue) throws LodisFileIOException, LodisDatabaseIOException {
        return CRUD.update(
                this,
                new Query(
                        resourceFileToString("sql/common/update-setting.sql"),
                        newValue,
                        settingDescription
                )
        );
    }


    /**
     * Updates an existing object with a new value
     *
     * @param key   the key of the object to update
     * @param value the new value for the object
     * @return the number of affected rows, should be 1 for successful operation
     */
    public Integer update(String key, Object value) throws LodisFileIOException, LodisDatabaseIOException, LodisKeyDoesNotExistException, LodisKeyAlreadyExistsException {
        if (!isKeyInUse(key))
            throw new LodisKeyDoesNotExistException(key);

        delete(key);
        return store(key, value);
    }


    /**
     * Used for deleting an object from Lodis
     *
     * @param key the key of the object to delete
     * @return how many rows were affected, should be one if everything goes well!
     */
    public Integer delete(String key) throws LodisKeyDoesNotExistException, LodisFileIOException, LodisDatabaseIOException {
        if (!isKeyInUse(key))
            throw new LodisKeyDoesNotExistException(key);
        StoredObjectMetadata storedObjectMetadata = getMetadata(key);
        if (storedObjectMetadata.getIsInDumpFile()) {
            new File(generateFilePath(this, storedObjectMetadata.getDumpFileIdentifier())).delete();
            manageDumpFileList(this, storedObjectMetadata.getDumpFileIdentifier(), false);
        }
        return CRUD.update(this, new Query(resourceFileToString("sql/common/delete.sql"), key));
    }

    /**
     * !!DANGER!!
     * !!this method is used for wiping _ALL_ data from the database including all dump files!!
     * !!DANGER!!
     *
     * @return the number of rows that were affected.
     */
    public Integer deleteAll() throws LodisFileIOException, LodisDatabaseIOException {
        for (File file : Objects.requireNonNull(new File(this.getVariableChassis().getRootFileLocation()).listFiles()))
            if (file.getName().endsWith(".dmp"))
                file.delete();
        CRUD.update(this, new Query(resourceFileToString("sql/common/reset-dumpfile-setting.sql")));
        return CRUD.update(this, new Query(resourceFileToString("sql/common/delete-payload-store.sql")));
    }


    /**
     * Not a particularly efficient method.
     * Is used to remove dump files that aren't linked to the database.
     * This might have happened if a large BLOB is created, then the database file is deleted (for example).
     *
     * @return the number of dump files cleared
     */
    public Integer destroyUnreferencedDumpFiles() throws LodisFileIOException, LodisDatabaseIOException {
        Integer counter = 0;

        String[] dumpFileList = new Gson().fromJson(
                getSetting("DumpFiles"),
                new TypeToken<String[]>() {
                }.getType()
        );

        for (File file : Objects.requireNonNull(new File(this.getVariableChassis().getRootFileLocation()).listFiles())) {
            if (file.getName().endsWith(".dmp")) {
                String dumpFileIdentifier = file.getName().replace(".dmp", "");

                if (Arrays.stream(dumpFileList).noneMatch(dumpFileIdentifier::equals)) {
                    try {
                        FileUtils.forceDelete(file);
                    } catch (IOException ex) {
                        throw new LodisFileIOException(ex);
                    }
                    counter++;
                }
            }
        }

        return counter;
    }

    /**
     * Used for removing references from the database that point to dump files that no longer exist
     *
     * @return number of rows affected
     */
    public Integer destroyReferencesToNonExistentDumpFiles() throws LodisFileIOException, LodisDatabaseIOException {
        Integer counter = 0;
        ArrayList<String> dumpFileList = new Gson().fromJson(
                getSetting("DumpFiles"),
                new TypeToken<ArrayList<String>>() {
                }.getType()
        );
        ArrayList<String> dumpFileListToReturn = new ArrayList<>(dumpFileList); /* duplicating the array, so we can iterate over one, then remove elements from the other, this avoids a `ConcurrentModificationException` */

        for (String dumpFileIdentifier : dumpFileList) {
            File tempFile = new File(generateFilePath(this, UUID.fromString(dumpFileIdentifier)));
            if (!tempFile.exists()) {
                CRUD.update(this, new Query("DELETE FROM PayloadStore WHERE Metadata LIKE ?", "%" + dumpFileIdentifier + "%"));
                dumpFileListToReturn.remove(dumpFileIdentifier);
                counter++;
            }
        }

        updateSetting("DumpFiles", dumpFileListToReturn);

        return counter;
    }

    /**
     * Generates a payload of all keys that are used within the database
     *
     * @return all keys
     */
    public String[] getAllKeys() throws LodisFileIOException, LodisDatabaseIOException {
        return Helpers.resultSetColumnToArray(CRUD.read(this, new Query(resourceFileToString("sql/common/get-all-keys.sql"))), "Key");
    }

    /**
     * counts the number of objects that are referenced or stored in the database
     *
     * @return the number of objects
     */
    public Integer countAllObjects() throws LodisFileIOException, LodisDatabaseIOException {
        return getAllKeys().length;
    }
}
