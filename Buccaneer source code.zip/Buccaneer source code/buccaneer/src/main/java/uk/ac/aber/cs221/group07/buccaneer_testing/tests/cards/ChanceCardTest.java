package uk.ac.aber.cs221.group07.buccaneer_testing.tests.cards;

import org.junit.Test;
import uk.ac.aber.cs221.group07.buccaneer.client.utils.ChanceCard;

import java.util.Optional;

import static org.junit.Assert.*;

public class ChanceCardTest {
    ChanceCard testChanceCard = new ChanceCard("test", "test", 1, true);

    // ##################################################
    // Card
    // ##################################################
    @Test
    public void ID() {
        assertNotNull(testChanceCard.getId());
        assertEquals(Optional.ofNullable(testChanceCard.getId()), Optional.of(1));
    }

    @Test
    public void Text() {
        assertEquals(testChanceCard.getText(), "test");
    }


    // ##################################################
    // Card
    // ##################################################
    @Test
    public void Retainable() {
        assertTrue(testChanceCard.isRetainable());
    }
}
