/*
 * @(#) Treasure.java 1.0 | 2022/05/06 *
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved. *
 */
package uk.ac.aber.cs221.group07.buccaneer.client.utils;
/**

 * A class that assigns and retrieves data about the treasure and its value
 *
 * @author Jennifer Billingsley (jeb69)
 * @date 28/03/2022
 * @version 1.0
 */
public class Treasure {

    private TreasureType type;
    private int value;

    /**
     * Constructor for the Treasure Object
     * This method sets the value of a treasure when the type of it is entered.
     * @param type the type of treasure it is in the game.
     */

    //constructor for enumerator
    public Treasure(TreasureType type) {
        this.type = type;
        // assigns correct value to treasure type
        switch (type) {
            case DIAMOND:
                this.value = 5;
                break;

            case RUBY:
                this.value = 5;
                break;

            case GOLDBAR:
                this.value = 4;
                break;

            case PEARL:
                this.value = 3;
                break;
            case BARRELOFRUM:
                this.value = 2;
                break;
        }
    }

    /**
     * This method retrieves the type of treasure when called.
     * @return type the type of treasure it is.
     */
    //setters and getters
    public TreasureType getType() {
        return type;
    }

    /**
     * This method retrieves the value of the treasure when called.
     * @return value the amount of points the treasure is worth in the game.
     */

    public int getValue() {
        return value;
    }


    public void setValue(int treasureValue) {
        this.value = treasureValue;
    }
}
