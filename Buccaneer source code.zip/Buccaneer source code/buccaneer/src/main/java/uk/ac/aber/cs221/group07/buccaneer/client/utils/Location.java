/*
 * @(#) Location.java 1.0 | 2022/05/06 *
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved. *
 */
package uk.ac.aber.cs221.group07.buccaneer.client.utils;
import java.util.ArrayList;


/**
* a class to show what assets each location has
* @author Mia Sabin (mis44)
* @date 25/04/2022
* @version 1.0
*/


public abstract class Location {

    ArrayList<Treasure> treasures;
    ArrayList<CrewCard> crewCards;
    ArrayList<ChanceCard> chanceCards;
    private String name;
    /**
     * Constructor for location
     * @param name
     */
    public Location(String name) {
        this.treasures = new ArrayList<>();
        this.crewCards = new ArrayList<>();
        this.chanceCards = new ArrayList<>();
        this.name = name;
    }

    /**
     * Gets name
     * @return name
     */

    public String getName() {
        return name;
    }

    /**
     * Sets the name of the location
     */

    public void setName(String name) {
        this.name = name;
    }

    /**
     * adds a treasure item to treasures
     * @param treasure
     */


    public void addTreasure(Treasure treasure){
        treasures.add(treasure);
    }

    /**
     * adds a chance card item to chanceCards
     * @param card
     */

    public void addCard(ChanceCard card){
        chanceCards.add(card);
    }

    //duplicated in UML diagram

    /**
     * Gets treasures
     * @return treasures
     */
    public ArrayList<Treasure> getTreasures() {
        return treasures;
    }

    /**
     * Gets crewCards
     * @return crewCards
     */

    public ArrayList<CrewCard> getCards(){
        return crewCards;
    }

    /**
     * Gets crewTopCard
     * @return
     */

    public CrewCard getTopCard(){
        return crewCards.get(crewCards.size() - 1);
    }

    /**
     *gets the treasure with the highest value
     * @return mostValued
     */

    public Treasure getMostValuedTreasure(){
        Treasure mostValued = null;
        Treasure currentTreasure;

        //how do we know the most valued treasure
        for (Treasure treasure : treasures) {
            currentTreasure = treasure;


            if (mostValued == null || currentTreasure.getValue() > mostValued.getValue()) {
                mostValued = currentTreasure;
            }
        }

        return mostValued;
    }

    /**
     * Gets crewCards
     * @return crewCards
     */

    public ArrayList<CrewCard> getCrewCards(){
        return crewCards;
    }

    /**
     * Gets chanceCards
     * @return chanceCards
     */

    public ArrayList<ChanceCard> getChanceCards(){
        return chanceCards;
    }

    /**
     * adds a crew card item to crewCards
     * @param card
     */

    public void addCrewCard(CrewCard card){
        crewCards.add(card);
    }

    public void trade(){

        //leave for now

    }

    /**
     * Sets the treasures that a location has
     */

    public void setTreasures(ArrayList<Treasure> treasures) {
        this.treasures = treasures;
    }

    /**
     * Sets the crew cards that a location has
     */


    public void setCrewCards(ArrayList<CrewCard> crewCards) {
        this.crewCards = crewCards;
    }

    /**
     * Sets the chance cards that a location has
     */

    public void setChanceCards(ArrayList<ChanceCard> chanceCards) {
        this.chanceCards = chanceCards;
    }
}
