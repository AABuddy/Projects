/*
 * @(#) TreasureType.java 1.0 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
package uk.ac.aber.cs221.group07.buccaneer.client.utils;

/**
 * TreasureType- an enumeration of all treasure types
 * @author Jen Billingsley [jeb69]
 * @version 1.0 | Released
 * @see Treasure
 * @see TreasureManager
 */

public enum TreasureType {
    //list of different treasures
    DIAMOND,
    PEARL,
    RUBY,
    BARRELOFRUM,
    GOLDBAR;
}
