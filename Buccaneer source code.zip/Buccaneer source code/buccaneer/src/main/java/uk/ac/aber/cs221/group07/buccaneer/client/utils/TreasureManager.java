/*
 * @(#) TreasureManager.java 1.0 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
package uk.ac.aber.cs221.group07.buccaneer.client.utils;

import java.util.ArrayList;
import java.util.Random;
/**
* TreasureManager - Initializes the 20 treasures and allows them to be handed out
 *
* @author Daniel Slater[das94]
* @author Julia Drozdz [jud28]
* @version 1.0 | Released
* @see @Treasure @TreasureType @GameWorld */

public class TreasureManager {
    private ArrayList<Treasure> diamonds;
    private ArrayList<Treasure> pearls;
    private ArrayList<Treasure> rubys;
    private ArrayList<Treasure> barrelsOfRum;
    private ArrayList<Treasure> goldBars;


    /*
    *Constructor for the Treasure manager class, creates the array lists for all of the treasures
    *
    */
    public TreasureManager() {
        diamonds = new ArrayList<>();
        pearls = new ArrayList<>();
        rubys = new ArrayList<>();
        barrelsOfRum = new ArrayList<>();
        goldBars = new ArrayList<>();
    }

    /*
    *Fills all treasure types with the correct amount of treasure
    *
    */    

    public void initialize() {
        Treasure diamond = new Treasure(TreasureType.DIAMOND);
        Treasure pearl = new Treasure(TreasureType.PEARL);
        Treasure ruby = new Treasure(TreasureType.RUBY);
        Treasure rum = new Treasure(TreasureType.BARRELOFRUM);
        Treasure gold = new Treasure(TreasureType.GOLDBAR);

        for (int x = 0; x < 4; x++) {
            diamonds.add(diamond);
            pearls.add(pearl);
            rubys.add(ruby);
            barrelsOfRum.add(rum);
            goldBars.add(gold);
        }

    }

    /*
    *Retrives a diamond if there are any left then removes it from the array of diamonds.
    *@return the diamond fetched
    */    

    public Treasure getDiamond() {
        Treasure item = null;
        if (!diamonds.isEmpty()) {
            item = diamonds.get(diamonds.size() - 1);
            diamonds.remove(diamonds.size() - 1);
        }
        return item;
    }
    /*
    *Retrives a pearl if there are any left then removes it from the array of pearls.
    *@return the pearl fetched
    */    

    public Treasure getPearl() {
        Treasure item = null;
        if (!pearls.isEmpty()) {
            item = pearls.get(pearls.size() - 1);
            pearls.remove(pearls.size() - 1);
        }
        return item;
    }

    /*
    *Retrives a ruby if there are any left then removes it from the array of diamonds.
    *@return the ruby fetched
    */  
    public Treasure getRuby() {
        Treasure item = null;
        if (!rubys.isEmpty()) {
            item = rubys.get(rubys.size() - 1);
            rubys.remove(rubys.size() - 1);
        }
        return item;
    }

    /*
    *Retrives a barrel of rum if there are any left then removes it from the array of barrelsOfRum.
    *@return the rum fetched
    */  


    public Treasure getBarrelOfRum() {
        Treasure item = null;
        if (!barrelsOfRum.isEmpty()) {
            item = barrelsOfRum.get(barrelsOfRum.size() - 1);
            barrelsOfRum.remove(barrelsOfRum.size() - 1);
        }
        return item;
    }

    /*
    *Retrives a gold bar if there are any left then removes it from the array of goldBars.
    *@return gold bar fetched
    */  

    public Treasure getGoldBar() {
        Treasure item = null;
        if (!goldBars.isEmpty()) {
            item = goldBars.get(goldBars.size() - 1);
            goldBars.remove(goldBars.size() - 1);
        }
        return item;
    }

    /*
    *Checks if there is any treasure remaining
    *@return true if there is treasure, false if not
    */  
    public boolean isTreasure() {
        boolean treasure = false;
        if (!diamonds.isEmpty() || !pearls.isEmpty() || !rubys.isEmpty() || !goldBars.isEmpty() || !barrelsOfRum.isEmpty())
            treasure = true;
        return treasure;
    }
    
    /*
    *fetches a random treasure and returns it
    *@return a randomly selected treasure
    */  
    public Treasure getRandomTreasure() {
        Treasure item = null;
        Random number = new Random();
        if (isTreasure())
            while (item == null) {
                int value = number.nextInt(5) + 1;
                switch (value) {

                    case 1:
                        item = getDiamond();
                        break;

                    case 2:
                        item = getPearl();
                        break;

                    case 3:
                        item = getRuby();
                        break;

                    case 4:
                        item = getGoldBar();
                        break;

                    case 5:
                        item = getBarrelOfRum();
                        break;
                }

            }
        return item;
    }
}
