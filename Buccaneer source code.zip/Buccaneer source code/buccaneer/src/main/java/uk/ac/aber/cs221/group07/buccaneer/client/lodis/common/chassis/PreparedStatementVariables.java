package uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.chassis;

/**
 * Record for storing a pair of an Index and an Object for use in Prepared Statements.
 *
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * @version 22.05.02
 * lodis.common.chassis.PreparedStatementVariables.java 22.05.02 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
public record PreparedStatementVariables(Integer index, Object object) {
}
