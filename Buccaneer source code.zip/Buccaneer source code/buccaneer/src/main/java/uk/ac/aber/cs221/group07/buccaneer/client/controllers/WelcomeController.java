package uk.ac.aber.cs221.group07.buccaneer.client.controllers;
/*
 * @(#) WelcomeController.java 1.0 | 2022/05/06 *
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved. *
 */
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import uk.ac.aber.cs221.group07.buccaneer.client.Main;

import java.io.IOException;
/**
 * Welcome Controller - A controller to manage the first screen of the game
 * @author Julia Drodz (jud28)
 * @date 02/06/2022
 * @version 1.0| release
 */
public class WelcomeController {
    @FXML
    private Stage stage;
    /**
     *  Go to the usernames screen, where users can choose the usernames
     * @param actionEvent
     */
    @FXML
    protected void onPlayGame(ActionEvent actionEvent) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("usernamesScreen.fxml"));
            stage = (Stage)(((Node)actionEvent.getSource()).getScene().getWindow());
            Scene scene = new Scene(fxmlLoader.load());
            stage.setTitle("Set your usernames");
            stage.setResizable(false);
            stage.setScene(scene);
            stage.show();
        } catch(IOException e) {
            e.printStackTrace();
        }
    }
    /*Go to obtain help screen*/
    @FXML
    protected void onObtainHelp(ActionEvent actionEvent) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("obtainHelpScreen.fxml"));
            stage = (Stage)(((Node)actionEvent.getSource()).getScene().getWindow());
            Scene scene = new Scene(fxmlLoader.load());
            stage.setTitle("Obtain help");
            stage.setResizable(false);
            stage.setScene(scene);
            stage.show();
        } catch(IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    protected void onExit(ActionEvent actionEvent) {
        stage = (Stage)(((Node)actionEvent.getSource()).getScene().getWindow());
        stage.close();
    }
}
