/*
 * @(#) ChanceCard.java 1.0 | 2022/05/06 *
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved. *
 */

package uk.ac.aber.cs221.group07.buccaneer.client.utils;

/**
 * @author Emma Solaas (ems53), Julia Drodz (jud28), Harry Portlock (hjp10)
 * @date (02/05/2022)
 * @version 1.0 | This is the class that allows you to create and manage chance cards, Released.
 *
 */

public class ChanceCard extends Card {
    boolean retainable;
    /**
     * Constructor for the chance card class.
     *
     * @param text text on chance card
     * @param name name of chance card
     * @param id id of chance card
     * @param retainable is it retainable
     */
    public ChanceCard(String text, String name, int id, boolean retainable) {
        super(text, name, id);
        this.retainable = retainable;
    }

    /**
     *
     * @return Returns whether the Chance Card is retainable.
     */
    public boolean isRetainable() {
        return retainable;
    }

    /**
     *
     * @param retainable Sets whether the chance card is retainable.
     */
    public void setRetainable(boolean retainable) {
        this.retainable = retainable;
    }

}
