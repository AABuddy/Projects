package uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.chassis;

import java.sql.Connection;
/**
 * Variable chassis for holding general information about the connection.
 *
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * @version 22.05.04
 * lodis.common.chassis.CoreVariables.java 22.05.04 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
public class CoreVariables {
    private Integer fileSizeThreshold = 500;

    private String rootFileLocation;
    private String sqliteDatabaseFileLocation;
    private String connectionString;

    private java.sql.Connection sqliteConnection;

    /**
     * Initialises a new instance of CoreVariables
     * It automatically generates the variables from a 'root file path' which is a required argument
     *
     * @param rootFileLocation the root file path
     */
    public CoreVariables(String rootFileLocation) {
        this.rootFileLocation = rootFileLocation;
        this.sqliteDatabaseFileLocation = this.rootFileLocation + "/lodis.db";
        this.connectionString = "jdbc:sqlite:" + this.sqliteDatabaseFileLocation;
    }

    public Integer getFileSizeThreshold() {
        return fileSizeThreshold;
    }

    public void setFileSizeThreshold(Integer fileSizeThreshold) {
        this.fileSizeThreshold = fileSizeThreshold;
    }

    public String getRootFileLocation() {
        return rootFileLocation;
    }

    public void setRootFileLocation(String rootFileLocation) {
        this.rootFileLocation = rootFileLocation;
    }

    public String getSqliteDatabaseFileLocation() {
        return sqliteDatabaseFileLocation;
    }

    public void setSqliteDatabaseFileLocation(String sqliteDatabaseFileLocation) {
        this.sqliteDatabaseFileLocation = sqliteDatabaseFileLocation;
    }

    public String getConnectionString() {
        return connectionString;
    }

    public void setConnectionString(String connectionString) {
        this.connectionString = connectionString;
    }

    public Connection getSqliteConnection() {
        return sqliteConnection;
    }

    public void setSqliteConnection(Connection sqliteConnection) {
        this.sqliteConnection = sqliteConnection;
    }
}
