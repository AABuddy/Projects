package uk.ac.aber.cs221.group07.buccaneer_testing.tests.other;

import javafx.scene.paint.Color;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;
import uk.ac.aber.cs221.group07.buccaneer.client.utils.GameWorld;
import uk.ac.aber.cs221.group07.buccaneer.client.utils.Island;
import uk.ac.aber.cs221.group07.buccaneer.client.utils.Player;
import uk.ac.aber.cs221.group07.buccaneer.client.utils.Port;

import java.util.Arrays;

/**
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * @version 22.05.06
 * buccaneer_testing.tests.other.GameWorldTest.java 22.05.06 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class GameWorldTest {
    private final String[] playerNames = new String[]{"Patches", "Reggie", "DELL", "Optiplex"};
    private GameWorld testGameWorld = new GameWorld(playerNames);

    @Test
    @Order(1)
    public void InitialiseInvalidInstances() {
        for (int i = 0; i < playerNames.length; i++) {
            final int i2 = i;
            Assertions.assertEquals(
                    String.format("Index %d out of bounds for length %d", i, i),
                    Assertions.assertThrows(
                            IndexOutOfBoundsException.class,
                            () -> new GameWorld(
                                    Arrays.copyOfRange(playerNames, 0, i2)
                            )
                    ).getMessage()
            );
        }
    }

    @Test
    @Order(2)
    public void InitialiseValidInstances() {
        this.testGameWorld = new GameWorld(Arrays.copyOfRange(playerNames, 0, 4));
    }

    @Test
    @Order(3)
    public void TestIslands() {
        Island[] testIslands = this.testGameWorld.getIslands();
        String[] expectedIslandNames = new String[]{"Flat", "Pirate", "Treasure"};
        for (int i = 0; i < expectedIslandNames.length; i++)
            Assertions.assertEquals(expectedIslandNames[i], testIslands[i].getName());
    }

    @Test
    @Order(4)
    public void TestPorts() {
        Port[] testPorts = this.testGameWorld.getPorts();
        String[] expectedIslandNames = new String[]{"Venice", "London", "Cadiz", "Amsterdam", "Marseilles", "Genoa"};
        for (int i = 0; i < expectedIslandNames.length; i++)
            Assertions.assertTrue(Arrays.asList(expectedIslandNames).contains(testPorts[i].getName()));
    }

    @Test
    @Order(5)
    public void TestPlayers() {
        Player[] testPlayers = this.testGameWorld.getPlayers();
        Color[] expectedPlayerColours = new Color[]{Color.BLUEVIOLET, Color.ORANGE, Color.CORNFLOWERBLUE, Color.YELLOW};
        for (int i = 0; i < playerNames.length; i++)
            Assertions.assertTrue(Arrays.asList(expectedPlayerColours).contains(testPlayers[i].getColor()));
    }

    @Test
    @Order(6)
    public void TestNames() {
        String[] testNames = this.testGameWorld.getNames();
        for (int i = 0; i < playerNames.length; i++)
            Assertions.assertEquals(playerNames[i], testNames[i]);
    }
}
