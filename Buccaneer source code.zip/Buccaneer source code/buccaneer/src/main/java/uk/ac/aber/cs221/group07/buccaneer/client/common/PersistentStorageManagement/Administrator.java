package uk.ac.aber.cs221.group07.buccaneer.client.common.PersistentStorageManagement;

/*
import uk.ac.aber.cs221.group07.buccaneer.client.Lodis.Lodis;
import uk.ac.aber.cs221.group07.buccaneer.client.Lodis.common.exceptions.LodisIOException;
import uk.ac.aber.cs221.group07.buccaneer.client.Lodis.common.exceptions.LodisKeyException;
import uk.ac.aber.cs221.group07.buccaneer.client.Lodis.common.exceptions.specific.*;
*/
public class Administrator {
    public static <T> T GetFromStore(Key key, Object defaultValue) {
        /*
        Lodis conn = null;
        Object temp = null;
        try {
            conn = new Lodis();
        } catch (LodisIOException ex) {
            ex.printStackTrace();
        }
        assert conn != null;


        try {
            if (!conn.isKeyInUse(key.name()))
                PutIntoStore(key, defaultValue);

            temp = conn.retrieve(key.name());
        } catch (LodisKeyDoesNotExistException | LodisClassMismatchException ignore) {
        } catch (LodisIOException ex) {
            ex.printStackTrace();
        }

        return (T) temp; */
        return null;
    }

    public static void PutIntoStore(Key key, Object value) {
        /*
        Lodis conn = null;
        try {
            conn = new Lodis();
        } catch (LodisIOException ex) {
            ex.printStackTrace();
        }
        assert conn != null;

        try {
            if (!conn.isKeyInUse(key.name()))
                conn.store(key.name(), value);
            else if (conn.isKeyInUse(key.name()))
                conn.update(key.name(), value);

        } catch (LodisIOException ex) {
            ex.printStackTrace();
        } catch (LodisKeyException ignored) {}
        */
    }
}
