package uk.ac.aber.cs221.group07.buccaneer_testing.tests.cards;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;
import uk.ac.aber.cs221.group07.buccaneer.client.utils.ChanceCardManager;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ChanceCardManagerTest {
    private final ChanceCardManager testChanceCardManager = new ChanceCardManager();


    @Test
    @Order(1)
    public void InitialiseInstance() {
        this.testChanceCardManager.initialize();
    }


    @Test
    @Order(2)
    public void getRandom() {
        Assertions.assertEquals(
                "Index 0 out of bounds for length 0",
                Assertions.assertThrows(IndexOutOfBoundsException.class, this.testChanceCardManager::getRandom).getMessage());
        // Assertions.assertNotNull(this.testChanceCardManager.getRandom());
    }

    @Test
    @Order(3)
    public void IsChanceCardsEmpty() {
        Assertions.assertTrue(this.testChanceCardManager.isChanceCardsEmpty());
    }
}
