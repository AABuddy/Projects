package uk.ac.aber.cs221.group07.buccaneer.client.common.PersistentStorageManagement;

public enum Key {
    CORE__SHOULD_RESTORE
}
