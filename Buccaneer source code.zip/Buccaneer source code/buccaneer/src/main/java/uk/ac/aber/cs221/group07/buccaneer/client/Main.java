package uk.ac.aber.cs221.group07.buccaneer.client;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class Main extends Application {
    public static void main(String[] args) {
//        SetShouldRestore(false);
        launch();
    }

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = getWindow();
        Scene scene = new Scene(fxmlLoader.load(), 1280, 720);
        stage.setTitle("Welcome to Buccaneer");
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();
    }

    public FXMLLoader getWindow() {
        return new FXMLLoader(Main.class.getResource(false ? "boardScreen.fxml" : "welcomeScreen.fxml"));
    }
}
