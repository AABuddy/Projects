package uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.exceptions.specific;

import uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.exceptions.LodisKeyException;

/**
 * Used to construct `LodisKeyAlreadyExistsException`
 *
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * @version 22.05.02
 * Lodis.common.exceptions.specific.LodisKeyAlreadyExistsException.java 22.05.02 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
public class LodisKeyAlreadyExistsException extends LodisKeyException {
    /**
     * This is used for when there is an attempt to store data in Lodis using a key that already exists.
     *
     * @param key the key for the data that was attempted to be stored
     */
    public LodisKeyAlreadyExistsException(String key) {
        super(new LodisKeyAlreadyExistsException(
                "The key \"" + key + "\" is already in use, please use UPDATE if you want to overwrite the data within this block."
        ));
    }
}
