/*
 * @(#) BoardController.java 1.0 | 2022/05/06 *
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved. *
 */
package uk.ac.aber.cs221.group07.buccaneer.client.controllers;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Point2D;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

import javafx.stage.Stage;
import uk.ac.aber.cs221.group07.buccaneer.client.Main;
import uk.ac.aber.cs221.group07.buccaneer.client.utils.*;

import java.io.IOException;
import java.util.*;

/**
 * @author Julia Drozdz [jud28]
 * @author Mia Sabin [mis77]
 * @author Dan Slater [dis94]
 * @version 1.0 - released.
 * BoardController is the main controller for the Buccaneer game. It manages the game assets instantiated
 * by the game world, handles battles, runs the Trading Screen and manages the game.
 * @see GameWorld
 * @see Player
 * @see Island
 * @see Port
 */
public class BoardController {
    @FXML
    private Stage stage;
    @FXML
    private GridPane grid;
    @FXML
    private VBox vboxPlayerInfo;
    @FXML
    private VBox vboxTurnOrder;
    @FXML
    private VBox vboxLocationInfo;
    @FXML
    private Label lblPlayer;
    @FXML
    private Label lblHomePort;
    @FXML
    private Label lblMovesLeft;
    @FXML
    private HBox hboxTreasures;
    @FXML
    private HBox hboxChanceCards;
    @FXML
    private HBox hboxCardValues;
    @FXML
    private HBox hboxTreasuresLocation;
    @FXML
    private Label lblHomePortInfo;
    @FXML
    private Label lblCards;
    @FXML
    private Label lblOrientation;
    @FXML
    private Label lblLocation;
    /**
     * Holds a value of 0 which represents north
     */
    public static final int NORTH = 0;
    /**
     * Holds a value of 90 which represents east
     */
    public static final int EAST = 90;
    /**
     * Holds a value of 270 which represents north
     */
    private static final int WEST = 270;
    /**
     * Holds a value of 180 which represents north
     */
    private static final int SOUTH = 180;
    /**
     * Holds a value of 45 which represents north
     */
    public static final int NORTH_EAST = 45;
    /**
     * Holds a value of 135 which represents north
     */
    public static final int SOUTH_EAST = 135;
    /**
     * Holds a value of 225 which represents north
     */
    private static final int SOUTH_WEST = 225;
    /**
     * Holds a value of 315 which represents north
     */
    private static final int NORTH_WEST = 315;
    /**
     * Holds a value of "horizontal" for the isLegalMove function
     */
    private static final String HORIZONTAL = "HORIZONTAL";

    /**
     * Holds a value of "horizontal" for the isLegalMove function
     */
    private static final String VERTICAL = "VERTICAL";
    /**
     * Holds a value of "horizontal" for the isLegalMove function
     */
    private static final String DIAGONAL = "DIAGONAL";
    private boolean hasPlayerRotated = false;
    private boolean hasPlayerMoved = false;

    // Types of objects stored: Islands, Ports, Players to make retrieving them easier for collision detection.
    private Map<Point2D, Object> objectsMap;
    // all ports need to be shifted in the x and y directions. This is important for adding new ports
    private Port[] ports;
    private Island[] islands;
    private Player[] players;

    private GameWorld gameWorld;

    // =================== Player =================== //
    private int currentPlayerID;
    private ImageView currentPlayer;
    private ImageView playerForInfo;     // player whose information is displayed in the info section

    /**
     * This Mapper class is responsible for mapping objects
     */
    private class Mapper {
        /**
         * Creates a port label with the first letter of the port name and the appropriate color
         * (color of the player that this port is a home port to or pink for tradable ports).
         *
         * @param name - name of the port
         * @return label - a label for port for player to be able to tell the ports apart.
         */
        private Label createPortLabel(String name) {
            Label label = new Label(Character.toString(name.charAt(0)));
            Color bgPortColor = Color.PINK;
            if (name == "London") bgPortColor = players[0].getColor();
            if (name == "Genoa") bgPortColor = players[1].getColor();
            if (name == "Marseilles") bgPortColor = players[2].getColor();
            if (name == "Cadiz") bgPortColor = players[3].getColor();
            label.setBackground(new Background(new BackgroundFill(bgPortColor, CornerRadii.EMPTY, Insets.EMPTY)));
            label.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT)));
            label.setPadding(new Insets(5, 10, 5, 10));
            label.setTextOverrun(OverrunStyle.CLIP);
            label.setFont(new Font("Verdana", 14));
            return label;
        }

        /**
         * Map a port to the grid at the given coordinates.
         *
         * @param x - x position of the port
         * @param y - y position of the port
         */
        private void mapPort(int x, int y) {
            for (int i = 0; i < ports.length; i++) {
                if (ports[i].getLocation().getX() == x && ports[i].getLocation().getY() == y) {
                    Label label = createPortLabel(ports[i].getName());
                    grid.setHalignment(label, HPos.CENTER);
                    grid.add(label, (int) ports[i].getLocation().getX(), (int) ports[i].getLocation().getY());
                }
            }
        }

        /**
         * Create a coordinate label for a given tile
         *
         * @param x - x position of the tile
         * @param y - y position of the tile
         * @return coordinate - label for the given coordinate (Tile on the grid)
         */
        private Label createCoordinateLabel(int x, int y) {
            int coordX = x + 1;
            int coordY = grid.getRowCount() - y;
            Label coordinate = new Label(coordX + ", " + coordY);
            coordinate.setFont(new Font("Verdana", 8));
            return coordinate;
        }

        /**
         * Map the label to the given coordinate on the grid
         *
         * @param x - x position of the tile
         * @param y - y position of the tile
         */
        private void mapLabel(int x, int y) {
            Label coordinate = createCoordinateLabel(x, y);
            grid.add(coordinate, x, y);
        }

        /**
         * Create a container on which the movePlayer function will be mapped to later
         *
         * @return container - VBox container
         */
        private VBox createMovementListenerContainer() {
            VBox container = new VBox();
            container.setCursor(Cursor.HAND);
            return container;
        }

        /**
         * Map the movement container to the grid
         *
         * @param x - x position of the container
         * @param y - y position of the container
         */
        private void mapMovementListenerContainer(int x, int y) {
            VBox vboxContainer = createMovementListenerContainer();
            grid.add(vboxContainer, x, y);
        }

        /**
         * Configure and map islands to the appropriate location on the grid
         */
        private void mapIslands() {
            for (int i = 0; i < islands.length; i++) {
                int xDiff = (int) Math.abs(islands[i].getLocation()[0].getX() - islands[i].getLocation()[1].getX());
                int yDiff = (int) Math.abs(islands[i].getLocation()[0].getY() - islands[i].getLocation()[1].getY());
                for (int j = 0; j <= xDiff; j++) {
                    for (int k = 0; k <= yDiff; k++) {
                        int x = (int) islands[i].getLocation()[0].getX() + j;
                        int y = (int) islands[i].getLocation()[0].getY() + k;
                        VBox vb = new VBox();
                        if (islands[i].equals(gameWorld.getIslandsMap().get("Flat"))) {
                            vb.setOnMouseClicked(e -> {
                                islandPopUp();
                                e.consume();
                            });

                            vb.toFront();
                            vb.setCursor(Cursor.CROSSHAIR);
                        }
                        grid.add(vb, x, y);
                    }
                }
            }
        }

        /**
         * Create a player image with the appropriate png file
         *
         * @param color - color of the player
         * @param k     - id of the player
         * @return iv - ImageView of the player
         */
        private ImageView createPlayerImage(String color, int k) {
            Image im = new Image(String.valueOf(Main.class.getResource(String.format("assets/player%s.png", color))));
            ImageView iv = new ImageView(im);
            iv.setCursor(Cursor.HAND);
            iv.setFitWidth(22);
            iv.setFitHeight(36);
            iv.setId(Integer.toString(k));
            iv.setOnMouseClicked(e -> {
                updatePlayerInfo(e);
                e.consume();
            });
            return iv;
        }

        /**
         * Maps players with the appropriate styling and attributes to the grid (row, col).
         *
         * @param x - x coordinate of the player
         * @param y - y coordinate of the player
         */
        private void mapPlayer(int x, int y) {
            for (int k = 0; k < players.length; k++) {
                if (players[k].getX() == x && players[k].getY() == y) {
                    String playerColor = "";
                    if (players[k].getColor() == Color.BLUEVIOLET) playerColor = "Purple";
                    if (players[k].getColor() == Color.ORANGE) playerColor = "Orange";
                    if (players[k].getColor() == Color.CORNFLOWERBLUE) playerColor = "Blue";
                    if (players[k].getColor() == Color.YELLOW) playerColor = "Yellow";
                    ImageView iv = createPlayerImage(playerColor, k);
                    // Rotations need to be chosen depending on where the player is spawned
                    if (players[k].getY() == 0 || players[k].getX() == 1) {
                        iv.setRotate(SOUTH);
                        players[k].setOrientation(SOUTH);
                    }
                    grid.add(iv, players[k].getX(), players[k].getY());
                }
            }
        }

        /**
         * Maps players in the turn order section
         */
        public void mapTurnOrder() {
            for (int k = 0; k < players.length; k++) {
                Button btnPlayer = new Button("P" + (k + 1) + ": " + players[k].getName());
                btnPlayer.setMaxWidth(180);
                btnPlayer.setId(Integer.toString(k));
                btnPlayer.setBackground(new Background(new BackgroundFill(players[k].getColor(), CornerRadii.EMPTY, Insets.EMPTY)));
                btnPlayer.setPadding(new Insets(10, 20, 10, 20));
                vboxTurnOrder.getChildren().addAll(btnPlayer);
            }
        }
    }

    /**
     * This function initializes the board controller with new values using the game world controller
     *
     * @param names - names of the players passed in from the setting usernames
     */
    public void initializeData(String[] names) {
        this.gameWorld = new GameWorld(names);
        this.islands = this.gameWorld.getIslands();
        this.players = this.gameWorld.getPlayers();
        this.ports = this.gameWorld.getPorts();
        this.initializeGame();
    }

    /**
     * Runs the BoardController with a given gameWorld
     *
     * @param gameWorld - game world with previously set values (skipping the initialization phase)
     */
    public void resumeGame(GameWorld gameWorld) {
        this.gameWorld = gameWorld;
        this.islands = this.gameWorld.getIslands();
        this.players = this.gameWorld.getPlayers();
        this.ports = this.gameWorld.getPorts();
        this.initializeGame();
    }

    /**
     * This function is responsible for initializing players (location, player in turn) and
     * mapping objects to the grid on the Board Screen.
     *
     * @see Mapper
     */
    public void initializeGame() {
        initializePlayers();
        // players[0].setLocation(new Point2D(10, 15)); // Overwrite the players location for testing
        instantiateObjectsMap();
        Mapper mapper = new Mapper();
        for (int x = 0; x < grid.getColumnCount(); x++) {
            for (int y = 0; y < grid.getRowCount(); y++) {
                // mapper.mapLabel(x, y);
                mapper.mapMovementListenerContainer(x, y);
                mapper.mapPort(x, y);
                mapper.mapPlayer(x, y);
            }
        }
        addMovementListener();
        mapper.mapIslands();
        mapper.mapTurnOrder();
        initializeCurrentPlayer();
        this.setVboxPlayerInfo();
        this.setVboxLocationInfo();
    }

    /**
     * Initialize the first player at the beginning of the game
     */
    public void initializeCurrentPlayer() {
        currentPlayerID = 0; // needs to come from the database
        currentPlayer = (ImageView) findObject(ImageView.class, players[currentPlayerID].getX(), players[currentPlayerID].getY());
        playerForInfo = currentPlayer;
        markPossibleTiles();
    }


    /**
     * Instantiate the object map where all the objects from the game will be put. This map is used for collision detection
     */
    public void instantiateObjectsMap() {
        objectsMap = new HashMap<>();
        for (int i = 0; i < ports.length; i++) {
            objectsMap.put(ports[i].getLocation(), ports[i]);
        }
        for (int i = 0; i < islands.length; i++) {
            int xDiff = (int) Math.abs(islands[i].getLocation()[0].getX() - islands[i].getLocation()[1].getX());
            int yDiff = (int) Math.abs(islands[i].getLocation()[0].getY() - islands[i].getLocation()[1].getY());
            for (int j = 0; j <= xDiff; j++) {
                for (int k = 0; k <= yDiff; k++) {
                    int x = (int) islands[i].getLocation()[0].getX() + j;
                    int y = (int) islands[i].getLocation()[0].getY() + k;
                    objectsMap.put(new Point2D(x, y), islands[i].getName());
                }
            }
        }
        for (int i = 0; i < players.length; i++) {
            objectsMap.put(new Point2D(players[i].getX(), players[i].getY()), players[i]);
        }
    }

    /**
     * Initializes location and moves remaining for players
     */
    public void initializePlayers() {
        for (int i = 0; i < players.length; i++) {
            players[i].setMovesRemaining();
            Point2D playerLocation = setPlayerLocation(players[i].getHomePort());
            players[i].setLocation(playerLocation);
        }
    }

    /**
     * This function makes sure that at the beginning of the game
     * the location of the player should be next to their home port.
     *
     * @param port - home port of the player
     * @return location that the player should be mapped to
     */
    private Point2D setPlayerLocation(Port port) {
        double playerX = 0;
        double playerY = 0;
        playerX = port.getLocation().getX() + 1;
        if (playerX > grid.getColumnCount() - 1) {
            playerX = port.getLocation().getX() - 1;
        }
        playerY = port.getLocation().getY();
        return new Point2D(playerX, playerY);
    }


    /**
     * When clicking on a tile represented by the VBox the movePlayer function will be called.
     */
    public void addMovementListener() {
        grid.getChildren().forEach(item -> {
            if (item.getClass() == VBox.class) {
                item.setOnMouseClicked(e -> {
                    movePlayer(grid.getColumnIndex(item), grid.getRowIndex(item));
                });
            }
        });
    }
    // ================ INFORMATION DISPLAYED TO USER ==================== //

    /**
     * Update the player info for the player  the user chose
     *
     * @param e
     */
    public void updatePlayerInfo(MouseEvent e) {
        playerForInfo = (ImageView) e.getTarget();
        setVboxPlayerInfo();
        setVboxLocationInfo();
    }


    /**
     * Create an ImageView of the treasure of the given type
     *
     * @param type - treasure type
     * @return iv - ImageView of the treasure of the given type
     */
    private ImageView createTreasureImage(TreasureType type) {
        Image im = new Image(String.valueOf(Main.class.getResource(String.format("assets/%s.jpg", type.toString()))));
        ImageView iv = new ImageView(im);
        return iv;
    }

    /**
     * Set the Player info section with the appropriate data
     */
    public void setVboxPlayerInfo() {
        int playerForInfoId = Integer.valueOf(playerForInfo.getId());
        vboxPlayerInfo.setAlignment(Pos.TOP_LEFT);
        Player player = players[playerForInfoId];
        lblPlayer.setText(player.getName());
        lblPlayer.setStyle("-fx-font: 24px arial");
        lblMovesLeft.setText("Moves remaining: " + player.getMovesRemaining());
        player.getInventory().getTreasures().forEach(treasure -> {
            ImageView iv = createTreasureImage(treasure.getType());
            hboxTreasures.getChildren().add(iv);
        });
        lblLocation.setText(String.format("Location: %d, %d", player.getX() + 1, grid.getRowCount() - player.getY()));
        String rotation = "";
        switch (player.getOrientation()) {
            case NORTH -> rotation = "North";
            case NORTH_EAST -> rotation = "North-East";
            case NORTH_WEST -> rotation = "North-West";
            case SOUTH -> rotation = "South";
            case SOUTH_EAST -> rotation = "South-East";
            case SOUTH_WEST -> rotation = "South-West";
            case WEST -> rotation = "West";
            case EAST -> rotation = "East";
        }
        lblOrientation.setText("Orientation: " + rotation);
        lblHomePort.setText("Home port: " + player.getHomePort().getName());
        player.getInventory().getChanceCards().forEach(chanceCard -> {
            Label label = new Label("Chance Card");
            hboxChanceCards.getChildren().add(label);
        });
        this.vboxPlayerInfo.setBackground(new Background(new BackgroundFill(player.getColor(), CornerRadii.EMPTY, Insets.EMPTY)));
    }

    /**
     * Displays information about players home port
     */
    public void setVboxLocationInfo() {
        int playerForInfoId = Integer.valueOf(playerForInfo.getId());
        Port homePort = players[playerForInfoId].getHomePort();
        lblHomePortInfo.setText(homePort.getName() + " info");
        lblHomePortInfo.setStyle("-fx-font: 24px arial");
        homePort.getTreasures().forEach(treasure -> {
            ImageView iv = createTreasureImage(treasure.getType());
            hboxTreasuresLocation.getChildren().add(iv);
        });
        lblCards.setText("Cards amount:  " + homePort.getCrewCards().size());
        homePort.getCrewCards().forEach(crewCard -> {
            Label lblCrewCard = new Label(Integer.toString(crewCard.getValue()));
            lblCrewCard.setPadding(new Insets(5));

            lblCrewCard.setBorder(new Border(new BorderStroke(crewCard.getColor(), BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT)));
            hboxCardValues.getChildren().add(lblCrewCard);
        });
        this.vboxLocationInfo.setBackground(new Background(new BackgroundFill(players[playerForInfoId].getColor(), CornerRadii.EMPTY, Insets.EMPTY)));
    }

    // ======================== TURN MANAGEMENT ========================== //

    /**
     * When switching to the next player the tiles should be unmarked and marked and  labels should display
     * the appropriate information
     */
    public void setNextPlayerInTurn() {
        this.unmarkTiles();
        currentPlayerID++;
        currentPlayerID = currentPlayerID % players.length;
        players[currentPlayerID].setMovesRemaining();
        currentPlayer = (ImageView) findObject(ImageView.class, players[currentPlayerID].getX(), players[currentPlayerID].getY());
        playerForInfo = currentPlayer;
        hasPlayerMoved = false;
        hasPlayerRotated = false;
        this.markPossibleTiles();
        this.setVboxPlayerInfo();
        this.setVboxLocationInfo();
    }

//    private void debug(int a, int b) {
//        System.out.println(a + ", " + b);
//    }

    /**
     * Allows to find the object in the grid
     * The complexity of this function is O(n^2) but could possibly be changed by using a map.
     *
     * @param targetClass - the class of the object we are looking for, eg. VBox for tiles, ImageView for player.
     * @param coordX      - position X of the object we are looking for
     * @param coordY      - position Y of the object we are looking for
     * @return object - the target object
     */
    private Node findObject(Class targetClass, int coordX, int coordY) {
        Node object = null;
        ObservableList<Node> children = grid.getChildren();
        for (Node node : children) {
            // row index is the Y coordinate, column is the X
            if (node.getClass() == targetClass && grid.getColumnIndex(node) == coordX && grid.getRowIndex(node) == coordY) {
                object = node;
                break;
            }
        }
        return object;
    }
    // ================================ TILES ================================== //

    /**
     * Marks the tiles a player can move into
     */
    public void markPossibleTiles() {
        for (int i = 0; i < players[currentPlayerID].getMovesRemaining(); i++) {
            int tileX = 0;
            int tileY = 0;
            switch ((int) currentPlayer.getRotate()) {
                case NORTH:
                    tileX = grid.getColumnIndex(currentPlayer);
                    tileY = grid.getRowIndex(currentPlayer) - (i + 1);
                    break;
                case SOUTH:
                    tileX = grid.getColumnIndex(currentPlayer);
                    tileY = grid.getRowIndex(currentPlayer) + (i + 1);
                    break;
                case EAST:
                    tileX = grid.getColumnIndex(currentPlayer) + (i + 1);
                    tileY = grid.getRowIndex(currentPlayer);
                    break;
                case WEST:
                    tileX = grid.getColumnIndex(currentPlayer) - (i + 1);
                    tileY = grid.getRowIndex(currentPlayer);
                    break;
                case NORTH_EAST:
                    tileX = grid.getColumnIndex(currentPlayer) + (i + 1);
                    tileY = grid.getRowIndex(currentPlayer) - (i + 1);
                    break;
                case SOUTH_WEST:
                    tileX = grid.getColumnIndex(currentPlayer) - (i + 1);
                    tileY = grid.getRowIndex(currentPlayer) + (i + 1);
                    break;
                case NORTH_WEST:
                    tileX = grid.getColumnIndex(currentPlayer) - (i + 1);
                    tileY = grid.getRowIndex(currentPlayer) - (i + 1);
                    break;
                case SOUTH_EAST:
                    tileX = grid.getColumnIndex(currentPlayer) + (i + 1);
                    tileY = grid.getRowIndex(currentPlayer) + (i + 1);
                    break;
            }
            if (tileY < 0 || tileY > grid.getRowCount() - 1 || tileX < 0 || tileX > grid.getColumnCount()) {
                break;
            }
            VBox tile = (VBox) findObject(VBox.class, tileX, tileY);
            if (tile != null) {
                tile.setStyle("-fx-background-color: lightgreen; -fx-text-fill: white;");
            }
        }
    }

    /**
     * Unmark the tiles after the player moves/rotates
     */
    public void unmarkTiles() {
        for (int i = 0; i < players[currentPlayerID].getMovesRemaining(); i++) {
            int tileX = 0;
            int tileY = 0;
            switch ((int) currentPlayer.getRotate()) {
                case NORTH:
                    tileX = grid.getColumnIndex(currentPlayer);
                    tileY = grid.getRowIndex(currentPlayer) - (i) - 1;
                    break;
                case SOUTH:
                    tileX = grid.getColumnIndex(currentPlayer);
                    tileY = grid.getRowIndex(currentPlayer) + (i) + 1;
                    break;
                case EAST:
                    tileX = grid.getColumnIndex(currentPlayer) + i + 1;
                    tileY = grid.getRowIndex(currentPlayer);
                    break;
                case WEST:
                    tileX = grid.getColumnIndex(currentPlayer) - i - 1;
                    tileY = grid.getRowIndex(currentPlayer);
                    break;
                case NORTH_EAST:
                    tileX = grid.getColumnIndex(currentPlayer) + i + 1;
                    tileY = grid.getRowIndex(currentPlayer) - (i) - 1;
                    break;
                case SOUTH_WEST:
                    tileX = grid.getColumnIndex(currentPlayer) - i - 1;
                    tileY = grid.getRowIndex(currentPlayer) + (i) + 1;
                    break;
                case NORTH_WEST:
                    tileX = grid.getColumnIndex(currentPlayer) - i - 1;
                    tileY = grid.getRowIndex(currentPlayer) - (i) - 1;
                    break;
                case SOUTH_EAST:
                    tileX = grid.getColumnIndex(currentPlayer) + i + 1;
                    tileY = grid.getRowIndex(currentPlayer) + (i) + 1;
                    break;
            }
            if (tileY < 0 || tileY > grid.getRowCount() - 1 || tileX < 0 || tileX > grid.getColumnCount()) {
                break;
            }
            VBox tile = (VBox) findObject(VBox.class, tileX, tileY);
            if (tile != null) {
                tile.setStyle("-fx-background-color: none; -fx-text-fill: white;");
            }
        }
    }

    // ============================ PLAYER MOVEMENT =========================== //

    /**
     * Check if the coordinates the player wants to move into are valid
     *
     * @param x         - the x that the player wants to move into
     * @param y         - the y that the player wants to move into
     * @param direction - the direction in which the isLegalMove will check for collision detection
     *                  - the valid options are: HORIZONTAL, VERTICAL, DIAGONAL
     * @return true if it is a legal move, false otherwise
     */
    private boolean isLegalMove(int x, int y, String direction) {
        // this function needs to ignore players because it detects the current player as a separate object
        int directionX = 1;
        int directionY = 1;
        if (currentPlayer.getRotate() == EAST || currentPlayer.getRotate() == SOUTH_EAST || currentPlayer.getRotate() == NORTH_EAST)
            directionX = 1;
        if (currentPlayer.getRotate() == WEST || currentPlayer.getRotate() == SOUTH_WEST || currentPlayer.getRotate() == NORTH_WEST)
            directionX = -1;
        if (currentPlayer.getRotate() == NORTH || currentPlayer.getRotate() == NORTH_EAST || currentPlayer.getRotate() == NORTH_WEST)
            directionY = -1;
        if (currentPlayer.getRotate() == SOUTH || currentPlayer.getRotate() == SOUTH_EAST || currentPlayer.getRotate() == SOUTH_WEST)
            directionY = 1;
        switch (direction) {
            case HORIZONTAL:
                for (int i = 1; i <= Math.abs(grid.getColumnIndex(currentPlayer) - x); i++) {
                    if (objectsMap.get(new Point2D(grid.getColumnIndex(currentPlayer) + (i * directionX), y)) != null && objectsMap.get(new Point2D(grid.getColumnIndex(currentPlayer) + (i * directionX), y)).getClass() != Player.class)
                        return false;
                }
                break;
            case VERTICAL:
                for (int i = 1; i <= Math.abs(grid.getRowIndex(currentPlayer) - y); i++) {
                    if (objectsMap.get(new Point2D(x, grid.getRowIndex(currentPlayer) + (i * directionY))) != null && objectsMap.get(new Point2D(x, grid.getRowIndex(currentPlayer) + (i * directionY))).getClass() != Player.class)
                        return false;
                }
                break;
            case DIAGONAL:
                int i = 1;
                int j = 1;
                while (i <= Math.abs(grid.getColumnIndex(currentPlayer) - x)) {
                    i++;
                    j++;
                    if (objectsMap.get(new Point2D(grid.getColumnIndex(currentPlayer) + (i * directionX), grid.getRowIndex(currentPlayer) + (j * directionY))) != null && objectsMap.get(new Point2D(grid.getColumnIndex(currentPlayer) + (i * directionX), grid.getRowIndex(currentPlayer) + (j * directionY))) != Player.class)
                        return false;
                }
                break;

        }
        return true;
    }

    /**
     * Moves the player to new coordinates x and y.
     *
     * @param x - the target x location
     * @param y - the target y location
     */
    public void movePlayer(int x, int y) {
        if (hasPlayerMoved) {
            return;
        }
        switch ((int) currentPlayer.getRotate()) {
            case NORTH:
                if (!isLegalMove(x, y, VERTICAL) || grid.getColumnIndex(currentPlayer) - x != 0 || grid.getRowIndex(currentPlayer) - y > players[currentPlayerID].getMovesRemaining() || grid.getRowIndex(currentPlayer) - y < 0) {
                    return;
                }
                break;
            case SOUTH:
                if (!isLegalMove(x, y, VERTICAL) || grid.getColumnIndex(currentPlayer) - x != 0 || grid.getRowIndex(currentPlayer) - y < -players[currentPlayerID].getMovesRemaining() || grid.getRowIndex(currentPlayer) - y > 0) {
                    return;
                }
                break;
            case EAST:
                if (!isLegalMove(x, y, HORIZONTAL) || grid.getRowIndex(currentPlayer) - y != 0 || grid.getColumnIndex(currentPlayer) - x > players[currentPlayerID].getMovesRemaining() || grid.getColumnIndex(currentPlayer) - x > 0) {
                    return;
                }
                break;
            case WEST:
                if (!isLegalMove(x, y, HORIZONTAL) || grid.getRowIndex(currentPlayer) - y != 0 || grid.getColumnIndex(currentPlayer) - x < -players[currentPlayerID].getMovesRemaining() || grid.getColumnIndex(currentPlayer) - x < 0) {
                    return;
                }
                break;
            case NORTH_EAST:
                if (!isLegalMove(x, y, DIAGONAL) || grid.getRowIndex(currentPlayer) - y == 0 || grid.getColumnIndex(currentPlayer) - x == 0 || grid.getColumnIndex(currentPlayer) - x > players[currentPlayerID].getMovesRemaining() || grid.getColumnIndex(currentPlayer) - x > 0 || grid.getRowIndex(currentPlayer) - y > players[currentPlayerID].getMovesRemaining() || grid.getRowIndex(currentPlayer) - y < 0 || grid.getRowIndex(currentPlayer) - y != -(grid.getColumnIndex(currentPlayer) - x)) {
                    return;
                }
                break;
            case SOUTH_WEST:
                if (!isLegalMove(x, y, DIAGONAL) || grid.getRowIndex(currentPlayer) - y == 0 || grid.getColumnIndex(currentPlayer) - x == 0 || grid.getRowIndex(currentPlayer) - y < -players[currentPlayerID].getMovesRemaining() || grid.getRowIndex(currentPlayer) - y > 0 || grid.getColumnIndex(currentPlayer) - x < -players[currentPlayerID].getMovesRemaining() || grid.getColumnIndex(currentPlayer) - x < 0 || -(grid.getRowIndex(currentPlayer) - y) != grid.getColumnIndex(currentPlayer) - x) {
                    return;
                }
                break;
            case NORTH_WEST:
                if (!isLegalMove(x, y, DIAGONAL) || grid.getRowIndex(currentPlayer) - y == 0 || grid.getColumnIndex(currentPlayer) - x == 0 || grid.getRowIndex(currentPlayer) - y > players[currentPlayerID].getMovesRemaining() || grid.getRowIndex(currentPlayer) - y < 0 || grid.getColumnIndex(currentPlayer) - x < -players[currentPlayerID].getMovesRemaining() || grid.getColumnIndex(currentPlayer) - x < 0 || grid.getRowIndex(currentPlayer) - y != grid.getColumnIndex(currentPlayer) - x) {
                    return;
                }
                break;
            case SOUTH_EAST:
                if (!isLegalMove(x, y, DIAGONAL) || grid.getRowIndex(currentPlayer) - y == 0 || grid.getColumnIndex(currentPlayer) - x == 0 || grid.getRowIndex(currentPlayer) - y < -players[currentPlayerID].getMovesRemaining() || grid.getRowIndex(currentPlayer) - y > 0 || grid.getColumnIndex(currentPlayer) - x > players[currentPlayerID].getMovesRemaining() || grid.getColumnIndex(currentPlayer) - x > 0 || grid.getRowIndex(currentPlayer) - y != grid.getColumnIndex(currentPlayer) - x) {
                    return;
                }
                break;
        }
        // Check if player is at a port, if they are at their home port unload all the treasures and check
        // if the game ended, otherwise trade.
        if (getPortPlayerIsAt(x, y) != null) {
            if (getPortPlayerIsAt(x, y).equals(players[currentPlayerID].getHomePort())) {
                checkIfEndOfGame();
            } else {
                initializeTrade();
            }
        }
        this.unmarkTiles();
        // Update the map of the objects
        objectsMap.remove(players[currentPlayerID].getLocation());
        players[currentPlayerID].setLocation(new Point2D(x, y));
        objectsMap.put(players[currentPlayerID].getLocation(), players[currentPlayerID]);
        grid.setColumnIndex(currentPlayer, x);
        grid.setRowIndex(currentPlayer, y);
        hasPlayerMoved = true;
        currentPlayer.toFront();
        this.markPossibleTiles();
        checkIfAtTreasureIsland(x, y);//Start the chance card management
        InitiateBattle();
    }
    // ============================ PLAYER ROTATION =========================== //

    /**
     * Rotates the current player to  East
     */
    public void rotateEast(ActionEvent actionEvent) {
        rotatePlayer(EAST);
    }

    /**
     * Rotates the current player to  North
     */
    public void rotateNorth(ActionEvent actionEvent) {
        rotatePlayer(NORTH);
    }

    /**
     * Rotates the current player to  West
     */
    public void rotateWest(ActionEvent actionEvent) {
        rotatePlayer(WEST);
    }

    /**
     * Rotates the current player to  South
     */
    public void rotateSouth(ActionEvent actionEvent) {
        rotatePlayer(SOUTH);
    }

    /**
     * Rotates the current player to  North East
     */
    public void rotateNorthEast(ActionEvent actionEvent) {
        rotatePlayer(NORTH_EAST);
    }

    /**
     * Rotates the current player to  North West
     */
    public void rotateNorthWest(ActionEvent actionEvent) {
        rotatePlayer(NORTH_WEST);
    }

    /**
     * Rotates the current player to  South West
     */
    public void rotateSouthWest(ActionEvent actionEvent) {
        rotatePlayer(SOUTH_WEST);
    }

    /**
     * Rotates the current player to South East
     */
    public void rotateSouthEast(ActionEvent actionEvent) {
        rotatePlayer(SOUTH_EAST);
    }

    /**
     * Rotate player in the given direction, mark and unmark tiles
     *
     * @param targetDirection
     */
    public void rotatePlayer(int targetDirection) {
        if (!canPlayerRotate()) {
            return;
        }
        this.unmarkTiles();
        currentPlayer.setRotate(targetDirection);
        players[currentPlayerID].setOrientation(targetDirection);
        this.markPossibleTiles();
        hasPlayerRotated = true;
        setNextPlayerInTurn();
    }

    /**
     * Checks the surrounding of the player for ports or islands, if a location is found, the player cannot rotate
     *
     * @return true if the player can rotate, false otherwise: the player has rotated already or they are next to a port
     */
    private boolean canPlayerRotate() {
        // only allow rotating the player if they have moved and not rotated before
        if (hasPlayerRotated) {
            return false;
        }
        if (!hasPlayerMoved) return false;
        // Check for ports around the player
        for (int i = grid.getColumnIndex(currentPlayer) - 1; i <= grid.getColumnIndex(currentPlayer) + 1; i++) {
            for (int j = grid.getRowIndex(currentPlayer) - 1; j <= grid.getRowIndex(currentPlayer) + 1; j++) {
                if (objectsMap.get(new Point2D(i, j)) != null) {
                    if (objectsMap.get(new Point2D(i, j)).getClass() == Port.class) {
                        return false;
                    }
                }
            }
        }
        return true;
    }


    // ================ End of the game listener ============= //

    /**
     * Check if the player has enough value in the treasures for the game to end,
     * if not deposit to their home port
     */
    public void checkIfEndOfGame() {
        // testEndScreen(); // adds treasures to player's home port (end game popup condition)
        int tempVal = 0;
        for (int i = 0; i < players[currentPlayerID].getHomePort().getTreasures().size(); i++) {
            tempVal = tempVal + players[currentPlayerID].getHomePort().getTreasures().get(i).getValue();
        }
        if (tempVal >= 20) {
            showEndScreen();
            //Do end game thingy (Display end Screen)
        } else { //deposit Treasure to the dock}
            System.out.println("Deposit to Port"); //remove this
            ArrayList<Treasure> playerTreasures = players[currentPlayerID].getInventory().getTreasures();
            players[currentPlayerID].getInventory().setTreasures(new ArrayList<>(Inventory.NUM_OF_TREASURES));
            players[currentPlayerID].getHomePort().getTreasures().addAll(playerTreasures);
        }
    }

    /**
     * Show the end screen popup
     */
    public void showEndScreen() {
        ButtonType startNew = new ButtonType("Start New Game"); // The screen for the main menu appears.
        ButtonType exit = new ButtonType("Exit");
        stage = (Stage) (lblOrientation.getScene().getWindow());
        Alert alert = new Alert(Alert.AlertType.INFORMATION, String.format("\nGame Over! The winner is: %s \n\nWhat would you like to do next? \n", players[currentPlayerID].getName()), startNew, exit);
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == startNew) {
            stage.getScene();

            try {
                FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("boardScreen.fxml"));
                Parent boardViewParent = fxmlLoader.load();
                BoardController controller = fxmlLoader.getController();
                controller.initializeData(gameWorld.getNames());
                Scene scene = new Scene(boardViewParent);
                stage.setTitle("Buccaneer");
                stage.setResizable(false);
                stage.setScene(scene);
                stage.show();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            stage.close();
        }
    }

    /**
     * To test the end screen the current player needs treasures with a value greater than 20
     */
    public void testEndScreen() {
        players[currentPlayerID].getHomePort().getTreasures().add(new Treasure(TreasureType.DIAMOND));
        players[currentPlayerID].getHomePort().getTreasures().add(new Treasure(TreasureType.DIAMOND));
        players[currentPlayerID].getHomePort().getTreasures().add(new Treasure(TreasureType.DIAMOND));
        players[currentPlayerID].getHomePort().getTreasures().add(new Treasure(TreasureType.DIAMOND));
    }

    /**
     * Checks the player's surroundings for a port
     *
     * @param x - x location of the player
     * @param y - y location of the player
     * @return port - the port the player is at
     */
    public Port getPortPlayerIsAt(int x, int y) {
        Port port = null;
        for (int i = x - 1; i <= x + 1; i++) {
            for (int j = y - 1; j <= y + 1; j++) {
                if (objectsMap.get(new Point2D(i, j)) != null && objectsMap.get(new Point2D(i, j)).getClass().equals(Port.class)) {
                    port = (Port) objectsMap.get(new Point2D(i, j));
                }
            }
        }
        return port;
    }

    // ========================= TRADING ======================= //

    /**
     * Initialize the trading screen
     */
    public void initializeTrade() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("tradingScreen.fxml"));
            Parent boardViewParent = fxmlLoader.load();
            TradingController controller = fxmlLoader.getController();
            // Change this to getPortPlayerIsAt and move the initializeTrade to movePlayer
            gameWorld.updateGameWorld(islands, ports, players);
            //Port port = getPortPlayerIsAt(players[currentPlayerID].getX(), players[currentPlayerID].getY());
            controller.initialise(players[currentPlayerID], ports[4], this.gameWorld);
            stage = (Stage) (lblOrientation.getScene().getWindow());
            Scene scene = new Scene(boardViewParent);
            stage.setTitle("Buccaneer");
            stage.setResizable(false);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    //=================================== BATTLE ====================================//

    /**
     * Initiate a battle with the other player
     */
    public void InitiateBattle() {
        int currentPlayerX = players[currentPlayerID].getX();
        int currentPlayerY = players[currentPlayerID].getY();
        for (int i = 0; i < 3; i++) {
            if (i != currentPlayerID) {
                int checkX = players[i].getX();
                int checkY = players[i].getY();
                if (checkX == currentPlayerX && checkY == currentPlayerY) {
                    ButtonType battle = new ButtonType("Ready To Attack!");
                    ButtonType flee = new ButtonType("Flee From Battle");
                    Alert initiateBattleAlert = new Alert(Alert.AlertType.CONFIRMATION, "\n Are you sure you would like to initiate in Battle? \n", battle, flee);
                    Optional<ButtonType> result = initiateBattleAlert.showAndWait();
                    if (result.get() == battle) {
                        battle(i);
                    }
                }
            }
        }
    }

    /**
     * This function handles all the functionality related to a battle such as:
     * - determining the winner and loser
     * - taking treasures or crew cards and adding them to the winner
     * - sets the loser as the player in turn
     *
     * @param enemyPlayer - id of the enemy player
     */
    public void battle(int enemyPlayer) {
        Player battleWinner = null;
        Player battleLoser = null;
        int loserId = 0;
        int winnerId = 0;
        if (players[currentPlayerID].getFightingStrength() > players[enemyPlayer].getFightingStrength()) {
            battleWinner = players[currentPlayerID];
            battleLoser = players[enemyPlayer];
            loserId = enemyPlayer;
        } else if (players[currentPlayerID].getFightingStrength() <= players[enemyPlayer].getFightingStrength()) {
            battleWinner = players[enemyPlayer];
            battleLoser = players[currentPlayerID];
            loserId = currentPlayerID;
        }
        battleLoser.getInventory().getTreasures().add(new Treasure(TreasureType.DIAMOND));
        battleLoser.getInventory().getTreasures().add(new Treasure(TreasureType.RUBY));
        //button label
        ButtonType exit = new ButtonType("Exit");
        //alert pop up
        Alert endOfBattleAlert = new Alert(Alert.AlertType.INFORMATION, "Player " + battleWinner.getName() + " has won the battle!\nPlayer " + battleLoser.getName() + " must now move their ship and hand over their treasure!", exit);
        endOfBattleAlert.showAndWait();
        ArrayList<Treasure> loserTreasure = battleLoser.getInventory().getTreasures();
        ArrayList<Treasure> winnerTreasure = battleWinner.getInventory().getTreasures();
        //if the battle loser has treasure in inventory
        if (loserTreasure != null) {
            //if the battle winners treasure inventory is full
            if (battleWinner.getInventory().getTreasures().size() == 2) {
                //need to put treasure on treasure island
                ArrayList<CrewCard> takenCrewCards = battleLoser.getInventory().takeCrewCards();
            }
            //if the battle winner has room for treasure
            else if (battleWinner.getInventory().getTreasures().size() < 2) {
                Treasure takeLoserTreasure = battleLoser.getInventory().takeTreasure();
                winnerTreasure.add(takeLoserTreasure);
            }
            //if the loser has no treasure but has crew cards
        } else if (loserTreasure.size() == 0 && battleLoser.getInventory().getCrewCards() != null) {
            ArrayList<CrewCard> takenCrewCards = battleLoser.getInventory().takeCrewCards();
            int winnerCrewCards = battleWinner.getInventory().getCrewCards().size();
            // if battle winners crew cards are full
            if (winnerCrewCards == 5) {
                //put crew cards on pirate island
            }
            //if battle winner has space for more crew cards
            if (winnerCrewCards < 5) {
                for (CrewCard takenCrewCard : takenCrewCards) {
                    ArrayList<CrewCard> givenCrewCards = battleWinner.getInventory().getCrewCards();
                    givenCrewCards.add(takenCrewCard);
                }
            }
        }
        //if the loser has no treasure and no cards to give away
        else if (loserTreasure.size() == 0 && battleLoser.getInventory().getCrewCards() == null) {
            //nothing is given to battle winner?
        }
        this.unmarkTiles();
        currentPlayer = (ImageView) findObject(ImageView.class, battleLoser.getX(), battleLoser.getY());
        currentPlayerID = loserId;
        playerForInfo = currentPlayer;
        hasPlayerMoved = false;
        hasPlayerRotated = false;
        this.markPossibleTiles();
        this.setVboxPlayerInfo();
        this.setVboxLocationInfo();
        currentPlayer.toFront();
    }

    //==============================ISLAND POP UP=================================//

    /**
     * Show the island popup that displays information about the Flat Island
     */
    public void islandPopUp() {
        //creates a string of all the treasures being stored in the island
        ArrayList<Treasure> islandTreasure = gameWorld.getIslandsMap().get("Flat").getTreasures();
        StringBuilder treasures = new StringBuilder();
        for (Treasure treasure : islandTreasure) {
            String currentTreasure = treasure.getType().toString();
            treasures.append(currentTreasure).append(" ,");
        }
        //creates a string of all the cards being stored at the island
        ArrayList<CrewCard> islandChanceCards = gameWorld.getIslandsMap().get("Flat").getCards();
        int numberOfCards = 0;
        StringBuilder cardsValues = new StringBuilder();
        for (CrewCard islandChanceCard : islandChanceCards) {
            numberOfCards++;
            cardsValues.append(islandChanceCard.getValue()).append(" ,");
        }
        //removes the comma from the end of the list of treasures/cards
        StringBuffer treasureBuffer = new StringBuffer(treasures);
        treasureBuffer.deleteCharAt(treasureBuffer.length() - 1);
        StringBuffer cardBuffer = new StringBuffer(cardsValues);
        cardBuffer.deleteCharAt(cardBuffer.length() - 1);
        //alert pop up
        Alert islandAlert = new Alert(Alert.AlertType.INFORMATION);
        islandAlert.setTitle("Island Information");
        islandAlert.setHeaderText("Island Information");
        islandAlert.setContentText("Treasures: " + treasureBuffer + "\nNumber Of Cards: " + numberOfCards + "\nCard Values: " + cardBuffer);
        islandAlert.showAndWait();
    }

    //=============================CHANCE CARD MANAGEMENT====================== //

    /**
     * Checks if the player is at the Treasure Island and takes a random chance card from it.
     *
     * @param x - x location of the player
     * @param y - y location of the player
     */
    void checkIfAtTreasureIsland(int x, int y) {
        if ((x == 9 && y == 12) || (x == 10 && y == 12) || (x == 9 && y == 7) || (x == 10 && y == 7) || (x == 12 && y == 9) || (x == 12 && y == 10) || (x == 7 && y == 9) || (x == 7 && y == 10)) {
            int playerChoice = 0;
            ChanceCard takenCard = gameWorld.getIslandsMap().get("Treasure").getChanceCards().remove(0);
            int numOfTreasures = players[currentPlayerID].getInventory().getTreasures().size();
            switch (takenCard.getId()) {
                case (28)://Take 2 crew cards from Pirate Island
                    executeChanceCard(0, 2, 0);
                    chanceCardDetails("You recieved 2 Crew cards from treasure island!");
                    break;

                case (15)://Take 2 crew cards from Pirate Island
                    executeChanceCard(0, 2, 0);
                    break;

                case (14): //Take treasure up to 7 in total value, or 3 crew cards from Pirate Island.
                    playerChoice = chanceCardChoice("You can either pick:\n\n- 2 Random Treasures\n\n or \n\n- 3 Random Crew Cards\n\nWhat do you want?\n");
                    executeChanceCard(playerChoice, 3, 2);
                    break;

                case (13)://Take treasure up to 5 in total value, or 2 crew cards from Pirate Island.
                    playerChoice = chanceCardChoice("You can either pick:\n\n- 1 Random Treasure\n\n or \n\n- 2 Random Crew Cards\n\nWhat do you want?\n");
                    executeChanceCard(playerChoice, 2, 1);
                    break;

                case (12)://Take treasure up to 4 in total value, or 2 crew cards from Pirate Island
                    playerChoice = chanceCardChoice("You you can either pick:\n\n- 1 Random Treasure\n\n or \n\n- 2 Random Crew Cards\n\nWhat do you want?\n");
                    executeChanceCard(playerChoice, 2, 1);
                    break;
                case (11)://Take treasure up to 5 in total value, or 2 crew cards from Pirate Island.
                    playerChoice = chanceCardChoice("You can either pick:\n\n- 1 Random Treasure\n\n or \n\n- 2 Random Crew Cards\n\nWhat do you want?\n");
                    executeChanceCard(playerChoice, 2, 1);
            }

        }
    }

    /**
     * Gives the player the choice of picking treasure or cards
     *
     * @param text - text of the chance card
     * @(return 1 for treasure / 0 for cards
     */
    public int chanceCardChoice(String text) {
        ButtonType treasure = new ButtonType("Treasure");
        ButtonType card = new ButtonType("CrewCard");
        Alert chanceCard = new Alert(Alert.AlertType.CONFIRMATION, "", treasure, card);
        chanceCard.setHeaderText("Chance Card");
        chanceCard.setContentText(text);
        Optional<ButtonType> result = chanceCard.showAndWait();
        if (result.get() == treasure) {
            return 1;
        } else {
            return 0;
        }
    }

    /**
     * Sets the details of the chance card in the alert
     *
     * @param text - chance card text
     */
    void chanceCardDetails(String text) { //Gives the player the choice of picking treasure or cards (return 1 for treasure / 0 for cards
        ButtonType ok = new ButtonType("Ok");
        Alert chanceCard = new Alert(Alert.AlertType.CONFIRMATION, "", ok);
        chanceCard.setHeaderText("Chance Card");
        chanceCard.setContentText(text);
        Optional<ButtonType> result = chanceCard.showAndWait();
    }

    /**
     * Executes the chance card for the given player
     *
     * @param choice           - player chose treasures or cards
     * @param amountOfcards    - the amount of cards the player will be given
     * @param amountOfTreasure - the amount of treasures the player will be given
     */
    public void executeChanceCard(int choice, int amountOfcards, int amountOfTreasure) {
        Treasure treasure;
        CrewCard card;
        if (choice == 1) {
            for (int index = 0; index < amountOfTreasure; index++) {
                treasure = gameWorld.getIslandsMap().get("Treasure").getTreasures().remove(0);
                players[currentPlayerID].getInventory().getTreasures().add(treasure);
            }
        } else {
            for (int index = 0; index < amountOfcards; index++) {
                card = gameWorld.getIslandsMap().get("Treasure").getCrewCards().remove(0);
                players[currentPlayerID].getInventory().getCrewCards().add(card);
            }
        }
    }

}
