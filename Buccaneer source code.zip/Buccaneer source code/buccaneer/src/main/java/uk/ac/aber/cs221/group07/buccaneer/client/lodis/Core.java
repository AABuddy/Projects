package uk.ac.aber.cs221.group07.buccaneer.client.lodis;

import uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.chassis.CoreVariables;
import uk.ac.aber.cs221.group07.buccaneer.client.lodis.common.exceptions.specific.LodisDatabaseIOException;

import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Responsible for core connection management, Lodis is inherited from this class.
 *
 * @author Cerys Amber Skye Lewis -- cel24@aber.ac.uk
 * @version 22.03.15
 * lodis.Core.java 22.03.15 | 2022/05/06
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved.
 */
public class Core {
    private CoreVariables coreVariables;

    public CoreVariables getVariableChassis() {
        return coreVariables;
    }

    public void setVariableChassis(CoreVariables coreVariables) {
        this.coreVariables = coreVariables;
    }


    /**
     * Used to create a new connection between Lodis and the core database.
     */
    public void connect() throws LodisDatabaseIOException {
        try {
            this.coreVariables.setSqliteConnection(
                    DriverManager.getConnection(this.coreVariables.getConnectionString())
            );
        } catch (SQLException ex) {
            throw new LodisDatabaseIOException(ex);
        }
    }

    /**
     * Used to destroy the connection between Lodis and the core database.
     */
    public void disconnect() throws LodisDatabaseIOException {
        try {
            this.coreVariables.getSqliteConnection().close();
            this.coreVariables.setSqliteConnection(null);
        } catch (SQLException ex) {
            throw new LodisDatabaseIOException(ex);
        }
    }
}
