package uk.ac.aber.cs221.group07.buccaneer.client.controllers;
/*
 * @(#) SettingUsernameController.java 1.0 | 2022/05/06 *
 * Copyright (c) 2022 Aberystwyth University.
 * All rights reserved. *
 */
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import uk.ac.aber.cs221.group07.buccaneer.client.Main;
import uk.ac.aber.cs221.group07.buccaneer.client.utils.GameWorld;

import java.io.IOException;
/**
 *SettingUsernameController- Allows you to pick your usernames for the game
 * @author Julia Drodz (jud28)
 * @date 02/05/2022
 * @version 1.0 | release
 */
public class SettingUsernameController {
    @FXML
    private Stage stage;
    @FXML
    private TextField inputPlayer1;
    @FXML
    private TextField inputPlayer2;
    @FXML
    private TextField inputPlayer3;
    @FXML
    private TextField inputPlayer4;
    @FXML
    private Label lblPlayer1;
    @FXML
    private Label lblPlayer2;
    @FXML
    private Label lblPlayer3;
    @FXML
    private Label lblPlayer4;
    /**
     *  Go back to the main window from the main menu
     * @param actionEvent
     */
    public void goToWelcome(ActionEvent actionEvent) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("welcomeScreen.fxml"));
            stage = (Stage)(((Node)actionEvent.getSource()).getScene().getWindow());
            Scene scene = new Scene(fxmlLoader.load());
            stage.setTitle("Welcome to Buccaneer");
            stage.setResizable(false);
            stage.setScene(scene);
            stage.show();
        } catch(IOException e) {
            e.printStackTrace();
        }
    }

    /**
     *  Go back to the board window from the set username menu
     * @param actionEvent
     */
    public void goToBoard(ActionEvent actionEvent) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("boardScreen.fxml"));
            Parent boardViewParent = fxmlLoader.load();
            BoardController controller = fxmlLoader.getController();
            // Pass data between controllers for the scenes
            String[] names = new String[]{inputPlayer1.getText(), inputPlayer2.getText(), inputPlayer3.getText(), inputPlayer4.getText()};
            controller.initializeData(names);

            stage = (Stage)(((Node)actionEvent.getSource()).getScene().getWindow());
            Scene scene = new Scene(boardViewParent);
            stage.setTitle("Buccaneer");
            stage.setResizable(false);
            stage.setScene(scene);
            stage.show();
        } catch(IOException e) {
            e.printStackTrace();
        }
    }
}
