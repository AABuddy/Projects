/* package uk.ac.aber.dcs.cs31620.lingrow.TestFeatures.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import org.jetbrains.annotations.NotNull

@Entity(tableName = "words")
data class WordTest(
    @PrimaryKey(autoGenerate = true)
    @NotNull
    val idTest: Int = 0,
    val nativeTest: String = "",
    val transTest: String = ""
) */
