/*package uk.ac.aber.dcs.cs31620.lingrow.TestFeatures.data

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface WordDaoTest {

    @Insert
    suspend fun insertMultipleWords(wordTestList: List<WordTest>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addWordTest(wordTest: WordTest)


    @Query("DELETE FROM words")
    suspend fun deleteAllWords()

    @Delete
    suspend fun deleteWord(wordTest: WordTest)


    @Query("SELECT * FROM words ORDER BY idTest ASC")
    fun readAllData(): LiveData<List<WordTest>>


    @Query("SELECT * FROM words")
    fun getAllWords(): LiveData<List<WordTest>>

} */