package uk.ac.aber.dcs.cs31620.lingrow.ui.navigation

sealed class Screen(val route: String) {

    object Splash : Screen("splash")
    object Home : Screen("home")
    object VocabScreen : Screen("vocab")
    object Login : Screen("login")
    object LangSelect : Screen("lang")
    object multiQuestion : Screen("multiQ")
    object textQuestion : Screen("textQ")

}

// Screens that will include the Top Bar and Bottom Bar from the Scaffolding!
val screens = listOf(
    Screen.Home,
    Screen.VocabScreen
)

