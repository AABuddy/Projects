package uk.ac.aber.dcs.cs31620.lingrow.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import uk.ac.aber.dcs.cs31620.lingrow.data.dataSource.Word
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.sp
import uk.ac.aber.dcs.cs31620.lingrow.R
import uk.ac.aber.dcs.cs31620.lingrow.ui.navigation.Screen

//import uk.ac.aber.dcs.cs31620.lingrow.TestFeatures.data.WordTest

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomListItem(word: Word) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .background(MaterialTheme.colorScheme.primaryContainer)
                .fillMaxWidth()
                .padding(20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically

        ) {
            Text(
                text = "${word.native}",
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                modifier = Modifier.weight(1f) // Fill with remaining space available
                )
            Text(
                text = "${word.translation}",
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                modifier = Modifier.weight(1f) // Fill with remaining space available
            )

            IconButton(
                onClick = { /* Remove item from the wordlist and update the screen */
                    //Screen.VocabScreen.update()   //Something like this but because of time constraints not able to complete
                }

            ) {
                Icon(
                    imageVector = Icons.Filled.Delete,
                    contentDescription =
                    stringResource(R.string.removeword)
                )

            }

        }
    }
}

@Composable
@Preview
fun CustomListItemPreview() {
    CustomListItem(
        word = Word(
            id = 0,
            native = "Hello",
            translation = "Halo"
        )
    )
}