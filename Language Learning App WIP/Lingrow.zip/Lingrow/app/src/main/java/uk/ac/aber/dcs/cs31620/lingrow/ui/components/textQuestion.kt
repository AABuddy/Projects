package uk.ac.aber.dcs.cs31620.lingrow.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.Button
import androidx.compose.material.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import uk.ac.aber.dcs.cs31620.lingrow.data.dataSource.words
import kotlin.random.Random
import androidx.compose.material.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color


@Composable
fun textQuestion() {
    generateQuestion()
    Column {
        Text("What is the translation for $question")
        var userAnswer by remember { mutableStateOf("") }
        BasicTextField(
            modifier = Modifier
                .width(350.dp)
                .height(60.dp)
                .background(MaterialTheme.colorScheme.primaryContainer)
                .padding(16.dp)
                .border(width = 1.dp, Color.Black, shape = RoundedCornerShape(16.dp)),
            value = userAnswer,
            onValueChange = { newTransText ->
                userAnswer = newTransText
            }

        )
        Button(
            onClick = {
                if (userAnswer == answer)
                    score +  1
            },
            modifier = Modifier
                .padding(end = 8.dp)
                .background(MaterialTheme.colorScheme.primary)
        ) {
            Text("Next Question")
        }
    }
}

@Composable
fun generateQuestion() {
    var typeQuestion = words.random()
    if(Random.nextInt(1,3) == 1) {
        question = typeQuestion.translation
        answer = typeQuestion.native
    } else {
        question = typeQuestion.native
        answer = typeQuestion.translation
        }
    }


