/*package uk.ac.aber.dcs.cs31620.lingrow.TestFeatures.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDateTime

@Database(entities = [WordTest::class], version = 1)
abstract class WordDatabaseTest : RoomDatabase() {
    abstract fun wordDaoTest(): WordDaoTest

    companion object {
        private var instance: WordDatabaseTest? = null
        private val coroutineScope = CoroutineScope(Dispatchers.IO)

        @Synchronized
        fun getDatabase(context: Context): WordDatabaseTest? {
            if (instance == null) {
                instance =
                    Room.databaseBuilder<WordDatabaseTest>(
                        context.applicationContext,
                        WordDatabaseTest::class.java,
                        "words"
                    )
                        //.allowMainThreadQueries()
                        .addCallback(roomDatabaseCallback(context))
                        //.addMigrations(MIGRATION_1_2, MIGRATION_2_3
                        .build()
            } // if
            return instance
        }

        private fun roomDatabaseCallback(context: Context): Callback {
            return object : Callback() {
                override fun onCreate(db: SupportSQLiteDatabase) {
                    super.onCreate(db)

                    coroutineScope.launch {
                        populateDatabase(context, getDatabase(context)!!)
                    }
                }
            }
        }

        private suspend fun populateDatabase(context: Context, instance: WordDatabaseTest) {

            val Word1 = WordTest(0,"hello1", "hallo1")
            val Word2 = WordTest(1,"hello2", "hallo2")
            val Word3 = WordTest(2,"hello3", "hallo3")

            val wordListTest = mutableListOf(
               Word1, Word2, Word3
            )

            val dao = instance.wordDaoTest()
            dao.insertMultipleWords(wordListTest)
        }
    }
} */