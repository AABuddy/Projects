package uk.ac.aber.dcs.cs31620.lingrow.ui.tests


import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavHostController
import uk.ac.aber.dcs.cs31620.lingrow.data.dataSource.words
import uk.ac.aber.dcs.cs31620.lingrow.ui.components.MultipleChoiceQuestion
import uk.ac.aber.dcs.cs31620.lingrow.ui.components.score

@Composable
fun multipleChoiceScreen(navController: NavHostController) {
        repeat(30) {
            MultipleChoiceQuestion()
        }
    resultScreenMulti(navController)
    }

@Composable
@Preview
fun multiPreview() {

}