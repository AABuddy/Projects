package uk.ac.aber.dcs.cs31620.lingrow.ui.home

import android.app.Application
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
//import uk.ac.aber.dcs.cs31620.lingrow.TestFeatures.data.WordRepositoryTest
//import uk.ac.aber.dcs.cs31620.lingrow.TestFeatures.data.WordTest
//import uk.ac.aber.dcs.cs31620.lingrow.data.dataSource.WordRepository
import uk.ac.aber.dcs.cs31620.lingrow.ui.components.TopLevelScaffold
import uk.ac.aber.dcs.cs31620.lingrow.ui.theme.LingrowTheme

@Composable
fun HomeScreen(navController: NavHostController) {

    TopLevelScaffold(
        navController = navController,
        pageContent = { innerPadding ->
            Surface(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize()

            ) {
                Text(
                    text = "Home Screen",
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
        }
    )

       /* val context = LocalContext.current.applicationContext
        LaunchedEffect(key1 = Unit){
        val repository = WordRepositoryTest(context as Application)
        repository.getAllWords()
    } */
}

@Preview
@Composable
private fun HomeScreenPreview(){
    val navController = rememberNavController()
    LingrowTheme(dynamicColor = true) {
        HomeScreen(navController)
    }
}