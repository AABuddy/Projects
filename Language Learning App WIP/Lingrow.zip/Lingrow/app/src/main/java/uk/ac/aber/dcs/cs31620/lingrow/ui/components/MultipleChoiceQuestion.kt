package uk.ac.aber.dcs.cs31620.lingrow.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.Button
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import uk.ac.aber.dcs.cs31620.lingrow.data.dataSource.words
import kotlin.random.Random

var question: String = ""
var answer: String = ""
var score : Int = 0;

@Composable
fun MultipleChoiceQuestion() {

    var options = generateQuesitonOptions()

    Column {
        Text("What is the translation for $question")
        options.forEach { option ->
            Row(modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 5.dp)) {
                Button(onClick = {
                    if (option == answer) {
                        score + 1
                    }
                    }) {
                    Text(option)
                }
            }
        }
    }

}

@Composable
fun generateQuesitonOptions(): List<String> {

    var wordOptions = mutableListOf<String>()
    var randomQuestionWord = words.random()
    var randomOptions = words.shuffled().take(3)

    while (randomQuestionWord in randomOptions) {
        randomOptions = words.shuffled().take(3)
    }

    randomOptions += randomQuestionWord

    if(Random.nextInt(1,3) == 1) {
        question = randomQuestionWord.translation
        answer = randomQuestionWord.native
        for (i in 1..4) {
            wordOptions.add(randomOptions[i].native)
        }
    } else {
        question = randomQuestionWord.native
        answer = randomQuestionWord.translation
        for (i in 1..4) {
            wordOptions.add(randomOptions[i].translation)
        }
    }
    return (wordOptions)
}