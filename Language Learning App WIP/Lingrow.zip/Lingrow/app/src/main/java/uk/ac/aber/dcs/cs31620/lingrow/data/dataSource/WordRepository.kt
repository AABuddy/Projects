/*package uk.ac.aber.dcs.cs31620.lingrow.data.dataSource

import androidx.lifecycle.LiveData

class WordRepository(private val wordDao: WordDao) {

    val readAllData: LiveData<List<Word>> = wordDao.readAllData()

    suspend fun addWord(word: Word) {
        wordDao.addWord(word)
    }

    fun getAllData(): List<Word> {
        return listOf(
            Word(
                id = 0,
                native = "Native1",
                translation = "Trans1"
            ),

            Word(
                id = 1,
                native = "Native2",
                translation = "Trans2"
            ),

            Word(
                id = 2,
                native = "Native3",
                translation = "Trans3"
            ),
        )
    }
} */