package uk.ac.aber.dcs.cs31620.lingrow.data.dataSource

val words = listOf(
    Word(0, "test1", "t1"),
    Word(0, "test2", "t2"),
    Word(0, "test3", "t3"),
)