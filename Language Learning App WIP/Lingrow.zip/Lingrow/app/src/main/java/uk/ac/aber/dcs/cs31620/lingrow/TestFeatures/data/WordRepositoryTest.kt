/* package uk.ac.aber.dcs.cs31620.lingrow.TestFeatures.data

import android.app.Application
import androidx.lifecycle.LiveData

class WordRepositoryTest(application: Application) {

    private val wordDaoTest = WordDatabaseTest.getDatabase(application)!!.wordDaoTest()

    fun getAllWords() = wordDaoTest.getAllWords()


    suspend fun insertMultipleWords(words: List<WordTest>){
        wordDaoTest.insertMultipleWords(words)
    }


    suspend fun deleteAllWords() {
        wordDaoTest.deleteAllWords()
    }

    suspend fun addWordTest(wordTest: WordTest){
        wordDaoTest.addWordTest(wordTest)
    }

} */