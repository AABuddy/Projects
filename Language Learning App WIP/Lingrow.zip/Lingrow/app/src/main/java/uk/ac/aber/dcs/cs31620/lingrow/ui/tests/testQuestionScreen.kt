package uk.ac.aber.dcs.cs31620.lingrow.ui.tests

import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavHostController
import uk.ac.aber.dcs.cs31620.lingrow.ui.components.textQuestion

@Composable
fun textQuestionScreen(navController: NavHostController) {  //Just repeats the text question function 30 times and then
    repeat(30) {                                     //inefficient however due to time constraint failed to merge the files
        textQuestion()
    }
    resultScreenMulti(navController)
}

@Composable
@Preview
fun textPreview() {

}