/*package uk.ac.aber.dcs.cs31620.lingrow.TestFeatures.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import uk.ac.aber.dcs.cs31620.lingrow.data.dataSource.Word

class WordViewmodelTest (application: Application): AndroidViewModel(application) {
    private val repository: WordRepositoryTest = WordRepositoryTest(application)

    var wordList: LiveData<List<WordTest>> = repository.getAllWords()
    private set




} */