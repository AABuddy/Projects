package uk.ac.aber.dcs.cs31620.lingrow.data.dataSource

import androidx.room.Entity
import androidx.room.PrimaryKey

    @Entity(tableName = "words")
    data class Word(
        @PrimaryKey(autoGenerate = true)
        var id: Int,
        var native: String,
        var translation: String
    )




