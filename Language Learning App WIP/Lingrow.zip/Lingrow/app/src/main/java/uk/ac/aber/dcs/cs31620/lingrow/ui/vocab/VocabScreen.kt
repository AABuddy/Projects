package uk.ac.aber.dcs.cs31620.lingrow.ui.vocab

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHost
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import uk.ac.aber.dcs.cs31620.lingrow.R
//import uk.ac.aber.dcs.cs31620.lingrow.TestFeatures.data.WordTest
//import uk.ac.aber.dcs.cs31620.lingrow.TestFeatures.data.WordViewmodelTest
import uk.ac.aber.dcs.cs31620.lingrow.data.dataSource.Word
import uk.ac.aber.dcs.cs31620.lingrow.data.dataSource.words
//import uk.ac.aber.dcs.cs31620.lingrow.data.dataSource.WordDao
//import uk.ac.aber.dcs.cs31620.lingrow.data.dataSource.WordRepository
import uk.ac.aber.dcs.cs31620.lingrow.ui.components.CustomListItem
import uk.ac.aber.dcs.cs31620.lingrow.ui.components.TopLevelScaffold
import uk.ac.aber.dcs.cs31620.lingrow.ui.theme.LingrowTheme

@Composable
fun VocabScreen(navController: NavHostController ) {

    TopLevelScaffold(
        navController = navController,
        floatingActionButton = {
            FloatingActionButton(
                onClick = { /*AddWordScreen(navController = navController) */}
            ) {
                Icon(
                    imageVector = Icons.Filled.Add,
                    contentDescription =
                    stringResource(R.string.addword)
                )
            }
        },
        {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(4.dp),  //Vertical Space Between the Custom List Items
                modifier = Modifier
                    .padding(vertical = 64.dp),                     //Space From Top Bar and Sides of phone
                contentPadding = PaddingValues(4.dp)                //Overall Space From Everything
            ) {
                items(words) { word ->
                    CustomListItem(word = word)
                }
            }
        }
    )

}

@Composable
fun update(navController: NavHostController) {
    navController.navigate("home") {
        popUpTo("splash")
    }
}


@Preview
@Composable
private fun VocabScreenPreview() {
    val navController = rememberNavController()
    LingrowTheme(dynamicColor = true) {
        VocabScreen(navController)
    }

}
