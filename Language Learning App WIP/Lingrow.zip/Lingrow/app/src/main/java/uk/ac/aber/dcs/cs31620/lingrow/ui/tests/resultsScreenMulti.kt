package uk.ac.aber.dcs.cs31620.lingrow.ui.tests

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import uk.ac.aber.dcs.cs31620.lingrow.ui.components.score
import uk.ac.aber.dcs.cs31620.lingrow.ui.theme.LingrowTheme

@Composable
fun resultScreenMulti(navController: NavController) {

    val percentage = (score / 30) * 100

    Column(                                                 //Column to organise screen data
        modifier = Modifier
            .padding(vertical = 50.dp)
            .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center

    ) {
        Text(
            text = "Your Score was",
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            fontSize = 12.sp
        )

        Text(
            text = "${score}",
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp
        )

        Text(
            text = "Expressed as ",
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            fontSize = 12.sp
        )

        Text(
            text = "${percentage}%",
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp
        )

        Button(
            onClick = {
                navController.navigate("home")
                score = 0
            },
            modifier = Modifier
                .padding(end = 8.dp)
                .background(MaterialTheme.colorScheme.primary)
        ) {
            Text("Home")
        }
    }
    }

@Preview
@Composable
private fun ResultScreenPreview() {
    val navController = rememberNavController()
    LingrowTheme(dynamicColor = false) {
        resultScreenMulti(navController)
    }
}
