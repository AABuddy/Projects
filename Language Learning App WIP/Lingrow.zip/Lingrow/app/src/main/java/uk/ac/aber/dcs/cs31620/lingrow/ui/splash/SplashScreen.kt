package uk.ac.aber.dcs.cs31620.lingrow.ui.splash

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import kotlinx.coroutines.delay
import uk.ac.aber.dcs.cs31620.lingrow.ui.theme.LingrowTheme
import uk.ac.aber.dcs.cs31620.lingrow.R


@Composable
fun SplashScreen(navController: NavController) {
    LaunchedEffect(key1 = true) {
        delay(3000L)
        navController.navigate("home") {
            popUpTo("splash") {
                inclusive = true
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(id = R.drawable.lingrow_logo), "logo",
            modifier = Modifier
                .width(110.dp)
                .height(110.dp)
        )
    }
}

@Preview
@Composable
private fun SplashScreenPreview() {
    val navController = rememberNavController()
    LingrowTheme(dynamicColor = true) {
        SplashScreen(navController)
    }
}