package uk.ac.aber.dcs.cs31620.lingrow.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.Help
import androidx.compose.material.icons.filled.Login
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import uk.ac.aber.dcs.cs31620.lingrow.R
import uk.ac.aber.dcs.cs31620.lingrow.ui.navigation.Screen
import uk.ac.aber.dcs.cs31620.lingrow.ui.theme.LingrowTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainPageNavigationDrawer(
    navController: NavHostController,
    drawerState: DrawerState,
    closeDrawer: () -> Unit = {},
    content: @Composable () -> Unit = {}
) {
    val items = listOf("MultipleChoiceQuestions", "TextQuestions")

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            val selectedItem = rememberSaveable { mutableStateOf(0) }
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .background(MaterialTheme.colorScheme.background)
                    .fillMaxSize()
            ) {

                Image(
                    modifier = Modifier
                        .size(110.dp)
                        .padding(bottom = 16.dp, top = 16.dp),
                    painter = painterResource(id = R.drawable.lingrow_logo),
                    contentDescription = "Lingrow Logo",
                    contentScale = ContentScale.Crop
                )

                items.forEachIndexed { index, item ->
                    NavigationDrawerItem(
                        label = { Text(item)},
                        selected = index == selectedItem.value,
                        onClick = {
                            /* Screen.route.item */
                            //Should take the user to the start of test they want to do
                        }
                    )
                }
            }     },
        content = content
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Preview
@Composable
private fun MainPageNavigationDrawerPreview() {
    LingrowTheme(dynamicColor = true) {
        val navController = rememberNavController()
        val drawerState = rememberDrawerState(initialValue = DrawerValue.Open)
        MainPageNavigationDrawer(navController, drawerState)
    }
}