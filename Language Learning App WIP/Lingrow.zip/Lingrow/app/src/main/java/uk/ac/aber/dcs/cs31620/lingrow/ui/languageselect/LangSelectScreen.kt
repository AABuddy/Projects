package uk.ac.aber.dcs.cs31620.lingrow.ui.languageselect

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.*
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import uk.ac.aber.dcs.cs31620.lingrow.ui.theme.LingrowTheme

@Composable
fun LangSelectScreen(navController: NavHostController) {

        Column(
            modifier = Modifier
                .padding(vertical = 50.dp)
                .fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center

        ) {

            Text(text = "Native Language", color = MaterialTheme.colorScheme.onPrimaryContainer)
            var nativeLang by remember { mutableStateOf("") }
            BasicTextField(
                modifier = Modifier
                    .width(350.dp)
                    .height(60.dp)
                    .background(MaterialTheme.colorScheme.primaryContainer)    //Change to Implemented Colors if have time
                    .padding(16.dp)
                    .border(width = 1.dp, Color.Black, shape = RoundedCornerShape(16.dp)),
                value = nativeLang,
                onValueChange = { newText ->
                    nativeLang = newText
                },
            )

            Text(text = "Language to learn", color = MaterialTheme.colorScheme.onPrimaryContainer)
            var transLang by remember { mutableStateOf("") }
            BasicTextField(
                modifier = Modifier
                    .width(350.dp)
                    .height(60.dp)
                    .background(MaterialTheme.colorScheme.primaryContainer)    //Change to Implemented Colors if have time
                    .padding(16.dp)
                    .border(width = 1.dp, Color.Black, shape = RoundedCornerShape(16.dp)),
                value = transLang,
                onValueChange = { newTransText ->
                    transLang = newTransText

                },
            )

            Button(
                onClick = {
                    navController.navigate("home")
                },
                modifier = Modifier
                    .padding(end = 8.dp)
            ) {
                Text("Confirm")
            }
        }
    }


    @Composable
    @Preview
fun LangSelectPreview() {
    val navController = rememberNavController()
    LingrowTheme(dynamicColor = false) {
        LangSelectScreen(navController)
    }
}
