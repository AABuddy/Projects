package uk.ac.aber.dcs.cs31620.lingrow.ui.vocab


import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.constraintlayout.compose.ConstraintLayout
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import uk.ac.aber.dcs.cs31620.lingrow.R
import uk.ac.aber.dcs.cs31620.lingrow.data.dataSource.Word
import uk.ac.aber.dcs.cs31620.lingrow.data.dataSource.words
import uk.ac.aber.dcs.cs31620.lingrow.ui.theme.LingrowTheme
import uk.ac.aber.dcs.cs31620.lingrow.ui.theme.LingrowTheme

@Composable
fun AddWordScreen(navController: NavHostController) {

    Column(
        modifier = Modifier
            .padding(vertical = 50.dp)
            .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center

    ) {

        Text(text = "Native Language", color = MaterialTheme.colorScheme.onPrimaryContainer)
        var nativeWord by remember { mutableStateOf("") }
        BasicTextField(
            modifier = Modifier
                .width(350.dp)
                .height(60.dp)
                .background(MaterialTheme.colorScheme.primaryContainer)    //Change to Implemented Colors if have time
                .padding(16.dp)
                .border(width = 1.dp, Color.Black, shape = RoundedCornerShape(16.dp)),
            value = nativeWord,
            onValueChange = { newText ->
                nativeWord = newText
            },
        )

        Text(text = "Language to learn", color = MaterialTheme.colorScheme.onPrimaryContainer)
        var transWord by remember { mutableStateOf("") }
        BasicTextField(
            modifier = Modifier
                .width(350.dp)
                .height(60.dp)
                .background(MaterialTheme.colorScheme.primaryContainer)    //Change to Implemented Colors if have time
                .padding(16.dp)
                .border(width = 1.dp, Color.Black, shape = RoundedCornerShape(16.dp)),
            value = transWord,
            onValueChange = { newTransText ->
                transWord = newTransText

            },
        )

        Button(
            onClick = {
                navController.navigate("vocab")
                //Back to Vocab Screen, nothing should happen
            },
            modifier = Modifier
                .width(250.dp)
                .padding(5.dp)
        ) {
            Text("Cancel")
        }


        Button(
            onClick = {
                // ADD word to database

                navController.navigate("vocab")
            },
            modifier = Modifier
                .width(250.dp)
                .padding(5.dp)

        ) {
            Text("Confirm")
        }
    }
}


@Composable
@Preview
private fun AddWordScreenPreview(){
    val navController = rememberNavController()
    LingrowTheme(dynamicColor = false) {
        AddWordScreen(navController)
    }
}