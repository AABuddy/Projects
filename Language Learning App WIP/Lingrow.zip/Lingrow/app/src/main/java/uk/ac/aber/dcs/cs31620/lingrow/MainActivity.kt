package uk.ac.aber.dcs.cs31620.lingrow

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import uk.ac.aber.dcs.cs31620.lingrow.ui.vocab.VocabScreen
import uk.ac.aber.dcs.cs31620.lingrow.ui.home.HomeScreen
import uk.ac.aber.dcs.cs31620.lingrow.ui.languageselect.LangSelectScreen
import uk.ac.aber.dcs.cs31620.lingrow.ui.splash.SplashScreen
import uk.ac.aber.dcs.cs31620.lingrow.ui.navigation.Screen
import uk.ac.aber.dcs.cs31620.lingrow.ui.theme.LingrowTheme
import uk.ac.aber.dcs.cs31620.lingrow.ui.vocab.VocabScreen


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LingrowTheme(dynamicColor = false) {    //Dynamic Color switches top bar color dependent on background
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    BuildNavigationGraph()
                }
            }
        }
    }
}

@Composable
private fun BuildNavigationGraph() {

    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Screen.Splash.route

    ) {
        composable(Screen.Splash.route) { SplashScreen(navController) }
        composable(Screen.Home.route) { HomeScreen(navController) }
        composable(Screen.VocabScreen.route) { VocabScreen(navController) }
        composable(Screen.LangSelect.route) { LangSelectScreen(navController) }
    }
}


@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    LingrowTheme(dynamicColor = true) {
        BuildNavigationGraph()
    }
}

